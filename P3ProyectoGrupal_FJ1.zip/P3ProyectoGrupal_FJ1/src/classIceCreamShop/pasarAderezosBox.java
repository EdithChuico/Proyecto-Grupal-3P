package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import org.bson.Document;
//Factory Method: En esta clase se llaman los datos almacenados en la base de datos, para visualizarlos en un ComboBox
public class pasarAderezosBox extends initializeMongo{
    //Obtener productos desde la base de datos
    public List<String> obtenerProductos() {
	    openMongo();
	    MongoDatabase database = getDatabase();
            //Colección a obtener
	    MongoCollection<Document> collection = database.getCollection("Aderezos");
	    
	    List<String> datos = new ArrayList<>();
	    FindIterable<Document> result = collection.find();

	    try (MongoCursor<Document> cursor = result.iterator()) {
	        while (cursor.hasNext()) {
	            Document document = cursor.next();
                   
	            String nombre = document.getString("Producto:");
	            datos.add(nombre);
	        }
	    }
	    return datos;
	}
    //Añdir el producto obtenido desde la base de datos
   public void añadirProdComboBox(JComboBox flavorShop) {
            //Se llama a la clase obtenerProductos en donde se obtuvieron anteriormente los productos a mostrar 
	    List<String> datos = obtenerProductos();
	    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(datos.toArray(new String[0]));
	    //Agregar los datos al comboBox
            flavorShop.setModel(model); 
	}
}
