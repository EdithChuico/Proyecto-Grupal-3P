/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import java.awt.Color;
import javax.swing.JLabel;

/**
 *
 * @author USER
 */
public class cardNumber {
    public void CardNumber(String CNumber, JLabel ValidationCNumber){
        if(CNumber.isEmpty()){
            ValidationCNumber.setText("¡Este campo es obligatorio!");
            ValidationCNumber.setForeground(Color.RED);
        }else if(CNumber.length()!=13){
            ValidationCNumber.setText("La tarjeta ingresada no es valida, ingresa una de 13 caracteres numericos");
        }else{
            ValidationCNumber.setText("");
        }
    }
}
