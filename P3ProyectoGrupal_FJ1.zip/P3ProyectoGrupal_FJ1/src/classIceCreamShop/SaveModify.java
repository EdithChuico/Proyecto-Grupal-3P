/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import org.bson.Document;

/**
 *
 * @author Usuario
 */
public class SaveModify {
    public void SaveModifyB4(String quantiNew, String idSearch) {
        if (quantiNew.isEmpty() || idSearch.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stockr = Integer.parseInt(quantiNew);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Inventario");
        MongoCollection<Document> collectionn = database.getCollection("Aderezos");

        Document query = new Document("Código:", idSearch);
        long count = collection.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(null, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            Document act = new Document("$set", new Document("Porciones:", quantiNew));
            collection.updateOne(query, act);
            collectionn.updateOne(query, act);
            JOptionPane.showMessageDialog(null, "Cantidad del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
        }  
    }
}
