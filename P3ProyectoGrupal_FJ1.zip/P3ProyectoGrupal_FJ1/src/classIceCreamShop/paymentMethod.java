/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import java.awt.Color;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class paymentMethod {
    public void SPayment(String SelectedPaymethod, JLabel SBCValidation4, JDialog CardDialog){
        if(SelectedPaymethod=="Seleccione"){
          methodSeleccione( SelectedPaymethod,  SBCValidation4,  CardDialog);
           
        }else if(SelectedPaymethod=="Efectivo"){
          methodEfectivo( SelectedPaymethod,  SBCValidation4,  CardDialog);
           
        }else if(SelectedPaymethod=="Transferencia"){
          methodTransferencia( SelectedPaymethod,  SBCValidation4,  CardDialog);
            
        }else if(SelectedPaymethod=="Tarjeta"){
          methodTarjeta( SelectedPaymethod,  SBCValidation4,  CardDialog);
        }
    }
    
    public void methodSeleccione(String SelectedPaymethod, JLabel SBCValidation4, JDialog CardDialog){
       SBCValidation4.setText("¡Selecciona un metodo de pago valido!");
       SBCValidation4.setForeground(Color.RED);  
    }
    public void methodEfectivo(String SelectedPaymethod, JLabel SBCValidation4, JDialog CardDialog){
       // Crear un JTextField para que el usuario ingrese la cantidad
       JTextField MontoRecibido = new JTextField();
       Object[] message = {
          "Monto recibido:", MontoRecibido
       };
       int option = JOptionPane.showConfirmDialog(null, message, "Ingresar Monto", JOptionPane.OK_CANCEL_OPTION);
      if (option == JOptionPane.OK_OPTION) {
           // Obtener la cantidad ingresada
           String amountStr = MontoRecibido.getText();
      }
        SBCValidation4.setText("");   
    }
    public void methodTransferencia(String SelectedPaymethod, JLabel SBCValidation4, JDialog CardDialog){
       JOptionPane.showConfirmDialog(null, "Banco: Pichincha\nTipo de cuenta: Ahorros\nCuenta: 2200337799\nRUC: 1723456890001\nEsperando transferencia...", "Datos de la cuenta", JOptionPane.OK_CANCEL_OPTION);
       SBCValidation4.setText("");
    }
    public void methodTarjeta(String SelectedPaymethod, JLabel SBCValidation4, JDialog CardDialog){
        CardDialog.setVisible(true);
        SBCValidation4.setText("");
    }
}
