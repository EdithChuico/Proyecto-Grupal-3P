package classIceCreamShop;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

public class createFlavor {
    public void validData(String Product,String Code,String Quantity,JTextField TNameTF,JTextField TCuantityTF,JTextField TCodeTF){
      if (Product.isEmpty() || Code.isEmpty() ||Quantity.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        if (!Product.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(null, "Ingrese un nombre valido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!Code.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stockr = Integer.parseInt(Quantity);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(null, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }  
        saveFlavor( Product, Code, Quantity, TNameTF, TCuantityTF, TCodeTF);
    }
    //Codigo para la creación de un nuevo sabor(Fcatory Method)
    public void saveFlavor(String Product,String Code,String Quantity,JTextField TNameTF,JTextField TCuantityTF,JTextField TCodeTF){
        initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Sabores"); 
        MongoCollection<Document> collectionn = database.getCollection("Inventario");
        Document query = new Document("Código:", Code);
        long count = collectionn.countDocuments(query);
        Document queryy = new Document("Producto:", Product);
        long counnt = collectionn.countDocuments(queryy);
        if( count <= 0){
        }else {
        JOptionPane.showMessageDialog(null, "El codigo ya existe dentro de los datos ingresados, por favor ingrese un codigo distinto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if( counnt <= 0){
        }else {
            JOptionPane.showMessageDialog(null, "El nombre del sabor ya existe dentro de los datos ingresados, por favor ingrese un nombre distinto distinto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String resultado = Product.substring(0, 1).toUpperCase() + Product.substring(1).toLowerCase();
        Document document = new Document().append("Producto:", resultado).append("Código:", Code).append("Porciones:", Quantity);
        collection.insertOne(document);
        collectionn.insertOne(document);
        JOptionPane.showMessageDialog(null, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        
        cleanTextField( TNameTF, TCuantityTF, TCodeTF);
    }
    public void cleanTextField(JTextField TNameTF,JTextField TCuantityTF,JTextField TCodeTF){
    TNameTF.setText("");
    TCuantityTF.setText("");
    TCodeTF.setText("");
   }
}
