package Observer;
import javax.swing.JOptionPane;
public class llenarCampos {
    //Ejemplo de patron de comportamiento tipo Observer
public void llenarCampos(){
//Mensaje de advertencia para el usuario
JOptionPane.showMessageDialog(null, "Debes llenar todos los campos","Campos vacios",JOptionPane.WARNING_MESSAGE);     
 }  
}
