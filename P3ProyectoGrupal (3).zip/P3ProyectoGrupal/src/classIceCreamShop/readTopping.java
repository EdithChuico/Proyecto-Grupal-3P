/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class readTopping {
  public void LoadDataSuplies(JTable STable){
        initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        FindIterable<Document> documents = collection.find();
        DefaultTableModel model;
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});
        for(Document document : documents){
            Vector<Object> Row = new Vector<>();
            Row.add(document.getString("Producto:"));
            Row.add(document.getString("Código:"));
            Row.add(document.getString("Porciones:"));
             
            model.addRow(Row);
               
        }STable.setModel(model);
        
         
}
}
