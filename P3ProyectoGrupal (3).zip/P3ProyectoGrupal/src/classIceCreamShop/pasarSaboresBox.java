/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class pasarSaboresBox extends initializeMongo{
   public List<String> obtenerProductos() {
	    openMongo();
	    MongoDatabase database = getDatabase();
	    MongoCollection<Document> collection = database.getCollection("Sabores");
	    
	    List<String> datos = new ArrayList<>();
	    FindIterable<Document> result = collection.find();

	    try (MongoCursor<Document> cursor = result.iterator()) {
	        while (cursor.hasNext()) {
	            Document document = cursor.next();
	            String nombre = document.getString("Producto:");
	            datos.add(nombre);
	        }
	    }
	    return datos;
	}
   public void añadirProdComboBox(JComboBox flavorShop) {
	    List<String> datos = obtenerProductos();
	    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(datos.toArray(new String[0]));
	    flavorShop.setModel(model); 
	}
}
