package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class readFlavors {
  public void LoadDataTaste(JTable TTable){
        initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
            MongoCollection<Document> collection = database.getCollection("Sabores"); 
            FindIterable<Document> documents = collection.find();
            DefaultTableModel model;
            model = new DefaultTableModel();
            model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});
            
            for(Document document : documents){
                Vector<Object> Row = new Vector<>();
                Row.add(document.getString("Producto:"));
                Row.add(document.getString("Código:"));
                Row.add(document.getString("Porciones:"));
                model.addRow(Row);
            }TTable.setModel(model);
       
}
}
