package classIceCreamShop;
import interfazGUI.IceCreamShop;
import interfazGUI.Login;
import javax.swing.JOptionPane;
public class changeUser {
   public void changeUser(java.awt.Component componente){
        int respuesta = JOptionPane.showConfirmDialog(null, "Al cambiar de usuario se perderan todos los datos no guardados, ¿esta seguro que desea continuar?","Confirmar cambio",JOptionPane.YES_NO_OPTION);
        if(respuesta==JOptionPane.YES_OPTION){
            Login L = new Login();
            L.setVisible(true);
            closeWindow(componente);
            IceCreamShop iSS=new IceCreamShop();
            iSS.setVisible(false);
        }
   } 
   public void closeWindow( java.awt.Component componente){
         if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }
    }
}
