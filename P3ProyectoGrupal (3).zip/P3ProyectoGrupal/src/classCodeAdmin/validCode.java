/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classCodeAdmin;

import interfazGUI.WorkerManager;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class validCode {
    public void validCodeAdmin(String Password, java.awt.Component componente){
     if(Password.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debes llenar todos los campos","Campos vacios",JOptionPane.WARNING_MESSAGE);
        }else{ // Verificar si se encontraron resultados
            if ("A1234".equals(Password)) {
               WorkerManager H = new WorkerManager();
               H.setVisible(true);
               closeVentana(componente);
            } else {
               JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Inicio Fallido", JOptionPane.ERROR_MESSAGE);
            }
        }   
    }
    private static void closeVentana(java.awt.Component componente) {
        if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }
    }
}
