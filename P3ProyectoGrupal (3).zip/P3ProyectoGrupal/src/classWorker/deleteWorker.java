package classWorker;
import generalFunctionalities.initializeMongo;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;
public class deleteWorker extends initializeMongo{
   public void deleteWorker(String idSearch,JTextField newPasword,JTextField uptadeId1,JTextField newName1){
    openMongo();
    MongoDatabase db=getDatabase();
    MongoCollection<Document> collection = db.getCollection("Vendedores");
    Document query = new Document("Cedula", idSearch);
    collection.deleteOne(query);
    JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
    cleanTextField( newPasword, uptadeId1, newName1);
   }
   public void cleanTextField(JTextField newPasword,JTextField uptadeId1,JTextField newName1){
    newPasword.setText("");
    uptadeId1.setText("");
    newName1.setText("");   
   }
           
}
