package classWorker;
import generalFunctionalities.initializeMongo;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

public class findWorker extends initializeMongo{
    public void validData(String idSearch,String PasswordNew,JTextField uptadeId1,JTextField newPasword,JTextField newName1){
        if (PasswordNew.isEmpty() ) {
            JOptionPane.showMessageDialog(null, "No puede actualizar campos vacios, ingrese un dato porfavor", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
      if (!PasswordNew.matches("[A-Z]\\d{4}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra mayuscula seguida de cuatro números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
     try{
        if (!idSearch.matches("\\d{10}")) {
          JOptionPane.showMessageDialog(null, "Ingrese una cedula válida (10 números)", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }} catch (NumberFormatException e) {
         JOptionPane.showMessageDialog(null, "Ingrese una cedula válida (Solo números)", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    }findWorkers( idSearch, PasswordNew, uptadeId1, newPasword, newName1);
    }
   public void findWorkers(String idSearch,String PasswordNew,JTextField uptadeId1,JTextField newPasword,JTextField newName1){
     openMongo();
     MongoDatabase db=getDatabase();
     MongoCollection<Document> collection = db.getCollection("Vendedores");
     Document query = new Document("Cedula", idSearch);
     long count= collection.countDocuments(query);
     if(count<=0){
        JOptionPane.showMessageDialog(null, "La cedula ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
        return;     
     }else{
        Document act= new Document("$set",new Document("CódigoUsuario:", PasswordNew));
        collection.updateOne(query, act);
        JOptionPane.showMessageDialog(null, "Usuario actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
     }
   }
   public void cleanTextField(JTextField uptadeId1,JTextField newPasword,JTextField newName1){
    newPasword.setText("");
    uptadeId1.setText("");
    newName1.setText("");
   }
}
