/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classOfert;

import interfazGUI.Ofert;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class closeOfert {
  public void closeOfert(){
      Ofert o=new Ofert();
      o.setVisible(false);
      JOptionPane.showMessageDialog(null, "Venta registrada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
  }  
}
