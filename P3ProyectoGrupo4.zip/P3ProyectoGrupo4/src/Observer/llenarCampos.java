package Observer;
import javax.swing.JOptionPane;
public class llenarCampos {
    //Ejemplo de patron de comportamiento tipo Observer
//Observer:Se aplica el tipo observer al crear una clase llamada "llenarCampos" 
//en donde se va crear la ventana emergente de precaución al no tener todos los 
//datos de una interfaz completados
public void llenarCampos(){
//Mensaje de advertencia para el usuario
JOptionPane.showMessageDialog(null, "Debes llenar todos los campos","Campos vacios",JOptionPane.WARNING_MESSAGE);     
 }  
}
