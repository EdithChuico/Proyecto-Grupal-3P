package interfazGUI;

import classLogin.validLogin;
import generalFunctionalities.reproducirSonido;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jl.decoder.JavaLayerException;
import tipografias.Fuentes;

public class Login extends javax.swing.JFrame {
    validLogin vL=new validLogin();
    Fuentes tipoFuente;
    String dir = "mongodb://localhost:27017";
    public Login() {
        initComponents();
        //Cambiar fuentes
        
        tipoFuente = new Fuentes();
        UserL.setFont(tipoFuente.fuente(tipoFuente.QS,1,20));
        UserTF.setFont(tipoFuente.fuente(tipoFuente.QS,1,20));
        PasswordL.setFont(tipoFuente.fuente(tipoFuente.QS,1,20));
        PasswordPF.setFont(tipoFuente.fuente(tipoFuente.QS,1,20));
        LoginB.setFont(tipoFuente.fuente(tipoFuente.QS,1,16));
        UserManualB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
        QuitB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
        //Posicionamiento central
        this.setLocationRelativeTo(null);
        //Reescalado de imagenes
        rsscalelabel.RSScaleLabel.setScaleLabel(BurgerMenuB, "src/imagenes/butgerpositivo.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(ExitL, "src/imagenes/cerrarpositivo.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(MinimizeL, "src/imagenes/Minimizarpositivo.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(MaximizeL, "src/imagenes/maximizarnodisponible.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(Background, "src/imagenes/Background.png");
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LoginLateralPanel = new javax.swing.JPanel();
        panelRound1 = new generalFunctionalities.PanelRound();
        BurgerButon = new javax.swing.JButton();
        BurgerMenuB = new javax.swing.JLabel();
        UserManualB = new javax.swing.JButton();
        QuitB = new javax.swing.JButton();
        LoginPanel = new javax.swing.JPanel();
        LogoPanel = new generalFunctionalities.PanelRound();
        LogoL = new javax.swing.JLabel();
        PutDataPanel = new generalFunctionalities.PanelRound();
        PasswordL = new javax.swing.JLabel();
        UserL = new javax.swing.JLabel();
        UserTF = new javax.swing.JTextField();
        PasswordPF = new javax.swing.JPasswordField();
        LoginB = new javax.swing.JButton();
        ExitB = new javax.swing.JButton();
        ExitL = new javax.swing.JLabel();
        MaximizeL = new javax.swing.JLabel();
        MinimizeB = new javax.swing.JButton();
        MinimizeL = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 480));
        setUndecorated(true);

        panelRound1.setBackground(new java.awt.Color(115, 115, 115));
        panelRound1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BurgerButon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BurgerButon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BurgerButonActionPerformed(evt);
            }
        });
        BurgerButon.setBorder(null);
        BurgerButon.setOpaque(false);
        BurgerButon.setContentAreaFilled(false);
        BurgerButon.setBorderPainted(false);
        panelRound1.add(BurgerButon, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 50, 50));
        panelRound1.add(BurgerMenuB, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 15, 50, 47));

        UserManualB.setBackground(new java.awt.Color(104, 192, 183));
        UserManualB.setForeground(new java.awt.Color(255, 255, 255));
        UserManualB.setText("Manual de Usuario");
        UserManualB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserManualBActionPerformed(evt);
            }
        });
        panelRound1.add(UserManualB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 200, 60));

        QuitB.setBackground(new java.awt.Color(205, 76, 130));
        QuitB.setForeground(new java.awt.Color(255, 255, 255));
        QuitB.setText("Salir");
        QuitB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QuitBActionPerformed(evt);
            }
        });
        panelRound1.add(QuitB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 273, 200, 50));

        javax.swing.GroupLayout LoginLateralPanelLayout = new javax.swing.GroupLayout(LoginLateralPanel);
        LoginLateralPanel.setLayout(LoginLateralPanelLayout);
        LoginLateralPanelLayout.setHorizontalGroup(
            LoginLateralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginLateralPanelLayout.createSequentialGroup()
                .addComponent(panelRound1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        LoginLateralPanelLayout.setVerticalGroup(
            LoginLateralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelRound1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        LoginPanel.setBackground(new java.awt.Color(51, 204, 255));
        LoginPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LogoPanel.setBackground(new java.awt.Color(235, 104, 156));
        LogoPanel.setMaximumSize(new java.awt.Dimension(164, 164));
        LogoPanel.setMinimumSize(new java.awt.Dimension(164, 164));
        LogoPanel.setPreferredSize(new java.awt.Dimension(164, 164));
        LogoPanel.setRoundBottomLeft(200);
        LogoPanel.setRoundBottomRight(200);
        LogoPanel.setRoundTopLeft(200);
        LogoPanel.setRoundTopRight(200);

        LogoL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/LogoDeliFrostMini.png"))); // NOI18N

        javax.swing.GroupLayout LogoPanelLayout = new javax.swing.GroupLayout(LogoPanel);
        LogoPanel.setLayout(LogoPanelLayout);
        LogoPanelLayout.setHorizontalGroup(
            LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 164, Short.MAX_VALUE)
            .addGroup(LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(LogoPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(LogoL)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        LogoPanelLayout.setVerticalGroup(
            LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 164, Short.MAX_VALUE)
            .addGroup(LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(LogoPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(LogoL)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        LoginPanel.add(LogoPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 164, 164));
        LogoPanel.getAccessibleContext().setAccessibleName("");

        PutDataPanel.setRoundBottomLeft(100);
        PutDataPanel.setRoundBottomRight(100);
        PutDataPanel.setRoundTopLeft(100);
        PutDataPanel.setRoundTopRight(100);
        PutDataPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PasswordL.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        PasswordL.setText("Contraseña");
        PutDataPanel.add(PasswordL, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, 40));

        UserL.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        UserL.setText("Usuario");
        PutDataPanel.add(UserL, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, 40));

        UserTF.setBackground(new java.awt.Color(205, 76, 130));
        UserTF.setForeground(new java.awt.Color(255, 255, 255));
        UserTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserTFActionPerformed(evt);
            }
        });
        PutDataPanel.add(UserTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 42, 350, 40));

        PasswordPF.setBackground(new java.awt.Color(205, 76, 130));
        PasswordPF.setForeground(new java.awt.Color(255, 255, 255));
        PutDataPanel.add(PasswordPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 350, 40));

        LoginB.setBackground(new java.awt.Color(104, 192, 183));
        LoginB.setForeground(new java.awt.Color(255, 255, 255));
        LoginB.setText("INGRESAR");
        LoginB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginBActionPerformed(evt);
            }
        });
        PutDataPanel.add(LoginB, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 120, 30));

        LoginPanel.add(PutDataPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 240, 500, 230));

        ExitB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ExitB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitBActionPerformed(evt);
            }
        });
        ExitB.setBorder(null);
        ExitB.setOpaque(false);
        ExitB.setContentAreaFilled(false);
        ExitB.setBorderPainted(false);
        LoginPanel.add(ExitB, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 20, 20));
        LoginPanel.add(ExitL, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 20, 20));
        LoginPanel.add(MaximizeL, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 20, 20));

        MinimizeB.setBorder(null);
        MinimizeB.setOpaque(false);
        MinimizeB.setContentAreaFilled(false);
        MinimizeB.setBorderPainted(false);
        MinimizeB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MinimizeB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinimizeBActionPerformed(evt);
            }
        });
        LoginPanel.add(MinimizeB, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 20, 20));
        LoginPanel.add(MinimizeL, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 20, 20));
        LoginPanel.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 480));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LoginLateralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(LoginPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LoginLateralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(LoginPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BurgerButonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BurgerButonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BurgerButonActionPerformed

    private void ExitBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitBActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_ExitBActionPerformed

    private void UserTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UserTFActionPerformed

    private void MinimizeBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinimizeBActionPerformed
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_MinimizeBActionPerformed

    private void QuitBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QuitBActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_QuitBActionPerformed

    private void LoginBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginBActionPerformed
        // TODO add your handling code here:
        String Password = PasswordPF.getText();
        ReturnUsuario ru = new ReturnUsuario("");
        String User = ru.getUsuarioConvertido();
        User=UserTF.getText();
        
        try {
            vL.validData(Password,ru,User, UserTF, this);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JavaLayerException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_LoginBActionPerformed

    private void UserManualBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserManualBActionPerformed
      UserManual c=new UserManual();
      c.setVisible(true);
// TODO add your handling code here:
    }//GEN-LAST:event_UserManualBActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton BurgerButon;
    private javax.swing.JLabel BurgerMenuB;
    private javax.swing.JButton ExitB;
    private javax.swing.JLabel ExitL;
    private javax.swing.JButton LoginB;
    private javax.swing.JPanel LoginLateralPanel;
    private javax.swing.JPanel LoginPanel;
    private javax.swing.JLabel LogoL;
    private generalFunctionalities.PanelRound LogoPanel;
    private javax.swing.JLabel MaximizeL;
    private javax.swing.JButton MinimizeB;
    private javax.swing.JLabel MinimizeL;
    private javax.swing.JLabel PasswordL;
    private javax.swing.JPasswordField PasswordPF;
    private generalFunctionalities.PanelRound PutDataPanel;
    private javax.swing.JButton QuitB;
    private javax.swing.JLabel UserL;
    private javax.swing.JButton UserManualB;
    private javax.swing.JTextField UserTF;
    private generalFunctionalities.PanelRound panelRound1;
    // End of variables declaration//GEN-END:variables
public class Usuario {
        private String usuarios;
        public Usuario() {
    }
        public void setUsuarios(String usuarios) {
            this.usuarios = usuarios;
        }

        public String getUsuarios() {
            return usuarios;
        }
    }

    public class ReturnUsuario extends Usuario {
        public ReturnUsuario(String usuarios) {
            setUsuarios(usuarios);
        }

        // Convertir
        public String getUsuarioConvertido() {
            return getUsuarios();
        }
    }
}
