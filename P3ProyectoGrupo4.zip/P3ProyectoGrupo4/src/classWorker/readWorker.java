package classWorker;

import generalFunctionalities.initializeMongo;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class readWorker extends initializeMongo{
    public void loadDataWorker(JTable WorkersTable){
        openMongo();
        MongoDatabase db=getDatabase();
        MongoCollection<Document> collection = db.getCollection("Vendedores");
        FindIterable<Document> documents =collection.find();
        DefaultTableModel model=new DefaultTableModel();
        model.setColumnIdentifiers(new String []{"Contraseña","Cedula","Usuario","Cargo"});    
        for(Document document : documents){
            Vector<Object> Row = new Vector<>();
            Row.add(document.getString("CódigoUsuario:"));
            Row.add(document.getString("Cedula"));
            Row.add(document.getString("Usuario:"));
            Row.add(document.getString("Cargo:"));
            model.addRow(Row);
            }WorkersTable.setModel(model);
    }
}
