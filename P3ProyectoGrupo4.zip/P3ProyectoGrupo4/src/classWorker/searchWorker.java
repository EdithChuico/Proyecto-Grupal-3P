package classWorker;
import generalFunctionalities.initializeMongo;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class searchWorker extends initializeMongo{
 public void validData(String idSearch,JTable updateTable ){
   try{
        if (!idSearch.matches("\\d{10}")) {
          JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }} catch (NumberFormatException e) {
         JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    } 
   searchWorker( idSearch, updateTable);
 }
 public void searchWorker(String idSearch,JTable updateTable){
     openMongo();
     MongoDatabase db=getDatabase();
     MongoCollection<Document> collection = db.getCollection("Vendedores");
     Document query = new Document("Cedula", idSearch);
     long count= collection.countDocuments(query);
     if(count<=0){
        JOptionPane.showMessageDialog(null, "La cedula ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
        return;     
     }else{
        DefaultTableModel tableModel = (DefaultTableModel) updateTable.getModel();
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String []{"Contraseña","Cedula","Usuario","Cargo"});
        FindIterable<Document> documents = collection.find(query);
        for (Document document : documents) {
           tableModel.addRow(new Object[]{
            document.get("CódigoUsuario:"),
            document.get("Cedula"),
            document.get("Usuario:"),
            document.get("Cargo:")
           });}
         updateTable.setModel(tableModel);
         updateTable.revalidate();
         updateTable.repaint();
     }
 }
}
