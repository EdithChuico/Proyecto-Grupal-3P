package classWorker;
import generalFunctionalities.initializeMongo;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class updateWorker extends initializeMongo{
    public void validData(JTable updateTable, String idSearch,String nameNew,JTextField newName1,JTextField uptadeId1,JTextField newPasword){
     if (!nameNew.matches("[A-Za-z]{1,7}")) {
            JOptionPane.showMessageDialog(null, "El usuario debe de contener maximo 7 letras", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
      try{
        if (!idSearch.matches("\\d{10}")) {
          JOptionPane.showMessageDialog(null, "Ingrese una cedula válida(10 números)", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }} catch (NumberFormatException e) {
         JOptionPane.showMessageDialog(null, "Ingrese una cedula (solamente números)", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    }   
      updateWorkers(updateTable, idSearch, nameNew, newName1, uptadeId1, newPasword);
    }
    public void updateWorkers(JTable updateTable,String idSearch,String nameNew,JTextField newName1,JTextField uptadeId1,JTextField newPasword){
     openMongo();
     MongoDatabase db=getDatabase();
     MongoCollection<Document> collection = db.getCollection("Vendedores");
     Document query = new Document("Cedula", idSearch);
     long count= collection.countDocuments(query);
     if(count<=0){
        JOptionPane.showMessageDialog(null, "La cedula ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
        return;     
     }else{
        Document act= new Document("$set",new Document("Usuario:", nameNew));
        collection.updateOne(query, act);
        JOptionPane.showMessageDialog(null, "Usuario actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
        cleanTextField( updateTable,newName1, uptadeId1, newPasword);
     }
    }
    public void cleanTextField(JTable updateTable,JTextField newName1,JTextField uptadeId1,JTextField newPasword){
     newName1.setText("");
     uptadeId1.setText("");
     newPasword.setText("");
     DefaultTableModel model1 = (DefaultTableModel) updateTable.getModel();
    model1.setRowCount(0);
    }
}
