package classWorker;
import javax.swing.JOptionPane;

public class workerClosed {
    //Se importa el java.awt.Component componente ya es quien nos va a permitir cerrar la ventana
  public void backPanel( java.awt.Component componente){
    int respuesta = JOptionPane.showConfirmDialog(componente, "Se eliminaran todos los datos no guardados, ¿está seguro que desea continuar?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            cerrarVentana(componente);
            
        }
    }
    private static void cerrarVentana(java.awt.Component componente) {
        if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }
    }
}
