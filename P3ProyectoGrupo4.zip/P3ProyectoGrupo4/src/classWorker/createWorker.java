
package classWorker;
import Observer.llenarCampos;
import generalFunctionalities.initializeMongo;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;
public class createWorker extends initializeMongo{
    //Instanciación de la clase llenarCampos
    //Mediator: Este tipo de patrón de diseño consiste en generar un objeto o método para poder dar 
    //mediación entre clases o funciones, un ejemplo claro de la aplicación de este patrón es las validaciones, 
    //enseñándonos que dependiendo cómo actúe el usuario el mediador dará la orden para actuar del modo requerido, 
    //como se ve en el ejemplo a continuación
    llenarCampos lC= new llenarCampos();
    //Método utilizado para validar los datos ingresados
    public void validateEnteredDataWorker(String newUser,JTextField UserNew, String newID,JTextField idNew,String newPasword,String newPasword1 ,JTextField passwordNew, JTextField passwordNew1,String newProfess){
      if (newUser.isEmpty() || newID.isEmpty() ||newPasword.isEmpty() || newPasword1.isEmpty() || newProfess.isEmpty()) {
           //Llamado del método llenarCampos (ejemplo de observer)
          lC.llenarCampos();
          return;}
    if (!newPasword.matches("[A-Z]\\d{4}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra mayuscula seguida de cuatro números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    try{
        if (!newID.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
            return;
    }} catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!newPasword.equals(newPasword1)){
        JOptionPane.showMessageDialog(null, "Las contraseñas ingresadas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
           passwordNew.setText("");
           passwordNew1.setText("");
        return;
    }
     if (!newUser.matches("[A-Za-z]{1,7}")) {
            JOptionPane.showMessageDialog(null, "El usuario debe de contener maximo 7 letras", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
     //Luego de las validaciones se llama al método en donde se guardarán los datos
     saveMongoWorker( newUser, UserNew,  newID, idNew, newPasword, newPasword1 , passwordNew,  passwordNew1, newProfess);
    }
    public void saveMongoWorker(String newUser,JTextField UserNew, String newID,JTextField idNew,String newPasword,String newPasword1 ,JTextField passwordNew, JTextField passwordNew1,String newProfess){
        openMongo();
        MongoDatabase db=getDatabase();
        MongoCollection<Document> collection = db.getCollection("Vendedores");
        Document filter = new Document("Usuario:", newUser);
        Document query = new Document("CódigoUsuario:", newPasword);
        FindIterable<Document> result = collection.find(filter);
        FindIterable<Document> results = collection.find(query);
        if (result.iterator().hasNext()) {
            JOptionPane.showMessageDialog(null, "Los datos ingresados ya existen dentro del registro, porfavor, ingrese datos distintos", "Error", JOptionPane.ERROR_MESSAGE);                    return;
        } 
        if (results.iterator().hasNext()) {
         JOptionPane.showMessageDialog(null, "Los datos ingresados ya existen dentro del registro, porfavor, ingrese datos distintos", "Error", JOptionPane.ERROR_MESSAGE);                    return;
        } else {    
         Document documents= new Document().append("CódigoUsuario:", newPasword).append("Usuario:", newUser).append("Cargo:", newProfess).append("Cedula", newID);
         collection.insertOne(documents);
         JOptionPane.showMessageDialog(null, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
        cleanTextField( UserNew, idNew , passwordNew,  passwordNew1);
        
    }
    public void cleanTextField(JTextField UserNew,JTextField idNew ,JTextField passwordNew, JTextField passwordNew1){
      UserNew.setText("");
      idNew.setText("");
      passwordNew.setText("");
      passwordNew1.setText("");  
    }
    
}
