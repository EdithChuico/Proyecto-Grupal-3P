package classWorker;
import generalFunctionalities.initializeMongo;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class deleteWorker extends initializeMongo{
   public void deleteWorker(JTable updateTable,String idSearch,JTextField newPasword,JTextField uptadeId1,JTextField newName1){
    openMongo();
    MongoDatabase db=getDatabase();
    MongoCollection<Document> collection = db.getCollection("Vendedores");
    Document query = new Document("Cedula", idSearch);
    collection.deleteOne(query);
    JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
    cleanTextField(  updateTable,newPasword, uptadeId1, newName1);
   }
   public void cleanTextField(JTable updateTable,JTextField newPasword,JTextField uptadeId1,JTextField newName1){
    newPasword.setText("");
    uptadeId1.setText("");
    newName1.setText("");
    DefaultTableModel model1 = (DefaultTableModel) updateTable.getModel();
    model1.setRowCount(0);
   }
           
}
