/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import java.awt.Component;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class enterData {
    public void validDataComboBox(JComboBox SBillTypeCB,JPanel LockedPanel,JTextField SBCNameTF,JTextField SBCPhoneTF,JTextField SBCidTF ){
     String TypeBill = (String) SBillTypeCB.getSelectedItem();

        // Verificar si la opción seleccionada es "Consumidor Final"Seleccione
        if ("Seleccione".equals(TypeBill)) {
            // Bloquear el panel "LockedPanel"
            for (Component component : LockedPanel.getComponents()) {
               component.setEnabled(false); 
            }
            
        } else if("Consumidor Final".equals(TypeBill)){
            for (Component component : LockedPanel.getComponents()) {
               component.setEnabled(false); 
            }
            cleanJtextFields( SBCNameTF, SBCPhoneTF, SBCidTF);
        }else{
            // Desbloquear el panel "LockedPanel"
            for (Component component : LockedPanel.getComponents()) {
               component.setEnabled(true); 
            }   
    }
}

public void cleanJtextFields(JTextField SBCNameTF,JTextField SBCPhoneTF,JTextField SBCidTF){
SBCNameTF.setText("");
            SBCPhoneTF.setText("");
            SBCidTF.setText("");
}
}