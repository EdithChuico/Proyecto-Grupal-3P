/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JLabel;
import javax.swing.JTextField;
import org.bson.Document;

public class saveFor {
    initializeMongo iM=new initializeMongo();
 public void buscarPorCedula(String cedula, JLabel FindValidation,  JTextField SBCNameTF,JTextField SBCPhoneTF,JTextField SBCidTF) {
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("RegistroClientes");
        Document queryID = new Document("Cedula", cedula);
            FindIterable<Document> documents = collection.find(queryID);
            if (documents.iterator().hasNext()) {
                for (Document document : documents) {
                    SBCNameTF.setText(document.getString("Nombre"));
                    SBCPhoneTF.setText(document.getString("Teléfono"));
                    SBCidTF.setText(document.getString("Cedula"));
                }
                FindValidation.setText("¡Resultado encontrado!");
            } else {
                FindValidation.setText("¡Resultado no encontrado!");
            }
 }
 public void buscarPorNombre(String nombre, JLabel FindValidation,  JTextField SBCNameTF,JTextField SBCPhoneTF,JTextField SBCidTF) {
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("RegistroClientes");

    Document queryNombre = new Document("Nombre", nombre);

    FindIterable<Document> documents = collection.find(queryNombre);

    if (documents.iterator().hasNext()) {
                for (Document document : documents) {
                   SBCNameTF.setText(document.getString("Nombre"));
                   SBCPhoneTF.setText(document.getString("Teléfono"));
                   SBCidTF.setText(document.getString("Cedula"));
                }
                FindValidation.setText("¡Resultado encontrado!");
            } else {
                FindValidation.setText("¡Resultado no encontrado!");
            }
    }
}

