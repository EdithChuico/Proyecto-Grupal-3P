/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import java.util.Locale;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.ERROR_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class DescountData {
    DescountValue dv=new DescountValue();
    Descount dc=new Descount();
    public void descData(String Descount, JLabel finaaal, JTextField Des){
         if(finaaal.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"No hay un total al cual asignar descuento","Error",ERROR_MESSAGE);
            return;
        }
        if(!Des.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Ya ha sido asignado un descuento","Error",ERROR_MESSAGE);
            return;
        }
        double total=Double.parseDouble(finaaal.getText());
        double ProcentDes=dv.descountValue(Descount);
        double trueDes=dc.descount(total, ProcentDes);
        Des.setText(String.format(Locale.US,"%.2f",trueDes));
        finaaal.setText(String.format(Locale.US,"%.2f",trueDes));
        JOptionPane.showMessageDialog(null,"Descuento Asignado","Aviso",INFORMATION_MESSAGE);
    }
}
