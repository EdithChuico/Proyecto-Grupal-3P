/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author Usuario
 */
public class deleteDressing {
    public void DeleteDressingB2( String idSearch, JTextField MFindTF2, JTextField MModifyTF2, JTextField MModifyTF4, JTable updateProducts1) {
    String dir = "mongodb://localhost:27017";
    MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
    MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
    MongoCollection<Document> collection = database.getCollection("Aderezos");
    Document query = new Document("Código:", idSearch);
    collection.deleteOne(query);
    JOptionPane.showMessageDialog(null, "Aderezo eliminado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

    MFindTF2.setText("");
    MModifyTF2.setText("");
    MModifyTF4.setText("");
    DefaultTableModel model = (DefaultTableModel) updateProducts1.getModel();
    model.setRowCount(0);
}
}
