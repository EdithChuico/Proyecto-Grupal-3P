/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author Usuario
 */
public class deleteDressing {
    initializeMongo iM=new initializeMongo();
    pasarSaboresBox pSB=new pasarSaboresBox();
    public void DeleteDressingB2( String idSearch, JTextField MFindTF2, JTextField MModifyTF2, JTextField MModifyTF4, JTable updateProducts1, JComboBox ToppingShop) {
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("Aderezos");
    Document query = new Document("Código:", idSearch);
    collection.deleteOne(query);
    JOptionPane.showMessageDialog(null, "Aderezo eliminado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

    deleteText(MFindTF2,MModifyTF2,MModifyTF4);   
    DefaultTableModel model = (DefaultTableModel) updateProducts1.getModel();
    model.setRowCount(0);
    pSB.añadirProdComboBox(ToppingShop);
}
    public void deleteText(JTextField MFindTF2, JTextField MModifyTF2, JTextField MModifyTF4){
    MFindTF2.setText("");
    MModifyTF2.setText("");
    MModifyTF4.setText("");
    
    }
}
