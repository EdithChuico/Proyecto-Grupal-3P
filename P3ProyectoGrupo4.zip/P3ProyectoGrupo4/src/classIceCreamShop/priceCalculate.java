/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;


import java.util.Locale;
import javax.swing.JLabel;


/**
 *
 * @author USER
 */
public class priceCalculate {

    public void prize(float Prize, float PrizeIce, JLabel totalfinal, JLabel SBOIVAResultP,JLabel finaaal){
        float totalPrize=Prize+PrizeIce;
        String totalPrizes = String.format(Locale.US,"%.2f",totalPrize);
        totalfinal.setText(totalPrizes);
        double iva=totalPrize*0.12;
                    SBOIVAResultP.setText(String.format(Locale.US,"%.2f",iva));
                    double finale=totalPrize+iva;
                    finaaal.setText(String.format(Locale.US,"%.2f",finale));
        }
}
