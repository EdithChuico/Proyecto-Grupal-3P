/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class createTopping {
   public void validData(String Product,String Code,String Quantity,JTextField SNameTF,JTextField SQuantityTF,JTextField SCodeTF){
    if (Product.isEmpty() || Code.isEmpty() ||Quantity.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        if (!Product.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(null, "Ingrese un nombre valido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!Code.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stockr = Integer.parseInt(Quantity);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(null, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }   
    saveTopping(Product,Code,Quantity,SNameTF,SQuantityTF, SCodeTF);
      
   }
   //Factory Method:Permite crear sabores y aderezos con sus respectivos códigos y cantidades en la interfaz iceCreamShop,
   //para posteriormente mostrar el sabor por medio de un ComboBox al momento de realizar el pedido del helado en el panel HSellsP. 
   //Codigo para la creación de un nuevo sabor(Fcatory Method)
   public void saveTopping(String Product,String Code,String Quantity,JTextField SNameTF,JTextField SQuantityTF,JTextField SCodeTF){
   //Instanciación de la clase initializeMongo
    initializeMongo iM=new initializeMongo();
    //Uso del método openMongo 
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("Aderezos"); 
    MongoCollection<Document> collectionn = database.getCollection("Inventario");
    Document query = new Document("Código:", Code);
    long count = collectionn.countDocuments(query);
    Document queryy = new Document("Producto:", Product);
    long counnt = collectionn.countDocuments(queryy);
    if( count <= 0){
    }else {
       JOptionPane.showMessageDialog(null, "El codigo ya existe dentro de los datos ingresados, por favor ingrese un codigo distinto", "Error", JOptionPane.ERROR_MESSAGE);
       return;
    }
    if( counnt <= 0){
    }else {
        JOptionPane.showMessageDialog(null, "El nombre del aderezo indicado ya existe dentro de los datos ingresados, por favor ingrese un aderezo distinto", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }       
    String resultado = Product.substring(0, 1).toUpperCase() + Product.substring(1).toLowerCase();
    Document document = new Document().append("Producto:", resultado).append("Código:", Code).append("Porciones:", Quantity);
    collection.insertOne(document);
    collectionn.insertOne(document);
    JOptionPane.showMessageDialog(null, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    cleanTextFields( SNameTF, SQuantityTF, SCodeTF);
   }
   public void cleanTextFields(JTextField SNameTF,JTextField SQuantityTF,JTextField SCodeTF){
    SNameTF.setText("");
    SQuantityTF.setText("");
    SCodeTF.setText("");
   }
}
