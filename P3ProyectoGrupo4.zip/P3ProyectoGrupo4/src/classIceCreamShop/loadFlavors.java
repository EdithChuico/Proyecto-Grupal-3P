/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class loadFlavors {
    initializeMongo iM=new initializeMongo();
    public void LoadFlavors(String Selected, JLabel MInformationL, JTable MTable){
        if(Selected=="Seleccione"){
            JOptionPane.showMessageDialog(null,"Selecciona el tipo de datos para cargar","Seleccion nula",JOptionPane.WARNING_MESSAGE);
        }else{
            if(Selected=="Sabores"){
                MInformationL.setText("Datos cargados de tipo: Sabores");
                iM.openMongo();
                iM.getDatabase();
                MongoDatabase database = iM.getDatabase();
                MongoCollection<Document> collection = database.getCollection("Sabores");

                FindIterable<Document> documents = collection.find();
                DefaultTableModel model;
                model = new DefaultTableModel();
                model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});

                for(Document document : documents){
                    Vector<Object> Row = new Vector<>();
                    Row.add(document.getString("Producto:"));
                    Row.add(document.getString("Código:"));
                    Row.add(document.getString("Porciones:"));

                    model.addRow(Row);

                }MTable.setModel(model);

            }else if(Selected =="Aderezos"){
                iM.openMongo();
                iM.getDatabase();
                MongoDatabase database = iM.getDatabase();
                MongoCollection<Document> collection = database.getCollection("Aderezos");

                FindIterable<Document> documents = collection.find();
                DefaultTableModel model;
                model = new DefaultTableModel();
                model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});

                for(Document document : documents){
                    Vector<Object> Row = new Vector<>();
                    Row.add(document.getString("Producto:"));
                    Row.add(document.getString("Código:"));
                    Row.add(document.getString("Porciones:"));

                    model.addRow(Row);

                }MTable.setModel(model);
                MInformationL.setText("Datos cargados de tipo: Aderezos");
            }
        }
    }
}
