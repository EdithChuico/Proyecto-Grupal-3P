/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class updateamountFlavors {
    initializeMongo iM=new initializeMongo();
    public void amountFlavors(JTable updateProducts,String quantiNew, String idSearch,JTextField MFindTF, JTextField MModifyTF, JTextField MModifyTF2){
        validFlavor(updateProducts,quantiNew, idSearch);
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Inventario");
        MongoCollection<Document> collectionn = database.getCollection("Sabores");

        Document query = new Document("Código:", idSearch);
        long count= collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(null, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            Document act= new Document("$set",new Document("Porciones:", quantiNew));
            collection.updateOne(query, act);
            collectionn.updateOne(query, act);
            JOptionPane.showMessageDialog(null, "Cantidad del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

        }
        cleanTextFields( updateProducts, MFindTF, MModifyTF , MModifyTF2);
    }
    public void validFlavor(JTable updateProducts,String quantiNew, String idSearch){
        if (quantiNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(null, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        try {
            int stockr = Integer.parseInt(quantiNew);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    public void cleanTextFields(JTable updateProducts,JTextField  MFindTF,JTextField MModifyTF ,JTextField MModifyTF2){
     MFindTF.setText("");
     MModifyTF.setText("");
     MModifyTF2.setText("");
     DefaultTableModel model1 = (DefaultTableModel) updateProducts.getModel();
     model1.setRowCount(0);
 }
}
