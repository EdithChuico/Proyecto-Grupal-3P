/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class toppingChosen {
    initializeMongo iM=new initializeMongo();
    totalPortionsC tPC=new totalPortionsC();
    public void ToppingChosen(String ProductSelected1, JComboBox PortionsSelected2, JTable jTable2, JTable OrderTable, JComboBox iceCream, JLabel totalfinal, JLabel SBOIVAResultP, JLabel finaaal) {
    if (ProductSelected1.isEmpty() || PortionsSelected2.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(null, "Llene todos los campos", "Error", JOptionPane.INFORMATION_MESSAGE);
        return;
    }

    if (!PortionsSelected2.getSelectedItem().toString().matches("([1-7])")) {
        JOptionPane.showMessageDialog(null, "Ingrese un valor numérico para la cantidad (Máximo 7)", "Error", JOptionPane.ERROR_MESSAGE);
        PortionsSelected2.setSelectedIndex(-1);
        return;
    }

    int portionsSelected = Integer.parseInt((String) PortionsSelected2.getSelectedItem());
        MongoClient mongoClient = (MongoClient) MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionDressings = database.getCollection("Aderezos");
        Document filter=new Document("Producto:",ProductSelected1);
        Document dressings=collectionDressings.find(filter).first();
        DefaultTableModel modelTable=new DefaultTableModel();
        modelTable.addColumn("Producto");
        modelTable.addColumn("Código");
        modelTable.addColumn("Porciones");
        modelTable.addColumn("Categoría"); // TODO add your handling code here:
        if(dressings==null){
            JOptionPane.showMessageDialog(null, "Aderezo ingresado no encontrado","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(portionsSelected>7){
            JOptionPane.showMessageDialog(null, "No puede elegir más de 7 porciones de aderezo", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int portions = Integer.parseInt(dressings.getString("Porciones:"));
        String code=dressings.getString("Código:");
        int totalPortionscat = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        System.out.print(totalPortionscat);
        if(portions==0){
            JOptionPane.showMessageDialog(null, "Producto agotado", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si el producto está en 0
        }
        if(portions<portionsSelected){
            JOptionPane.showMessageDialog(null, "La cantidad de porciones elegidas sobrepasa la existente", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si la cantidad seleccionada sobrepasa a la disponible
        }
        if(totalPortionscat+portionsSelected>7){
            JOptionPane.showMessageDialog(null, "Sobrepasa la cantidad de aderezos a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(totalPortionscat>=7){
            JOptionPane.showMessageDialog(null, "Sobrepasa la cantidad de aderezos a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control para que no pase de 5 sabores totales elegidos
        }
        int Portions=portions-portionsSelected;
        String newPortions=String.valueOf(Portions);
        Document update=new Document("$set",new Document("Porciones:",newPortions));
        collectionDressings.updateOne(filter,update);//actualiza la base principal disminuyendo lo que pidio el cliente
        Document filter2=new Document("Código:",code);
        MongoCollection<Document>collection=database.getCollection("Carrito");
        Document carProducts=collection.find(filter2).first();
        System.out.print(carProducts);
        if(carProducts!=null){
            int newcarPortion =carProducts.getInteger("Porciones:") + portionsSelected;
            Document update2=new Document("$set",new Document("Porciones:",newcarPortion));
            collection.updateOne(filter2,update2);//actualiza solo la cantidad en el carrito si el cliente vuelve a elegir el mismo producto
        }else{
            Document documentCar=new Document()
            .append("Producto:",dressings.getString("Producto:"))
            .append("Código:", dressings.getString("Código:"))
            .append("Porciones:", portionsSelected)
            .append("Categoría:","Aderezos");
            collection.insertOne(documentCar);//actualiza el carrito agregando el nuevo sabor/aderezo que eligió el cliente
        }
        FindIterable<Document> documents = collection.find();
        for (Document document : documents) {
            String[] dataProduct = {
                document.getString("Producto:"),
                document.getString("Código:"),
                String.valueOf(document.getInteger("Porciones:")),
                document.getString("Categoría:")
            };
            modelTable.addRow(dataProduct);
        }//muestra en la tabla lo que el cliente eligió
        jTable2.setModel(modelTable);
        OrderTable.setModel(modelTable);
        JOptionPane.showMessageDialog(null, "Aderezo agregado");
        float value=(float) 0.75;
        int totalPortionscat2 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        int totalPortionscat3 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        float Prize=(totalPortionscat2+totalPortionscat3)*value;
        String cream=iceCream.getSelectedItem().toString();
        float PrizeIce=0;
        if(cream=="Vasito"){
            PrizeIce=1;
        }else{
            if(cream=="Conito"){
                PrizeIce=(float) 1.25;
            }else{
                if(cream=="Paleta"){
                    PrizeIce=(float) 0.50;
                }else{
                    PrizeIce=2;
                }
            }
        }
        float totalPrize=Prize+PrizeIce;
        String totalPrizes = String.valueOf(totalPrize);
        totalfinal.setText(totalPrizes);
        double iva=totalPrize*0.12;
                    SBOIVAResultP.setText(String.valueOf(iva));
                    double finale=totalPrize+iva;
                    finaaal.setText(String.valueOf(finale));
    }
}
