package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class readInvoices {
    public void seeInvoices(JTable RegistersTable){
    initializeMongo iM=new initializeMongo();
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("Facturas");
    FindIterable<Document> documents = collection.find();
            DefaultTableModel model;
            model = new DefaultTableModel();
    model.setColumnIdentifiers(new String[]{"Cliente", "Cedula", "Telefono", "Pago", "Pedido","Cantidad","Total"});
    for(Document document : documents){
        String[] row={
            document.getString("Cliente"),
            document.getString("Cedula"),
            document.getString("Telefono"),
            document.getString("Pago"),
            document.getString("Pedido"),
            document.getString("Cantidad"),
            document.getString("Total")
        };
        model.addRow(row);
        }
        RegistersTable.setModel(model);
}
}

