/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class flavorChosen {
    initializeMongo iM=new initializeMongo();
    totalPortionsC tPC=new totalPortionsC();
    public void FlavorChosen(String productSelected, JComboBox PortionsSelected, JTable jTable2, JTable OrderTable, JComboBox iceCream, JLabel totalfinal, JLabel SBOIVAResultP, JLabel finaaal) {
    DataValid1(productSelected,PortionsSelected);

    int portionsSelected = Integer.parseInt((String) PortionsSelected.getSelectedItem());
        iM.openMongo();
                iM.getDatabase();
                MongoDatabase database = iM.getDatabase();
                MongoCollection<Document> collectionFlavors = database.getCollection("Sabores");
        
        Document filter=new Document("Producto:",productSelected);
        Document flavors=collectionFlavors.find(filter).first();
        DefaultTableModel modelTable=new DefaultTableModel();
        modelTable.addColumn("Producto");
        modelTable.addColumn("Código");
        modelTable.addColumn("Porciones");
        modelTable.addColumn("Categoría");
        
        DataValid2(flavors);
        /*if(portionsSelected>5){
            JOptionPane.showMessageDialog(null, "No puede elegir más de 5 porciones de sabores", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }*/
        int portions = Integer.parseInt(flavors.getString("Porciones:"));
        String code=flavors.getString("Código:");
        int totalPortionscat = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        System.out.print(totalPortionscat);
        //*
        if(portions==0){
            JOptionPane.showMessageDialog(null, "Producto agotado", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si el producto está en 0
        }
        if(portions<portionsSelected){
            JOptionPane.showMessageDialog(null, "La cantidad de porciones elegidas sobrepasa la existente", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si la cantidad seleccionada sobrepasa a la disponible
        }
        if(totalPortionscat+portionsSelected>5){
            JOptionPane.showMessageDialog(null, "Sobrepasa la cantidad de sabores a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(totalPortionscat>=5){
            JOptionPane.showMessageDialog(null, "Sobrepasa la cantidad de sabores a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control para que no pase de 5 sabores totales elegidos
        }
        //*/
        //DataValid3(portions,portionsSelected,totalPortionscat);
        
        int Portions=portions-portionsSelected;
        String newPortions=String.valueOf(Portions);
        Document update=new Document("$set",new Document("Porciones:",newPortions));
        collectionFlavors.updateOne(filter,update);//actualiza la base principal disminuyendo lo que pidio el cliente
        Document filter2=new Document("Código:",code);
        MongoCollection<Document>collection=database.getCollection("Carrito");
        Document carProducts=collection.find(filter2).first();
        System.out.print(carProducts);
        if(carProducts!=null){
            int newcarPortion =carProducts.getInteger("Porciones:") + portionsSelected;
            Document update2=new Document("$set",new Document("Porciones:",newcarPortion));
            collection.updateOne(filter2,update2);//actualiza solo la cantidad en el carrito si el cliente vuelve a elegir el mismo producto
        }else{
            Document documentCar=new Document()
            .append("Producto:",flavors.getString("Producto:"))
            .append("Código:", flavors.getString("Código:"))
            .append("Porciones:", portionsSelected)
            .append("Categoría:","Sabores");
            collection.insertOne(documentCar);//actualiza el carrito agregando el nuevo sabor/aderezo que eligió el cliente
        }
        FindIterable<Document> documents = collection.find();
        for (Document document : documents) {
            String[] dataProduct = {
                document.getString("Producto:"),
                document.getString("Código:"),
                String.valueOf(document.getInteger("Porciones:")),
                document.getString("Categoría:")
            };
            modelTable.addRow(dataProduct);
        }//muestra en la tabla lo que el cliente eligió
        jTable2.setModel(modelTable);
        OrderTable.setModel(modelTable);
        JOptionPane.showMessageDialog(null, "Sabor agregado");
        float value=(float) 1.0;
        int totalPortionscat2 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        int totalPortionscat3 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        float Prize=(totalPortionscat2+totalPortionscat3)*value;
        String cream=iceCream.getSelectedItem().toString();
        float PrizeIce=0;
        if(cream=="Vasito"){
            PrizeIce=1;
        }else{
            if(cream=="Conito"){
                PrizeIce=(float) 1.25;
            }else{
                if(cream=="Paleta"){
                    PrizeIce=(float) 0.50;
                }else{
                    PrizeIce=2;
                }
            }
        }
        /*float totalPrize=Prize+PrizeIce;
        
        String totalPrizes = String.valueOf(totalPrize);
        totalfinal.setText(totalPrizes);
                    double iva=totalPrize*0.12;
                    SBOIVAResultP.setText(String.valueOf(iva));
                    double finale=totalPrize+iva;
                    finaaal.setText(String.valueOf(finale));*/
        priceCalculate pC=new priceCalculate();
        pC.prize(Prize, PrizeIce, totalfinal, SBOIVAResultP, finaaal);
        
    }
    public void DataValid1(String productSelected, JComboBox PortionsSelected){
        if (productSelected.isEmpty() || PortionsSelected.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(null, "Llene todos los campos", "Error", JOptionPane.INFORMATION_MESSAGE);
        return;
    }

    if (!PortionsSelected.getSelectedItem().toString().matches("([1-5])")) {
        JOptionPane.showMessageDialog(null, "Ingrese un valor numérico para la cantidad (Máximo 5)", "Error", JOptionPane.ERROR_MESSAGE);
        PortionsSelected.setSelectedIndex(-1);
        return;
    }
    }
    public void DataValid2(Document flavors){
        if(flavors==null){
            JOptionPane.showMessageDialog(null, "Sabor ingresado no encontrado","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    public void DataValid3(int portions, int portionsSelected, int totalPortionscat){
        if(portions==0){
            JOptionPane.showMessageDialog(null, "Producto agotado", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si el producto está en 0
        }
        if(portions<portionsSelected){
            JOptionPane.showMessageDialog(null, "La cantidad de porciones elegidas sobrepasa la existente", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si la cantidad seleccionada sobrepasa a la disponible
        }
        if(totalPortionscat+portionsSelected>5){
            JOptionPane.showMessageDialog(null, "Sobrepasa la cantidad de sabores a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(totalPortionscat>=5){
            JOptionPane.showMessageDialog(null, "Sobrepasa la cantidad de sabores a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control para que no pase de 5 sabores totales elegidos
        }
    }
}
