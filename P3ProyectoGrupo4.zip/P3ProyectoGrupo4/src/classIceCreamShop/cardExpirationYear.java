/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import java.awt.Color;
import javax.swing.JLabel;

/**
 *
 * @author USER
 */
public class cardExpirationYear {
    public void ExpirationYear(String CExpiration, JLabel ValidationCEMM){
        if (CExpiration.isEmpty()) {
            ValidationCEMM.setText("¡Este campo es obligatorio!");
            ValidationCEMM.setForeground(Color.RED);
        } else if (!CExpiration.matches("^(1[5-9]|2[0-8])$")) {
            ValidationCEMM.setText("El año no es válido");
            ValidationCEMM.setForeground(Color.RED);
        } else {
            ValidationCEMM.setText("");
        }
    }
}
