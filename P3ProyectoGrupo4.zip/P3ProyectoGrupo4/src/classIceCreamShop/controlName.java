/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.Color;
import org.bson.Document;
import generalFunctionalities.initializeMongo;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class controlName {
    initializeMongo iM=new initializeMongo();
    public void SBCNameTF(String NameClient, JLabel SBCValidation1){
        if(NameClient.isEmpty()){
            SBCValidation1.setText("¡Este campo es obligatorio!");
            SBCValidation1.setForeground(Color.RED);
        }else{
                controlName(NameClient, SBCValidation1);
        }
    }
    public void controlName(String NameClient, JLabel SBCValidation1){
                iM.openMongo();
                iM.getDatabase();
                MongoDatabase database = iM.getDatabase();
                MongoCollection<Document> collection = database.getCollection("RegistroClientes");
                Document query = new Document("Nombre",NameClient);
                
                FindIterable<Document> documents = collection.find(query);
                
                if(documents.iterator().hasNext()){
                    SBCValidation1.setText("Este nombre ya esta en uso, ingresa otro para registrar");
                    SBCValidation1.setForeground(Color.RED);
                }else{
                    SBCValidation1.setText("");
                }
    }
}
