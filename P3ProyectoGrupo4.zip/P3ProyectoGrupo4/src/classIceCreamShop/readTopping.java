package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class readTopping {
    //En el siguiente código podemos entender como se ha utilizado la misma función “LoadDataSuplies”
    //para poder presentar una información dentro de una tabla o Jtable, al cambiar su variable 
    //haremos que se presenten dentro de una tabla distinta
    
    //Estos son los métodos para colocar la información dentro de las tablas y como vimos al principio 
    //del ejemplo, solo es cuestión de cambiar la variable de la tabla de la que deseamos ver los datos leídos.
  public void LoadDataSuplies(JTable STable){
        initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        FindIterable<Document> documents = collection.find();
        DefaultTableModel model;
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});
        for(Document document : documents){
            Vector<Object> Row = new Vector<>();
            Row.add(document.getString("Producto:"));
            Row.add(document.getString("Código:"));
            Row.add(document.getString("Porciones:"));
             
            model.addRow(Row);
               
        }STable.setModel(model);        
}
}
