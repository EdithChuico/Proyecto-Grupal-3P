package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import interfazGUI.Ofert;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import org.bson.Document;
//Ejemplo de chain of Responsability
public class saveClient {
    initializeMongo iM=new initializeMongo(); 
    readCart rC=new readCart();
 //Chain of Responsability: Se usa para identificar el método de pago elegido por el cliente el cual pasará por cada uno de los 
 //manejadores hasta que se ubique en el que represente al método de pago seleccionado
  public void validData(String selectedBill,String nameClient,String phoneClient,String paymentClient,String idClient ,JLabel SBCValidation1,JLabel SBCValidation2, JLabel SBCValidation3,JLabel SBCValidation4, JTable jTable2,JTable OrderTable, JTextField iceCreamtype,JTextField PortionsDelete, JComboBox iceCream,JLabel finaaal,JLabel totalfinal, JLabel SBOIVAResultP,JRadioButton RegisterYes,JRadioButton RegisterNo){
      paymentMethod pM=new paymentMethod();
    pM.SPayment(selectedBill, SBCValidation4, null);
      
//Validación en caso de que el dato seleccionado sea "Seleccione"
    if ("Seleccione".equals(selectedBill)) {
        JOptionPane.showMessageDialog(null, "Seleccione el tipo de consumidor para guardar la factura", "Tipo de factura inválido", JOptionPane.ERROR_MESSAGE);
        return;
    }   //Validación en caso de que el dato seleccionado sea "Consumidor Final"
    if ("Consumidor Final".equals(selectedBill)) {
        //Si el dato escogido es Consumidor Final se llmaará al método  "consumidorFinal"
        consumidorFinal(  nameClient, phoneClient, paymentClient, idClient , SBCValidation1, SBCValidation2,  SBCValidation3, SBCValidation4,  jTable2, OrderTable,  iceCreamtype, PortionsDelete,  iceCream, finaaal, totalfinal,  SBOIVAResultP, RegisterYes, RegisterNo);
        //Validación en caso de que el dato seleccionado sea "Datos"   
    }
    if ("Datos".equals(selectedBill)) {  
       //Si el dato escogido es Datos se llmaará al método  "validDatos"
        validDatos(  nameClient, phoneClient, paymentClient, idClient , SBCValidation1, SBCValidation2,  SBCValidation3, SBCValidation4,  jTable2, OrderTable,  iceCreamtype, PortionsDelete,  iceCream, finaaal, totalfinal,  SBOIVAResultP, RegisterYes, RegisterNo);
    }
  }
  
  public void consumidorFinal(String nameClient,String phoneClient,String paymentClient,String idClient ,JLabel SBCValidation1,JLabel SBCValidation2, JLabel SBCValidation3,JLabel SBCValidation4, JTable jTable2,JTable OrderTable, JTextField iceCreamtype,JTextField PortionsDelete, JComboBox iceCream,JLabel finaaal,JLabel totalfinal, JLabel SBOIVAResultP,JRadioButton RegisterYes,JRadioButton RegisterNo ){
    if (OrderTable.getRowCount() == 0) {
    JOptionPane.showMessageDialog(null, "No hay productos para crear la factura, inserta al menos 1", "Sin productos para la factura", JOptionPane.WARNING_MESSAGE);
    } else {
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("Facturas");
    Document nuevaFactura = new Document().append("Cliente", "Consumidor Final").append("Cedula", "9999999999")
    .append("Telefono", "0999999999").append("Pago", "Efectivo").append("Producto", iceCreamtype.getText())
    .append("Cantidad", "1").append("Total", finaaal.getText());
    collection.insertOne(nuevaFactura);
    MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
    carritoCollection.drop();
    JOptionPane.showMessageDialog(null, "Factura registrada exitosamente", "Factura guardada", JOptionPane.INFORMATION_MESSAGE);
    clearTextFields(  jTable2, OrderTable,  iceCreamtype, PortionsDelete,  iceCream, finaaal, totalfinal,  SBOIVAResultP);
    }
}
  
public void datos(String nameClient,String phoneClient,String paymentClient,String idClient ,JLabel SBCValidation1,JLabel SBCValidation2, JLabel SBCValidation3,JLabel SBCValidation4, JTable jTable2,JTable OrderTable, JTextField iceCreamtype,JTextField PortionsDelete, JComboBox iceCream,JLabel finaaal,JLabel totalfinal, JLabel SBOIVAResultP,JRadioButton RegisterYes,JRadioButton RegisterNo){
   iM.openMongo();
   iM.getDatabase();
    MongoDatabase database = iM.getDatabase();   
        if (RegisterYes.isSelected()) {
                            // Registrar el usuar
        MongoCollection<Document> clienteCollection = database.getCollection("RegistroClientes");
        // Validar que no exista el cliente
        Document queryID = new Document("Cedula", idClient);
        FindIterable<Document> documents = clienteCollection.find(queryID);
        if (documents.iterator().hasNext()) {
        JOptionPane.showMessageDialog(null, "El cliente ingresado ya existe en la base, no se registrará", "Cliente existente", JOptionPane.INFORMATION_MESSAGE);
        } else {
            Document nuevoCliente = new Document().append("Nombre", nameClient).append("Cedula", idClient).append("Teléfono", phoneClient);
            clienteCollection.insertOne(nuevoCliente);
            }
            String totalValue = totalfinal.getText();
            String finaalValue = finaaal.getText();
            double finaalDouble = Double.parseDouble(finaalValue);
            if(finaalDouble>5){
            Ofert e= new Ofert();
            e.setVisible(true);
            e.setLocationRelativeTo(null);
            double result = finaalDouble - (0.10 * finaalDouble);
            finaaal.setText(String.valueOf(result));
                    }
           MongoCollection<Document> facturaCollection = database.getCollection("Facturas");
           Document nuevaFactura = new Document().append("Cliente", nameClient).append("Cedula", idClient).append("Telefono", phoneClient)
           .append("Pago", paymentClient).append("Producto", iceCreamtype.getText()).append("Cantidad", "1").append("Total", finaaal.getText());
           facturaCollection.insertOne(nuevaFactura);
           MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
           carritoCollection.drop();
           JOptionPane.showMessageDialog(null, "Factura guardada en la base", "Guardado de factura exitoso", JOptionPane.INFORMATION_MESSAGE);
           clearTextFields(  jTable2, OrderTable,  iceCreamtype, PortionsDelete,  iceCream, finaaal, totalfinal,  SBOIVAResultP);
       } else if (RegisterNo.isSelected()) {
        MongoCollection<Document> facturaCollection = database.getCollection("Facturas");
        Document nuevaFactura = new Document().append("Cliente", nameClient).append("Cedula", idClient).append("Telefono", phoneClient)
        .append("Pago", paymentClient).append("Producto", iceCreamtype.getText()).append("Cantidad", "1").append("Total", finaaal.getText());
        facturaCollection.insertOne(nuevaFactura);
        MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
        carritoCollection.drop();
        JOptionPane.showMessageDialog(null, "Factura guardada en la base", "Guardado de factura exitoso", JOptionPane.INFORMATION_MESSAGE);
       clearTextFields(  jTable2, OrderTable,  iceCreamtype, PortionsDelete,  iceCream, finaaal, totalfinal,  SBOIVAResultP);
        }  
}

 public void validDatos(String nameClient,String phoneClient,String paymentClient,String idClient ,JLabel SBCValidation1,JLabel SBCValidation2, JLabel SBCValidation3,JLabel SBCValidation4, JTable jTable2,JTable OrderTable, JTextField iceCreamtype,JTextField PortionsDelete, JComboBox iceCream,JLabel finaaal,JLabel totalfinal, JLabel SBOIVAResultP,JRadioButton RegisterYes,JRadioButton RegisterNo){
 
     if (nameClient.isEmpty() || phoneClient.isEmpty() || idClient.isEmpty() ) {
                    JOptionPane.showMessageDialog(null, "Ingresa datos para los campos", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
                    SBCValidation1.setText("¡Este campo es obligatorio!");
                    SBCValidation2.setText("¡Este campo es obligatorio!");
                    SBCValidation3.setText("¡Este campo es obligatorio!");
                    SBCValidation4.setText("¡Selecciona un método de pago válido!");
                    SBCValidation1.setForeground(Color.RED);
                    SBCValidation2.setForeground(Color.RED);
                    SBCValidation3.setForeground(Color.RED);
                    SBCValidation4.setForeground(Color.RED);
                } 
        if (!nameClient.matches("([a-zA-Z]+\\s){3}[a-zA-Z]+")) {
        JOptionPane.showMessageDialog(null, "Ingrese un nombre válido con 2 Apellidos y 2 Nombres", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        if (nameClient.matches("d")) {
            JOptionPane.showMessageDialog(null, "Ingrese un nombre valido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (OrderTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "No hay productos para crear la factura, inserta al menos 1", "Sin productos para la factura", JOptionPane.WARNING_MESSAGE);
            return;
        }
        datos(  nameClient, phoneClient, paymentClient, idClient , SBCValidation1, SBCValidation2,  SBCValidation3, SBCValidation4,  jTable2, OrderTable,  iceCreamtype, PortionsDelete,  iceCream, finaaal, totalfinal,  SBOIVAResultP, RegisterYes, RegisterNo);
          
     
 }
 
 public void clearTextFields( JTable jTable2,JTable OrderTable, JTextField iceCreamtype,JTextField PortionsDelete, JComboBox iceCream,JLabel finaaal,JLabel totalfinal, JLabel SBOIVAResultP){
    totalfinal.setText("");
    SBOIVAResultP.setText("");
    finaaal.setText("");
    rC.updateTable(jTable2,OrderTable,iceCreamtype ,PortionsDelete,iceCream);   
 }
         
}
