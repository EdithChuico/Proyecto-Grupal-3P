/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.awt.Color;
import javax.swing.JLabel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class controlID {
  initializeMongo iM=new initializeMongo();
public void SBCidTF(String IDClient, JLabel SBCValidation3, String PhoneClient){
    if(IDClient.isEmpty()){
            SBCValidation3.setText("¡Este campo es obligatorio!");
            SBCValidation3.setForeground(Color.RED);
        }else{
            if(IDClient.length()!=10 || IDClient==PhoneClient){
                SBCValidation3.setText("La cedula debe tener 10 digitos numericos y ser diferente al telefono");
            }else{
                procesID(IDClient, SBCValidation3);
            }
        }      
}
public void procesID(String IDClient, JLabel SBCValidation3){
    iM.openMongo();
                iM.getDatabase();
                MongoDatabase database = iM.getDatabase();
                MongoCollection<Document> collection = database.getCollection("RegistroClientes");
                        Document query = new Document("Cedula",IDClient);

                        FindIterable<Document> documents = collection.find(query);

                        if(documents.iterator().hasNext()){
                            SBCValidation3.setText("Esta cedula ya esta en uso, ingresa otra para registrar");
                            SBCValidation3.setForeground(Color.RED);
                        }else{
                            SBCValidation3.setText("");
                        }
}
}
