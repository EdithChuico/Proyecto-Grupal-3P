/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class deleteFlavor {
    initializeMongo iM=new initializeMongo();
    pasarSaboresBox pSB=new pasarSaboresBox();
    public void DeleteFlavor(JTable updateProducts,String idSearch, JTextField MFindTF, JTextField MModifyTF, JTextField MModifyTF2,  JComboBox flavorShop){
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Sabores");
        Document query = new Document("Código:", idSearch);
        collection.deleteOne(query);
        JOptionPane.showMessageDialog(null, "Sabor eliminado exitosamente", "Error", JOptionPane.INFORMATION_MESSAGE);

        cleanTextFields( updateProducts, MFindTF, MModifyTF , MModifyTF2);
        DefaultTableModel model = (DefaultTableModel) updateProducts.getModel();
        model.setRowCount(0);
        pSB.añadirProdComboBox(flavorShop);
    }
    public void cleanTextFields(JTable updateProducts,JTextField  MFindTF,JTextField MModifyTF ,JTextField MModifyTF2){
     MFindTF.setText("");
     MModifyTF.setText("");
     MModifyTF2.setText("");
     DefaultTableModel model1 = (DefaultTableModel) updateProducts.getModel();
    model1.setRowCount(0);
 }
}
