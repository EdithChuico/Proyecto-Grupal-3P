package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class totalPortionsC {
  public int totalPortionscategory(MongoCollection<Document> collection, String category) {
    FindIterable<Document> documents = collection.find();
    int totalPortions = 0;

    for (Document document : documents) {
        String categoriaActual = document.getString("Categoría:");
        if (category.equals(categoriaActual)) {
            int porciones = document.getInteger("Porciones:", 0);
            totalPortions += porciones;
        }
    }

    return totalPortions;
}  
}
