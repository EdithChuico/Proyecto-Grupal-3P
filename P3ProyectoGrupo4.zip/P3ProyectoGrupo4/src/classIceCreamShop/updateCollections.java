/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

/**
 *
 * @author Usuario
 */
public class updateCollections {
    public void actualizarColeccion(MongoCollection<Document> collection, String producto, int porciones) {
    Document filter = new Document("Producto:", producto);
    Document existingDocument = collection.find(filter).first();
    if (existingDocument != null) {
        String porcionesString = existingDocument.getString("Porciones:");
// Convertir a int usando Integer.parseInt()
    int existingPorciones = 0;  // Valor predeterminado en caso de que la cadena no sea un número válido
    if (porcionesString != null) {
        existingPorciones = Integer.parseInt(porcionesString);
    }
        //int existingPorciones = existingDocument.getInteger("Porciones:", 0);
        // Sumar directamente a la variable de tipo int
        int newPorciones = existingPorciones + porciones;
        // Actualizar porciones en la colección correspondiente
        Document update = new Document("$set", new Document("Porciones:", Integer.toString(newPorciones)));
        collection.updateOne(filter, update);
    } else {
        // Insertar un nuevo documento si no existe en la colección
        Document newDocument = new Document()
                .append("Producto:", producto)
                .append("Porciones:", porciones);
        collection.insertOne(newDocument);
    }
}
    
}
