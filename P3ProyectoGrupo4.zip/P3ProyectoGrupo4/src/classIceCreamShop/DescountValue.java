/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

/**
 *
 * @author USER
 */
public class DescountValue {
    public double descountValue(String Descount){
        double desValue;
        if("Cumpleanero(-50%)".equals(Descount)){
            desValue=0.5;
        }else{ 
            if("Viernes negro(-35%)".equals(Descount)){
                desValue=0.35;
        }else{ 
            if("Navidad(-45%)".equals(Descount)){
                 desValue=0.45;
                }else{
                 desValue=0.2;
                }
                }
        }
        return desValue;
    }
}
