/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class findmodTopping {
    initializeMongo iM=new initializeMongo();
    public void FindTopping(String newCode, JTable updateProducts1){
        ValidData(newCode);
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        Document query = new Document("Código:", newCode);
        long count= collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(null, "El código ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            DefaultTableModel tableModel = (DefaultTableModel) updateProducts1.getModel();
            tableModel.setRowCount(0);
            tableModel.setColumnIdentifiers(new String []{"Producto","Código","Cantidad"});
            FindIterable<Document> documents = collection.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Producto:"),
                    document.get("Código:"),
                    document.get("Porciones:")
                });  }
                updateProducts1.setModel(tableModel);
                updateProducts1.revalidate();
                updateProducts1.repaint();
            }
    }   
    public void ValidData(String newCode){
        if (!newCode.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
}
