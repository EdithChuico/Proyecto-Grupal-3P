/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class ToFindname {
    saveFor sF=new saveFor();
    public void TofindName(String find, JLabel FindValidation, JTextField SBCNameTF,JTextField SBCPhoneTF,JTextField SBCidTF){
        if (find.isEmpty()) {
            FindValidation.setText("¡Ingresa datos para buscar!");
        } else {
            // Verificar si el valor ingresado contiene solo dígitos (posiblemente una cédula)
            if (find.matches("\\d+")) {
                sF.buscarPorCedula(find, FindValidation, SBCNameTF, SBCPhoneTF, SBCidTF);
            } else {
                sF.buscarPorNombre(find, FindValidation, SBCNameTF, SBCPhoneTF, SBCidTF);
            }
        }
    }
}
