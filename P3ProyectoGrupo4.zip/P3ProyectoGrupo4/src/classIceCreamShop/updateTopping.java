/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class updateTopping {
    initializeMongo iM=new initializeMongo();
    pasarAderezosBox pAB=new pasarAderezosBox();
    public void UpdateTopping(String nameNew, String idSearch, JTextField  MFindTF2,JTextField MModifyTF3 ,JTextField MModifyTF4, JComboBox ToppingShop){
        ValidData(nameNew,idSearch);
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collectionn = database.getCollection("Aderezos");
        Document query = new Document("Código:", idSearch);
        long count= collectionn.countDocuments(query);
        Document queryy = new Document("Producto:", nameNew);
        long countt= collectionn.countDocuments(queryy);

        if(count<=0){
            JOptionPane.showMessageDialog(null, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if( countt <= 0){
        }else {
            JOptionPane.showMessageDialog(null, "El nombre del aderezo indicado ya existe dentro de los datos ingresados, por favor ingrese un aderezo distinto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Document act= new Document("$set",new Document("Producto:", nameNew));
        collectionn.updateOne(query, act);
        JOptionPane.showMessageDialog(null, "Nombre del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

        cleanTextFields(  MFindTF2, MModifyTF3 , MModifyTF4);
        pAB.añadirProdComboBox(ToppingShop);
    }
    public void ValidData(String nameNew, String idSearch){
        if (nameNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(null, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}

        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    public void cleanTextFields(JTextField  MFindTF2,JTextField MModifyTF3 ,JTextField MModifyTF4){
     MFindTF2.setText("");
     MModifyTF3.setText("");
     MModifyTF4.setText("");
 }
}
