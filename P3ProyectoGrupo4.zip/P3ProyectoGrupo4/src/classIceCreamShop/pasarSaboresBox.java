/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import org.bson.Document;

/**
 *
 * @author HP
 */
//Factory Method: En esta clase se llaman los datos almacenados en la base de datos, para visualizarlos en un ComboBox
public class pasarSaboresBox extends initializeMongo{
   public List<String> obtenerProductos() {
	    openMongo();
	    MongoDatabase database = getDatabase();
	    MongoCollection<Document> collection = database.getCollection("Sabores");
	    List<String> datos = new ArrayList<>();
	    FindIterable<Document> doc = collection.find();
	    try (MongoCursor<Document> cursor = doc.iterator()) {
	        while (cursor.hasNext()) {
	            Document document = cursor.next();
	            String nombre = document.getString("Producto:");
	            datos.add(nombre);
	        }
	    }
	    return datos;
	}
   public void añadirProdComboBox(JComboBox flavorShop) {
	    List<String> datos = obtenerProductos();
	    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(datos.toArray(new String[0]));
	    flavorShop.setModel(model); 
	}
   public List<String> tenerDato(){
       openMongo();
       MongoDatabase db=getDatabase();
       MongoCollection<Document> collection= db.getCollection("Sadborws");
       List<String> dato=new ArrayList<>();
       FindIterable<Document> docc=collection.find();
       try(MongoCursor<Document> cursor=docc.iterator()){
           while(cursor.hasNext()){
               Document doccc=cursor.next();
               String nomr=doccc.getString("Product");
               dato.add(nomr);
           }
           
       }
       return dato;
   }
   public void addCombo(JComboBox flavorShop){
       List<String> dato =tenerDato();
       DefaultComboBoxModel <String> mode=new DefaultComboBoxModel<>(dato.toArray(new String[0]));
       flavorShop.setModel(mode);

   }  
   public List<String> teberDato(){
     openMongo();
     MongoDatabase db=getDatabase();
     MongoCollection<Document> colle=db.getCollection("sabor");
     List<String> datOo=new ArrayList<>();
     FindIterable<Document> doc=colle.find();
     try(MongoCursor<Document> cursor=doc.iterator()){
         while(cursor.hasNext()){
             Document docc=cursor.next();
             String name=docc.getString("Producto");
             datOo.add(name);
         }
     }return datOo;
   }
   public void add2Combo(JComboBox flavorShop){
     List<String> datOo= teberDato();  
     DefaultComboBoxModel<String> docc=new DefaultComboBoxModel<>(datOo.toArray(new String [0]));
     flavorShop.setModel(docc);
   }
   }

