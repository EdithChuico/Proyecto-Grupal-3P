package generalFunctionalities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;

public class reproducirSonido {
    private AdvancedPlayer player;
    private Thread playerThread;
    private Object lock = new Object();

    public void reproducirSonido(String archivoSonido) {
        try {
            FileInputStream fileInputStream = new FileInputStream(archivoSonido);
            player = new AdvancedPlayer(fileInputStream);

            playerThread = new Thread(() -> {
                try {
                    player.play();
                } catch (JavaLayerException e) {
                    e.printStackTrace();
                }
            });

            playerThread.start();

        } catch (FileNotFoundException | JavaLayerException e) {
            e.printStackTrace();
        }
    }

    public void pausarSonido() {
        if (player != null && playerThread != null && playerThread.isAlive()) {
            player.close();
        }
    }

    public void reanudarSonido() {
        if (player != null && playerThread != null && !playerThread.isAlive()) {
            playerThread = new Thread(() -> {
                try {
                    player.play();
                } catch (JavaLayerException e) {
                    e.printStackTrace();
                }
            });
            playerThread.start();
        }
    }
}

