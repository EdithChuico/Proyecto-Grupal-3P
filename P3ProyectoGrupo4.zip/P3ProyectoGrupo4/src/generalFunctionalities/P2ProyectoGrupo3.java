package generalFunctionalities;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import interfazGUI.Login;
import javazoom.jl.decoder.JavaLayerException;
public class P2ProyectoGrupo3 {
    public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException, JavaLayerException{
      //inicializador del tema
        FlatLightLaf.setup();
        //redondeo de componentes
        UIManager.put("TextComponent.arc", 100);
        UIManager.put("Button.arc", 100);
        //Definir color al tabbed
        //UIManager.put( "TabbedPane.tabSeparatorsFullHeight", true );
        UIManager.put( "TabbedPane.selectedBackground", new Color(253,234,166));
        //instanciacion
       Login f= new Login();
       //Heladeria f = new Heladeria();
       f.setVisible(true);
       /*reproducirSonido rS=new reproducirSonido();
       rS.reproducirSonido("cumbiaHelado.mp3");
   */ }
    
}
