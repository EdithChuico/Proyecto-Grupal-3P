package classUserManual;

public class closeUserManual {
    public void ce(java.awt.Component componente){
      if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }   
    }
}
