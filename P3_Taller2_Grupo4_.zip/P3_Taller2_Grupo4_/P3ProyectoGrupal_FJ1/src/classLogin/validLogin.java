package classLogin;
import Observer.llenarCampos;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import interfazGUI.IceCreamShop;
import interfazGUI.Login;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

public class validLogin extends initializeMongo{
    //Instanciación de la clase llenarCampos
    llenarCampos lC= new llenarCampos();
    public void validData(String Password,Login.ReturnUsuario ru,String User,JTextField UserTF, java.awt.Component componente){
    User=UserTF.getText();
    if(Password.isEmpty() || User.isEmpty()){
        //Llamado del método llenarCampos (ejemplo de observer)
        lC.llenarCampos();
    }else{
        validUser( Password, ru, User, UserTF,  componente);
    }
    }
    public void validUser(String Password,Login.ReturnUsuario ru,String User,JTextField UserTF,  java.awt.Component componente){
     User=UserTF.getText();  
     openMongo();
     MongoDatabase db=getDatabase();
     MongoCollection<Document> collection = db.getCollection("Vendedores");
     Document filter = new Document("Usuario:", User).append("CódigoUsuario:", Password);
     FindIterable<Document> result = collection.find(filter);
     if (result.iterator().hasNext()) {
        JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso", "Inicio Exitoso", JOptionPane.INFORMATION_MESSAGE);
        IceCreamShop H = new IceCreamShop();
        H.setVisible(true);
        closeWindow(componente);
     } else {
       JOptionPane.showMessageDialog(null, "Credenciales incorrectas", "Inicio Fallido", JOptionPane.ERROR_MESSAGE);
     }
    }
    public void closeWindow( java.awt.Component componente){
         if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }
    }
}