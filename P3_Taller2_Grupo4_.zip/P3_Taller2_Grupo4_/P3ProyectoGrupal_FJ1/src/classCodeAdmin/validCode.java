package classCodeAdmin;
import Observer.llenarCampos;
import interfazGUI.WorkerManager;
import javax.swing.JOptionPane;
public class validCode {
    //Instanciación de la clase llenarCampos
    llenarCampos lC= new llenarCampos();
    public void validCodeAdmin(String Password, java.awt.Component componente){
     if(Password.isEmpty()){
         //Llamado del método llenarCampos (ejemplo de observer)
         lC.llenarCampos();
     }else{ // Verificar si se encontraron resultados
            if ("A1234".equals(Password)) {
               WorkerManager H = new WorkerManager();
               H.setVisible(true);
               closeVentana(componente);
            } else {
               JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Inicio Fallido", JOptionPane.ERROR_MESSAGE);
            }
        }   
    }
    private static void closeVentana(java.awt.Component componente) {
        if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }
    }
}
