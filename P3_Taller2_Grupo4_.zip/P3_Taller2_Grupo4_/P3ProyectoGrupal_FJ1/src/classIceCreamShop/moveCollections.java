/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

/**
 *
 * @author Usuario
 */
public class moveCollections {
    
    
    public void moverAColecciones(MongoDatabase database, MongoCollection<Document> carritoCollection) {
        updateCollections uc=new updateCollections();
    MongoCollection<Document> saboresCollection = database.getCollection("Sabores");
    MongoCollection<Document> aderezosCollection = database.getCollection("Aderezos"); 
    FindIterable<Document> carritoDocuments = carritoCollection.find();
    for (Document carritoDocument : carritoDocuments) {
        String categoria = carritoDocument.getString("Categoría:");
        String producto = carritoDocument.getString("Producto:");
        int porciones = carritoDocument.getInteger("Porciones:", 0);
        // Actualizar la colección correspondiente (Sabores o Aderezos)
        if ("Sabores".equals(categoria)) {
            uc.actualizarColeccion( saboresCollection ,producto, porciones);
        } else if ("Aderezos".equals(categoria)) {
            uc.actualizarColeccion( aderezosCollection ,producto, porciones);
        }
        // Eliminar el documento de la colección "Carrito" si es necesario
        carritoCollection.deleteOne(carritoDocument);
    }
}
}
