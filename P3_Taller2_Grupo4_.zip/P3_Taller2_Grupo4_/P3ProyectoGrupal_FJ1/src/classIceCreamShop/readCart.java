/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class readCart {
   public void updateTable(JTable jTable2,JTable OrderTable,JTextField iceCreamtype ,JTextField PortionsDelete, JComboBox iceCream){
       initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
         FindIterable<Document> documents = carritoCollection.find();
            DefaultTableModel model;
            model = new DefaultTableModel();
            model.setColumnIdentifiers(new String []{"Producto", "Código", "Porciones","Categoria"});
            
            for(Document document : documents){
                String[] dataProduct = {
                document.getString("Producto:"),
                document.getString("Código:"),
                String.valueOf(document.getInteger("Porciones:")),
                document.getString("Categoría:")
            };
                model.addRow(dataProduct);
            }jTable2.setModel(model);
            OrderTable.setModel(model);
            iceCreamtype.setText(iceCream.getSelectedItem().toString());
            
PortionsDelete.setText("");
   }
}
