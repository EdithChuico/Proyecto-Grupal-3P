package classIceCreamShop;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

public class updateFlavors {
    pasarSaboresBox pSB=new pasarSaboresBox();
 public void validFlavor (String idSearch,String nameNew,JTextField  MFindTF,JTextField MModifyTF ,JTextField MModifyTF2,JComboBox flavorShop ){
     if (nameNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(null, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}

        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(null, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        updateFlavor( idSearch, nameNew,  MFindTF, MModifyTF , MModifyTF2,flavorShop);
 } 
 public void updateFlavor(String idSearch,String nameNew,JTextField  MFindTF,JTextField MModifyTF ,JTextField MModifyTF2,JComboBox flavorShop){
     initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("Inventario");
        MongoCollection<Document> collectionn = database.getCollection("Sabores");
        Document query = new Document("Código:", idSearch);
        long count= collection.countDocuments(query);
        Document queryy = new Document("Producto:", nameNew);
        long countt= collection.countDocuments(queryy);

        if(count<=0){
            JOptionPane.showMessageDialog(null, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(countt<=0){
        }else{
            JOptionPane.showMessageDialog(null, "El nombre ingresado ya está siendo utilizado para otro sabor", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Document act= new Document("$set",new Document("Producto:", nameNew));
        collection.updateOne(query, act);
        collectionn.updateOne(query, act);
        JOptionPane.showMessageDialog(null, "Nombre del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
        pSB.añadirProdComboBox(flavorShop);
        cleanTextFields(  MFindTF, MModifyTF , MModifyTF2);
 }
 public void cleanTextFields(JTextField  MFindTF,JTextField MModifyTF ,JTextField MModifyTF2){
     MFindTF.setText("");
     MModifyTF.setText("");
     MModifyTF2.setText("");
 }
}
