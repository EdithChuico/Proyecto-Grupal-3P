
package interfazGUI;

import classWorker.createWorker;
import classWorker.deleteWorker;
import classWorker.readWorker;
import classWorker.searchWorker;
import classWorker.findWorker;
import classWorker.updateWorker;
import classWorker.workerClosed;
import java.awt.Color;
import tipografias.Fuentes;

public class WorkerManager extends javax.swing.JFrame {
    createWorker aW=new createWorker();
    readWorker aD=new readWorker();
    updateWorker uW=new updateWorker();
    deleteWorker dW=new deleteWorker();
    searchWorker sW=new searchWorker();
    findWorker fW= new findWorker();
    Fuentes tipoFuente;
    public WorkerManager() {
        initComponents();
        this.setBackground(new Color(75, 75, 75));
        tipoFuente = new Fuentes();
        this.setLocationRelativeTo(null);
        
        //Cambiar fuente
        WMTitleL.setFont(tipoFuente.fuente(tipoFuente.QS,1,22));
        WMFindL.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        WMNewDataL.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
       
        aD.loadDataWorker(WorkersTable);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        WMBackgroundPanel = new javax.swing.JPanel();
        WMTitleL = new javax.swing.JLabel();
        WMBackB = new javax.swing.JButton();
        UMInfoTabbed = new javax.swing.JTabbedPane();
        UMInterfaceP = new generalFunctionalities.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        WorkersTable = new javax.swing.JTable();
        UMDatabaseP = new generalFunctionalities.PanelRound();
        UserNew = new javax.swing.JTextField();
        WMFindL = new javax.swing.JLabel();
        WMNewDataL = new javax.swing.JLabel();
        idNew = new javax.swing.JTextField();
        WMNewDataL1 = new javax.swing.JLabel();
        AddWorker = new javax.swing.JButton();
        WMNewDataL2 = new javax.swing.JLabel();
        passwordNew = new javax.swing.JTextField();
        WMNewDataL3 = new javax.swing.JLabel();
        passwordNew1 = new javax.swing.JTextField();
        posicion = new javax.swing.JTextField();
        UMSimbologyP = new generalFunctionalities.PanelRound();
        SL5 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        SL10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        updateTable = new javax.swing.JTable();
        updatePassword = new javax.swing.JButton();
        newPasword = new javax.swing.JTextField();
        WMDeleteWorkerB1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        uptadeId1 = new javax.swing.JTextField();
        MFindB1 = new javax.swing.JButton();
        newName1 = new javax.swing.JTextField();
        updateName = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMaximumSize(new java.awt.Dimension(800, 480));
        setMinimumSize(new java.awt.Dimension(800, 480));
        setPreferredSize(new java.awt.Dimension(800, 480));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        WMBackgroundPanel.setBackground(new java.awt.Color(117, 117, 117));
        WMBackgroundPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        WMTitleL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        WMTitleL.setForeground(new java.awt.Color(255, 255, 255));
        WMTitleL.setText("Gestor de Trabajadores");
        WMBackgroundPanel.add(WMTitleL, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, -1, -1));

        WMBackB.setBackground(new java.awt.Color(117, 117, 117));
        WMBackB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        WMBackB.setBorder(null);
        WMBackB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WMBackBActionPerformed(evt);
            }
        });
        WMBackgroundPanel.add(WMBackB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        UMInfoTabbed.setBackground(new java.awt.Color(255, 255, 255));
        UMInfoTabbed.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        UMInfoTabbed.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        UMInterfaceP.setBackground(new java.awt.Color(166, 166, 166));
        UMInterfaceP.setRoundBottomLeft(100);
        UMInterfaceP.setRoundBottomRight(100);
        UMInterfaceP.setRoundTopRight(100);
        UMInterfaceP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        WorkersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(WorkersTable);

        UMInterfaceP.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 540, 290));

        UMInfoTabbed.addTab("Trabajadores", UMInterfaceP);

        UMDatabaseP.setBackground(new java.awt.Color(166, 166, 166));
        UMDatabaseP.setRoundBottomLeft(100);
        UMDatabaseP.setRoundBottomRight(100);
        UMDatabaseP.setRoundTopRight(100);
        UMDatabaseP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        UserNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserNewActionPerformed(evt);
            }
        });
        UMDatabaseP.add(UserNew, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, 340, 40));

        WMFindL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        WMFindL.setForeground(new java.awt.Color(255, 255, 255));
        WMFindL.setText("Usuario");
        UMDatabaseP.add(WMFindL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 100, 30));

        WMNewDataL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        WMNewDataL.setForeground(new java.awt.Color(255, 255, 255));
        WMNewDataL.setText("Cédula");
        UMDatabaseP.add(WMNewDataL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 110, 30));

        idNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idNewActionPerformed(evt);
            }
        });
        UMDatabaseP.add(idNew, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 210, 340, 40));

        WMNewDataL1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        WMNewDataL1.setForeground(new java.awt.Color(255, 255, 255));
        WMNewDataL1.setText("Confirmar Contraseña");
        UMDatabaseP.add(WMNewDataL1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 290, 30));

        AddWorker.setBackground(new java.awt.Color(166, 166, 166));
        AddWorker.setForeground(new java.awt.Color(255, 255, 255));
        AddWorker.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add+.png"))); // NOI18N
        AddWorker.setText("Añadir");
        AddWorker.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddWorkerActionPerformed(evt);
            }
        });
        UMDatabaseP.add(AddWorker, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 310, 160, 40));

        WMNewDataL2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        WMNewDataL2.setForeground(new java.awt.Color(255, 255, 255));
        WMNewDataL2.setText("Contraseña");
        UMDatabaseP.add(WMNewDataL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 110, 30));

        passwordNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordNewActionPerformed(evt);
            }
        });
        UMDatabaseP.add(passwordNew, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, 340, 40));

        WMNewDataL3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        WMNewDataL3.setForeground(new java.awt.Color(255, 255, 255));
        WMNewDataL3.setText("Cargo");
        UMDatabaseP.add(WMNewDataL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 110, 30));

        passwordNew1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordNew1ActionPerformed(evt);
            }
        });
        UMDatabaseP.add(passwordNew1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 340, 40));

        posicion.setText("Cajero");
        UMDatabaseP.add(posicion, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 260, 340, 40));

        UMInfoTabbed.addTab("Agregar", UMDatabaseP);

        UMSimbologyP.setBackground(new java.awt.Color(166, 166, 166));
        UMSimbologyP.setRoundBottomLeft(100);
        UMSimbologyP.setRoundBottomRight(100);
        UMSimbologyP.setRoundTopRight(100);
        UMSimbologyP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SL5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        SL5.setForeground(new java.awt.Color(255, 255, 255));
        SL5.setText("Si desea eliminar el elemento buscado, seleccione el botón \"Eliminar\"");
        UMSimbologyP.add(SL5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 390, 20));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete+.png"))); // NOI18N
        UMSimbologyP.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        SL10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        SL10.setForeground(new java.awt.Color(255, 255, 255));
        SL10.setText("Ingrese la nueva contraseña");
        UMSimbologyP.add(SL10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 170, 30));

        updateTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(updateTable);

        UMSimbologyP.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 470, 50));

        updatePassword.setBackground(new java.awt.Color(104, 192, 183));
        updatePassword.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/actualizar+.png"))); // NOI18N
        updatePassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatePasswordActionPerformed(evt);
            }
        });
        UMSimbologyP.add(updatePassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 220, 50, 30));

        newPasword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newPaswordActionPerformed(evt);
            }
        });
        UMSimbologyP.add(newPasword, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, 300, 30));

        WMDeleteWorkerB1.setBackground(new java.awt.Color(166, 166, 166));
        WMDeleteWorkerB1.setForeground(new java.awt.Color(255, 255, 255));
        WMDeleteWorkerB1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/remove+.png"))); // NOI18N
        WMDeleteWorkerB1.setText("Eliminar");
        WMDeleteWorkerB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WMDeleteWorkerB1ActionPerformed(evt);
            }
        });
        UMSimbologyP.add(WMDeleteWorkerB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 270, 140, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Ingrese la cedula del usuario que desee modificar");
        UMSimbologyP.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ingrese el nuevo nombre de usuario");
        UMSimbologyP.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 210, -1));

        uptadeId1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uptadeId1ActionPerformed(evt);
            }
        });
        UMSimbologyP.add(uptadeId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 340, 30));

        MFindB1.setBackground(new java.awt.Color(104, 192, 183));
        MFindB1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Buscarpositivo.png"))); // NOI18N
        MFindB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MFindB1ActionPerformed(evt);
            }
        });
        UMSimbologyP.add(MFindB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 50, 50, 30));

        newName1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newName1ActionPerformed(evt);
            }
        });
        UMSimbologyP.add(newName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, 300, 30));

        updateName.setBackground(new java.awt.Color(104, 192, 183));
        updateName.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/actualizar+.png"))); // NOI18N
        updateName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateNameActionPerformed(evt);
            }
        });
        UMSimbologyP.add(updateName, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 170, 50, 30));

        UMInfoTabbed.addTab("Modificar ", UMSimbologyP);

        WMBackgroundPanel.add(UMInfoTabbed, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 760, 360));

        getContentPane().add(WMBackgroundPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 460));

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void idNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idNewActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idNewActionPerformed
    
    private void WMBackBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WMBackBActionPerformed
        workerClosed wC=new workerClosed();
        wC.backPanel(this);
        
    }//GEN-LAST:event_WMBackBActionPerformed

    private void UserNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserNewActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UserNewActionPerformed
    
    private void AddWorkerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddWorkerActionPerformed
    //Facade: El patrón de Diseño facade  indica que podrías dar una presentación 
  //solo con las funciones requeridas por el usuario, ocultando las funciones que 
  //serían irrelevantes, también podremos ver otro ejemplo de facade a continuación 
    String newUser= UserNew.getText();
    String newID= idNew.getText();
    String newPasword= passwordNew.getText();
    String newPasword1= passwordNew1.getText();
    String newProfess= posicion.getText();
    aW.validateEnteredDataWorker(newUser, UserNew, newID,idNew ,newPasword,newPasword1 ,passwordNew,passwordNew1,newProfess);
    aD.loadDataWorker(WorkersTable);
    // TODO add your handling code here:
    }//GEN-LAST:event_AddWorkerActionPerformed

    private void passwordNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordNewActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordNewActionPerformed

    private void newPaswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newPaswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_newPaswordActionPerformed

    private void updatePasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatePasswordActionPerformed
    String idSearch= uptadeId1.getText();
    String PasswordNew=newPasword.getText();
    fW.validData(idSearch,PasswordNew,uptadeId1,newPasword,newName1);
    aD.loadDataWorker(WorkersTable);   
    }//GEN-LAST:event_updatePasswordActionPerformed

    private void passwordNew1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordNew1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordNew1ActionPerformed

    private void uptadeId1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uptadeId1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uptadeId1ActionPerformed

    private void MFindB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MFindB1ActionPerformed
     String idSearch= uptadeId1.getText();
     sW.validData(idSearch,updateTable );
    }//GEN-LAST:event_MFindB1ActionPerformed

    private void newName1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newName1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_newName1ActionPerformed

    private void updateNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateNameActionPerformed
      String idSearch= uptadeId1.getText();
      String nameNew=newName1.getText();
      uW.validData(idSearch, nameNew,newName1,uptadeId1,newPasword);
      aD.loadDataWorker(WorkersTable); 
    }//GEN-LAST:event_updateNameActionPerformed

    private void WMDeleteWorkerB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WMDeleteWorkerB1ActionPerformed
     String idSearch= uptadeId1.getText();
     dW.deleteWorker(idSearch,newPasword,uptadeId1,newName1);
     aD.loadDataWorker(WorkersTable);
      
// TODO add your handling code here:
    }//GEN-LAST:event_WMDeleteWorkerB1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WorkerManager().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddWorker;
    private javax.swing.JButton MFindB1;
    private javax.swing.JLabel SL10;
    private javax.swing.JLabel SL5;
    private generalFunctionalities.PanelRound UMDatabaseP;
    private javax.swing.JTabbedPane UMInfoTabbed;
    private generalFunctionalities.PanelRound UMInterfaceP;
    private generalFunctionalities.PanelRound UMSimbologyP;
    private javax.swing.JTextField UserNew;
    private javax.swing.JButton WMBackB;
    private javax.swing.JPanel WMBackgroundPanel;
    private javax.swing.JButton WMDeleteWorkerB1;
    private javax.swing.JLabel WMFindL;
    private javax.swing.JLabel WMNewDataL;
    private javax.swing.JLabel WMNewDataL1;
    private javax.swing.JLabel WMNewDataL2;
    private javax.swing.JLabel WMNewDataL3;
    private javax.swing.JLabel WMTitleL;
    private javax.swing.JTable WorkersTable;
    private javax.swing.JTextField idNew;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField newName1;
    private javax.swing.JTextField newPasword;
    private javax.swing.JTextField passwordNew;
    private javax.swing.JTextField passwordNew1;
    private javax.swing.JTextField posicion;
    private javax.swing.JButton updateName;
    private javax.swing.JButton updatePassword;
    private javax.swing.JTable updateTable;
    private javax.swing.JTextField uptadeId1;
    // End of variables declaration//GEN-END:variables
}
