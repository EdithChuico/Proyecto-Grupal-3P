package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class deleteOneCar {
    initializeMongo iM=new initializeMongo();
    totalPortionsC tPC=new totalPortionsC();
  public void deleteProductoCar(String delete){
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
    Document query = new Document("Producto:", delete);
    long count= carritoCollection.countDocuments(query);
    if(count<=0){
        JOptionPane.showMessageDialog(null, "El producto a buscar no a sido ingresado", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String adminPassword = JOptionPane.showInputDialog(null, "Ingrese la contraseña del administrador:", "Confirmar eliminación", JOptionPane.PLAIN_MESSAGE);
        // Verificar la contraseña de administrador
    if (adminPassword == null || !adminPassword.equals("A1234")) {
        JOptionPane.showMessageDialog(null, "Contraseña incorrecta. No se permite la eliminación.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    // Eliminar el producto después de realizar las operaciones de suma y actualización
    carritoCollection.deleteOne(query);
    JOptionPane.showMessageDialog(null, "Producto eliminado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        
    
  }
public void addTable(JTable jTable2, JTextField PortionsDelete,JComboBox iceCream, JLabel totalfinal,JLabel SBOIVAResultP,JLabel finaaal){
    
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
    FindIterable<Document> documents = carritoCollection.find();
        DefaultTableModel model;
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String []{"Producto", "Código", "Porciones","Categoria"});

        for(Document document : documents){
            String[] dataProduct = {
                document.getString("Producto:"),
                document.getString("Código:"),
                String.valueOf(document.getInteger("Porciones:")),
                document.getString("Categoría:")
            };
        priceProducts( jTable2,  PortionsDelete, iceCream,  totalfinal, SBOIVAResultP, finaaal);
        model.addRow(dataProduct);
        }jTable2.setModel(model);
        PortionsDelete.setText(""); 
    
 
}
public void priceProducts(JTable jTable2, JTextField PortionsDelete,JComboBox iceCream, JLabel totalfinal,JLabel SBOIVAResultP,JLabel finaaal){
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    float value=(float) 0.75;
        int totalPortionscat2 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        int totalPortionscat3 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        float Prize=(totalPortionscat2+totalPortionscat3)*value;
        String cream=iceCream.getSelectedItem().toString();
        float PrizeIce=0;
        if(cream=="Vasito"){
            PrizeIce=1;
        }else{
            if(cream=="Conito"){
                PrizeIce=(float) 1.25;
            }else{
                if(cream=="Paleta"){
                    PrizeIce=(float) 0.50;
                }else{
                    PrizeIce=2;
                }
            }
        }
        float totalPrize=Prize+PrizeIce;
        String totalPrizes = String.valueOf(totalPrize);
        totalfinal.setText(totalPrizes);
        double iva=totalPrize*0.12;
        SBOIVAResultP.setText(String.valueOf(iva));
        double finale=totalPrize+iva;
        finaaal.setText(String.valueOf(finale));
}
}

