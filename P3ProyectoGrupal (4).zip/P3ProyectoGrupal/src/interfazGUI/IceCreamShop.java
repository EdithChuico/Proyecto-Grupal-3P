package interfazGUI;

import classIceCreamShop.changeUser;
import classIceCreamShop.createFlavor;
import classIceCreamShop.createTopping;
import classIceCreamShop.deleteOneCar;
import classIceCreamShop.enterData;
import classIceCreamShop.inventarioFuncion;
import classIceCreamShop.pasarAderezosBox;
import classIceCreamShop.pasarSaboresBox;
import classIceCreamShop.readCart;
import classIceCreamShop.readFlavors;
import classIceCreamShop.readInvoices;
import classIceCreamShop.readTopping;
import classIceCreamShop.saveClient;
import classIceCreamShop.saveFor;
import classIceCreamShop.totalPortionsC;
import classIceCreamShop.validPhone;
import generalFunctionalities.initializeMongo;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.Color;
import java.awt.Component;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
import tipografias.Fuentes;
import javax.swing.JTextField; 
import org.json.simple.JSONObject;
public class IceCreamShop extends javax.swing.JFrame {
     inventarioFuncion iF= new inventarioFuncion();
     pasarSaboresBox pSB=new pasarSaboresBox();
     pasarAderezosBox pAB=new pasarAderezosBox();
     readFlavors rF=new readFlavors();
     readTopping rT=new readTopping();
     readCart rC=new readCart();
     readInvoices rI=new readInvoices();
     createFlavor cF=new createFlavor();
     createTopping cT=new createTopping();
     changeUser cU=new changeUser();
     validPhone vP=new validPhone();
     saveFor sF=new saveFor();
    Fuentes tipoFuente;
    DefaultTableModel model= new DefaultTableModel();
    DefaultTableModel modelOT = new DefaultTableModel();
    DefaultTableModel modelRegisters = new DefaultTableModel();
    totalPortionsC tPC=new totalPortionsC();
    enterData eD=new enterData();
    String dir = "mongodb://localhost:27017";
   
    public IceCreamShop() {
        initComponents();
        rF.LoadDataTaste(TTable);
        rT.LoadDataSuplies(STable);
        rI.seeInvoices(RegistersTable);
        pSB.añadirProdComboBox(flavorShop);
        pAB.añadirProdComboBox(ToppingShop);
        tipoFuente = new Fuentes();
        modelOT = new DefaultTableModel();
        //definir columnas de la tabla
        modelOT.addColumn("Producto");
        modelOT.addColumn("Cantidad");
        modelOT.addColumn("Precio");
        OrderTable.setModel(modelOT);
        this.setExtendedState(this.MAXIMIZED_BOTH);
        CardDialog.setLocationRelativeTo(null);
        rsscalelabel.RSScaleLabel.setScaleLabel(BackgroundLateralP, "src/imagenes/Background.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(BackgroundLateralP, "src/imagenes/Background.png");
        //Cambio de fuente
            //botones
            InventoryB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            SellsB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            SettingsB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            UserManualB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            ChangeUserB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            ExitB.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            
            TSaveAllB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
            SSaveAllB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
            MFindB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
            
            MSaveModifyB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
            MSaveModifyB2.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
            MLoadDataB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
            SBORefreshB.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBOSellB.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBOCancelSellB.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            
            SRLoadDataRegisterB.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            
            //Labels
            TNameL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            TCodeL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            TQuantityL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            TImageL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            SNameL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            SCodeL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            SQuantityL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            SImageL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            
            MModifyL.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            MModifyL2.setFont(tipoFuente.fuente(tipoFuente.QS,1,15));
            MInformationL.setFont(tipoFuente.fuente(tipoFuente.QS,1,19));
           
            SBCTitleL.setFont(tipoFuente.fuente(tipoFuente.QS,1,16));
            SBCBillL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBCNameL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBCPhoneL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBCRegisterL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBCIdentificationL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBCPaymentL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            SBOTitleL.setFont(tipoFuente.fuente(tipoFuente.QS,1,16));
            SBOFindL.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
            
            
            MTable.setModel(model);
            //redondear combo boxes
            SBillTypeCB.putClientProperty("JComponent.roundRect", true);
            SPaymentCB.putClientProperty("JComponent.roundRect", true);
            flavorShop.putClientProperty("JComponent.roundRect", true);
            ToppingShop.putClientProperty("JComponent.roundRect", true);
            MLoadTypeDataCB.putClientProperty("JComponent.roundRect", true);
        HSellsP.setVisible(false);
        //boquear panel de cliente por defecto:
        for (Component component : LockedPanel.getComponents()) {
               component.setEnabled(false); 
            }
        rC.updateTable(jTable2,OrderTable,iceCreamtype ,PortionsDelete,iceCream);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        RegisterBG = new javax.swing.ButtonGroup();
        CardDialog = new javax.swing.JDialog();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        CardName = new javax.swing.JTextField();
        CardNumber = new javax.swing.JTextField();
        CardExpiration = new javax.swing.JTextField();
        CardSC = new javax.swing.JTextField();
        ValidationCName = new javax.swing.JLabel();
        ValidationCNumber = new javax.swing.JLabel();
        Addorn = new javax.swing.JLabel();
        ValidationCSC = new javax.swing.JLabel();
        YY = new javax.swing.JTextField();
        ValidationCEMM = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        HeladeriaLateralPanel = new javax.swing.JPanel();
        panelRound1 = new generalFunctionalities.PanelRound();
        LogoL = new javax.swing.JLabel();
        ButtonsPanel = new javax.swing.JPanel();
        InventoryB = new javax.swing.JButton();
        SellsB = new javax.swing.JButton();
        SettingsB = new javax.swing.JButton();
        UserManualB = new javax.swing.JButton();
        ChangeUserB = new javax.swing.JButton();
        ExitB = new javax.swing.JButton();
        BurgerButton = new javax.swing.JButton();
        BackgroundLateralP = new javax.swing.JLabel();
        HeladeriaInteractivePanel = new javax.swing.JPanel();
        InventoryTabbed = new javax.swing.JTabbedPane();
        TastePanel = new generalFunctionalities.PanelRound();
        TNameL = new javax.swing.JLabel();
        TCodeL = new javax.swing.JLabel();
        TNameTF = new javax.swing.JTextField();
        TCodeTF = new javax.swing.JTextField();
        TCuantityTF = new javax.swing.JTextField();
        TImageL = new javax.swing.JLabel();
        TSaveAllB = new javax.swing.JButton();
        panelRound2 = new generalFunctionalities.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        TTable = new javax.swing.JTable();
        TQuantityL = new javax.swing.JLabel();
        SupliesPane = new generalFunctionalities.PanelRound();
        SNameL = new javax.swing.JLabel();
        SCodeL = new javax.swing.JLabel();
        SQuantityL = new javax.swing.JLabel();
        SNameTF = new javax.swing.JTextField();
        SCodeTF = new javax.swing.JTextField();
        SQuantityTF = new javax.swing.JTextField();
        SImageL = new javax.swing.JLabel();
        SupliesTablePanel = new generalFunctionalities.PanelRound();
        jScrollPane2 = new javax.swing.JScrollPane();
        STable = new javax.swing.JTable();
        SSaveAllB = new javax.swing.JButton();
        ModificacionesPane1 = new generalFunctionalities.PanelRound();
        panelRound5 = new generalFunctionalities.PanelRound();
        jScrollPane7 = new javax.swing.JScrollPane();
        MTable1 = new javax.swing.JTable();
        MFindB2 = new javax.swing.JButton();
        MFindTF2 = new javax.swing.JTextField();
        MModifyL3 = new javax.swing.JLabel();
        MSaveModifyB3 = new javax.swing.JButton();
        MModifyTF3 = new javax.swing.JTextField();
        MLoadDataB2 = new javax.swing.JButton();
        MLoadTypeDataCB2 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        MInformationL2 = new javax.swing.JLabel();
        SDeleteAllB3 = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        updateProducts1 = new javax.swing.JTable();
        MModifyL4 = new javax.swing.JLabel();
        MSaveModifyB4 = new javax.swing.JButton();
        MModifyTF4 = new javax.swing.JTextField();
        MFindL3 = new javax.swing.JLabel();
        SL6 = new javax.swing.JLabel();
        WMDeleteWorkerB2 = new javax.swing.JButton();
        ModificacionesPane = new generalFunctionalities.PanelRound();
        panelRound4 = new generalFunctionalities.PanelRound();
        MFindB = new javax.swing.JButton();
        MFindTF = new javax.swing.JTextField();
        MModifyL = new javax.swing.JLabel();
        MSaveModifyB = new javax.swing.JButton();
        MModifyTF = new javax.swing.JTextField();
        MLoadDataB = new javax.swing.JButton();
        panelRound6 = new generalFunctionalities.PanelRound();
        jScrollPane3 = new javax.swing.JScrollPane();
        MTable = new javax.swing.JTable();
        MLoadTypeDataCB = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        MInformationL = new javax.swing.JLabel();
        SDeleteAllB1 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        updateProducts = new javax.swing.JTable();
        MModifyL2 = new javax.swing.JLabel();
        MSaveModifyB2 = new javax.swing.JButton();
        MModifyTF2 = new javax.swing.JTextField();
        MFindL2 = new javax.swing.JLabel();
        SL5 = new javax.swing.JLabel();
        WMDeleteWorkerB1 = new javax.swing.JButton();
        HSellsP = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        SProductsPane = new generalFunctionalities.PanelRound();
        SProductsTabbed = new javax.swing.JTabbedPane();
        PConeIceCreamP = new generalFunctionalities.PanelRound();
        AddOption = new javax.swing.JButton();
        SBOFindL1 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        PortionsSelected = new javax.swing.JTextField();
        SBOFindL2 = new javax.swing.JLabel();
        AddOption1 = new javax.swing.JButton();
        SBOFindL3 = new javax.swing.JLabel();
        PortionsDelete = new javax.swing.JTextField();
        SBOFindL4 = new javax.swing.JLabel();
        SBOFindL5 = new javax.swing.JLabel();
        PortionsSelected2 = new javax.swing.JTextField();
        SRDeleteOnecar = new javax.swing.JButton();
        SBOFindL6 = new javax.swing.JLabel();
        iceCream = new javax.swing.JComboBox<>();
        flavorShop = new javax.swing.JComboBox<>();
        ToppingShop = new javax.swing.JComboBox<>();
        SBillsPane = new generalFunctionalities.PanelRound();
        SOrderPanel = new generalFunctionalities.PanelRound();
        jScrollPane4 = new javax.swing.JScrollPane();
        OrderTable = new javax.swing.JTable();
        SBOTitleL = new javax.swing.JLabel();
        SBOCancelSellB = new javax.swing.JButton();
        SBOSellB = new javax.swing.JButton();
        SBORefreshB = new javax.swing.JButton();
        SBOSubtotalL = new javax.swing.JLabel();
        SBOIVAL = new javax.swing.JLabel();
        SBOTotalL = new javax.swing.JLabel();
        SBOIVAP = new generalFunctionalities.PanelRound();
        SBOIVAResultP = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        totalfinal = new javax.swing.JLabel();
        SBOTotalP = new generalFunctionalities.PanelRound();
        finaaal = new javax.swing.JLabel();
        SBOSubtotalP = new generalFunctionalities.PanelRound();
        iceCreamtype = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        SClientP = new generalFunctionalities.PanelRound();
        SBCTitleL = new javax.swing.JLabel();
        SBCBillL = new javax.swing.JLabel();
        SBillTypeCB = new javax.swing.JComboBox<>();
        LockedPanel = new javax.swing.JPanel();
        SBCNameL = new javax.swing.JLabel();
        SBCPhoneL = new javax.swing.JLabel();
        SBCNameTF = new javax.swing.JTextField();
        SBCPhoneTF = new javax.swing.JTextField();
        SBCIdentificationL = new javax.swing.JLabel();
        SBCPaymentL = new javax.swing.JLabel();
        SBCidTF = new javax.swing.JTextField();
        SBCValidation4 = new javax.swing.JLabel();
        SBCValidation1 = new javax.swing.JLabel();
        SBCValidation2 = new javax.swing.JLabel();
        SBCValidation3 = new javax.swing.JLabel();
        SPaymentCB = new javax.swing.JComboBox<>();
        SBCRegisterL = new javax.swing.JLabel();
        RegisterYes = new javax.swing.JRadioButton();
        RegisterNo = new javax.swing.JRadioButton();
        SBOFindL = new javax.swing.JLabel();
        SBOFindB = new javax.swing.JButton();
        SBOFindTF = new javax.swing.JTextField();
        FindValidation = new javax.swing.JLabel();
        SRegistersPane = new generalFunctionalities.PanelRound();
        SRLoadDataRegisterB = new javax.swing.JButton();
        panelRound10 = new generalFunctionalities.PanelRound();
        jScrollPane6 = new javax.swing.JScrollPane();
        RegistersTable = new javax.swing.JTable();

        CardDialog.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        CardDialog.setMinimumSize(new java.awt.Dimension(400, 400));
        this.setLocationRelativeTo(null);
        CardDialog.setModal(true);
        CardDialog.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("Datos de la tarjeta");
        CardDialog.getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 6, -1, -1));

        jLabel4.setText("Titular de la tarjeta");
        CardDialog.getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 28, -1, -1));

        jLabel5.setText("Numero de la tarjeta");
        CardDialog.getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 96, -1, -1));

        jLabel6.setText("Fecha de expiracion");
        CardDialog.getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 176, -1, -1));

        jLabel7.setText("Codigo de seguridad");
        CardDialog.getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(192, 176, -1, -1));

        jButton1.setText("Confirmar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, -1, -1));

        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, -1, -1));

        CardName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CardNameActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(CardName, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 48, 341, -1));

        CardNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CardNumberActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(CardNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 118, 341, -1));

        CardExpiration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CardExpirationActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(CardExpiration, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 40, -1));

        CardSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CardSCActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(CardSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(192, 198, 110, -1));

        ValidationCName.setText("Validacion");
        CardDialog.getContentPane().add(ValidationCName, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 74, -1, -1));

        ValidationCNumber.setText("Validacion");
        CardDialog.getContentPane().add(ValidationCNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 148, -1, -1));

        Addorn.setText("/");
        CardDialog.getContentPane().add(Addorn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, -1, -1));

        ValidationCSC.setText("Validacion");
        CardDialog.getContentPane().add(ValidationCSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(192, 232, -1, -1));

        YY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YYActionPerformed(evt);
            }
        });
        CardDialog.getContentPane().add(YY, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 40, -1));
        CardDialog.getContentPane().add(ValidationCEMM, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 170, 20));

        jLabel8.setText("MM");
        CardDialog.getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        jLabel9.setText("YY");
        CardDialog.getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, -1, -1));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        HeladeriaLateralPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound1.setBackground(new java.awt.Color(115, 115, 115));
        panelRound1.setRoundBottomLeft(200);
        panelRound1.setRoundBottomRight(200);
        panelRound1.setRoundTopLeft(200);
        panelRound1.setRoundTopRight(200);

        LogoL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/LogoDeliFrostMini.png"))); // NOI18N

        javax.swing.GroupLayout panelRound1Layout = new javax.swing.GroupLayout(panelRound1);
        panelRound1.setLayout(panelRound1Layout);
        panelRound1Layout.setHorizontalGroup(
            panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 190, Short.MAX_VALUE)
            .addGroup(panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(LogoL)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        panelRound1Layout.setVerticalGroup(
            panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 190, Short.MAX_VALUE)
            .addGroup(panelRound1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(LogoL)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        HeladeriaLateralPanel.add(panelRound1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 190, 190));

        ButtonsPanel.setBackground(new java.awt.Color(115, 115, 115));

        InventoryB.setBackground(new java.awt.Color(205, 76, 130));
        InventoryB.setForeground(new java.awt.Color(255, 255, 255));
        InventoryB.setText("Inventario");
        InventoryB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InventoryBActionPerformed(evt);
            }
        });

        SellsB.setBackground(new java.awt.Color(104, 192, 183));
        SellsB.setForeground(new java.awt.Color(255, 255, 255));
        SellsB.setText("Ventas");
        SellsB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SellsBActionPerformed(evt);
            }
        });

        SettingsB.setBackground(new java.awt.Color(205, 76, 130));
        SettingsB.setForeground(new java.awt.Color(255, 255, 255));
        SettingsB.setText("Gestion de Trabajadores\n");
        SettingsB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SettingsBActionPerformed(evt);
            }
        });

        UserManualB.setBackground(new java.awt.Color(104, 192, 183));
        UserManualB.setForeground(new java.awt.Color(255, 255, 255));
        UserManualB.setText("Manual de Usuario");
        UserManualB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserManualBActionPerformed(evt);
            }
        });

        ChangeUserB.setBackground(new java.awt.Color(205, 76, 130));
        ChangeUserB.setForeground(new java.awt.Color(255, 255, 255));
        ChangeUserB.setText("Cambio de Usuario");
        ChangeUserB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangeUserBActionPerformed(evt);
            }
        });

        ExitB.setBackground(new java.awt.Color(104, 192, 183));
        ExitB.setForeground(new java.awt.Color(255, 255, 255));
        ExitB.setText("Salir");
        ExitB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ButtonsPanelLayout = new javax.swing.GroupLayout(ButtonsPanel);
        ButtonsPanel.setLayout(ButtonsPanelLayout);
        ButtonsPanelLayout.setHorizontalGroup(
            ButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ButtonsPanelLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(ButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(InventoryB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SellsB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SettingsB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(UserManualB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ChangeUserB, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                    .addComponent(ExitB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        ButtonsPanelLayout.setVerticalGroup(
            ButtonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ButtonsPanelLayout.createSequentialGroup()
                .addContainerGap(127, Short.MAX_VALUE)
                .addComponent(InventoryB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SellsB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SettingsB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(UserManualB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ChangeUserB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ExitB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(173, Short.MAX_VALUE))
        );

        HeladeriaLateralPanel.add(ButtonsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 340, 600));

        BurgerButton.setText("<");
        BurgerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BurgerButtonActionPerformed(evt);
            }
        });
        HeladeriaLateralPanel.add(BurgerButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 20, -1, -1));
        HeladeriaLateralPanel.add(BackgroundLateralP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, 310));

        getContentPane().add(HeladeriaLateralPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        HeladeriaInteractivePanel.setBackground(new java.awt.Color(255, 255, 255));
        HeladeriaInteractivePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        InventoryTabbed.setBackground(new java.awt.Color(255, 255, 255));

        TastePanel.setBackground(new java.awt.Color(253, 234, 166));
        TastePanel.setRoundBottomLeft(100);
        TastePanel.setRoundBottomRight(100);
        TastePanel.setRoundTopRight(100);
        TastePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TNameL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TNameL.setText("Nombre del sabor");
        TastePanel.add(TNameL, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 30, -1, 20));

        TCodeL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TCodeL.setText("Codigo");
        TastePanel.add(TCodeL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 130, 20));

        TNameTF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TastePanel.add(TNameTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 30, 210, 30));

        TCodeTF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TastePanel.add(TCodeTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 70, 210, 30));

        TCuantityTF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TCuantityTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TCuantityTFActionPerformed(evt);
            }
        });
        TastePanel.add(TCuantityTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 210, 30));

        TImageL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/saboresHelado.jpg"))); // NOI18N
        TastePanel.add(TImageL, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 30, 400, 190));

        TSaveAllB.setBackground(new java.awt.Color(235, 104, 156));
        TSaveAllB.setForeground(new java.awt.Color(255, 255, 255));
        TSaveAllB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/guardardatos+.png"))); // NOI18N
        TSaveAllB.setText("Guardar todo");
        TSaveAllB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TSaveAllBActionPerformed(evt);
            }
        });
        TastePanel.add(TSaveAllB, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, 210, 40));

        panelRound2.setBackground(new java.awt.Color(255, 255, 255));
        panelRound2.setRoundBottomLeft(100);
        panelRound2.setRoundBottomRight(100);
        panelRound2.setRoundTopLeft(100);
        panelRound2.setRoundTopRight(100);

        TTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TTable);

        javax.swing.GroupLayout panelRound2Layout = new javax.swing.GroupLayout(panelRound2);
        panelRound2.setLayout(panelRound2Layout);
        panelRound2Layout.setHorizontalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 879, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        panelRound2Layout.setVerticalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        TastePanel.add(panelRound2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 940, 380));

        TQuantityL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TQuantityL.setText("Cantidad");
        TastePanel.add(TQuantityL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 130, 20));

        InventoryTabbed.addTab("Guardar Sabores", TastePanel);

        SupliesPane.setBackground(new java.awt.Color(253, 234, 166));
        SupliesPane.setRoundBottomLeft(100);
        SupliesPane.setRoundBottomRight(100);
        SupliesPane.setRoundTopRight(100);
        SupliesPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SNameL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SNameL.setText("Nombre del Aderezo");
        SupliesPane.add(SNameL, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 30, 150, 20));

        SCodeL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SCodeL.setText("Codigo");
        SupliesPane.add(SCodeL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 130, 20));

        SQuantityL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SQuantityL.setText("Cantidad");
        SupliesPane.add(SQuantityL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 130, 20));

        SNameTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SNameTFActionPerformed(evt);
            }
        });
        SupliesPane.add(SNameTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 30, 210, 30));
        SupliesPane.add(SCodeTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 70, 210, 30));

        SQuantityTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SQuantityTFActionPerformed(evt);
            }
        });
        SupliesPane.add(SQuantityTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 210, 30));

        SImageL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/aderezosHelado.jpg"))); // NOI18N
        SupliesPane.add(SImageL, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 10, 400, 210));

        SupliesTablePanel.setBackground(new java.awt.Color(255, 255, 255));
        SupliesTablePanel.setRoundBottomLeft(100);
        SupliesTablePanel.setRoundBottomRight(100);
        SupliesTablePanel.setRoundTopLeft(100);
        SupliesTablePanel.setRoundTopRight(100);

        STable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(STable);

        javax.swing.GroupLayout SupliesTablePanelLayout = new javax.swing.GroupLayout(SupliesTablePanel);
        SupliesTablePanel.setLayout(SupliesTablePanelLayout);
        SupliesTablePanelLayout.setHorizontalGroup(
            SupliesTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SupliesTablePanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 879, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        SupliesTablePanelLayout.setVerticalGroup(
            SupliesTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SupliesTablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        SupliesPane.add(SupliesTablePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 940, 380));

        SSaveAllB.setBackground(new java.awt.Color(235, 104, 156));
        SSaveAllB.setForeground(new java.awt.Color(255, 255, 255));
        SSaveAllB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/guardardatos+.png"))); // NOI18N
        SSaveAllB.setText("Guardar todo");
        SSaveAllB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SSaveAllBActionPerformed(evt);
            }
        });
        SupliesPane.add(SSaveAllB, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, 210, 40));

        InventoryTabbed.addTab("Guardar Aderezos", SupliesPane);

        ModificacionesPane1.setBackground(new java.awt.Color(253, 234, 166));
        ModificacionesPane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound5.setBackground(new java.awt.Color(255, 255, 255));
        panelRound5.setRoundBottomLeft(100);
        panelRound5.setRoundBottomRight(100);
        panelRound5.setRoundTopLeft(100);
        panelRound5.setRoundTopRight(100);

        MTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(MTable1);

        javax.swing.GroupLayout panelRound5Layout = new javax.swing.GroupLayout(panelRound5);
        panelRound5.setLayout(panelRound5Layout);
        panelRound5Layout.setHorizontalGroup(
            panelRound5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound5Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 879, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        panelRound5Layout.setVerticalGroup(
            panelRound5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );

        ModificacionesPane1.add(panelRound5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 940, 260));

        MFindB2.setBackground(new java.awt.Color(104, 192, 183));
        MFindB2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Buscarpositivo.png"))); // NOI18N
        MFindB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MFindB2ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(MFindB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 60, 50, 30));
        ModificacionesPane1.add(MFindTF2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 370, 30));

        MModifyL3.setText("Ingrese el nuevo nombre del producto");
        ModificacionesPane1.add(MModifyL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, -1, 20));

        MSaveModifyB3.setBackground(new java.awt.Color(235, 104, 156));
        MSaveModifyB3.setForeground(new java.awt.Color(255, 255, 255));
        MSaveModifyB3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/guardardatos+.png"))); // NOI18N
        MSaveModifyB3.setText("Guardar");
        MSaveModifyB3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MSaveModifyB3ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(MSaveModifyB3, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 180, -1, -1));
        ModificacionesPane1.add(MModifyTF3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 180, 360, 30));

        MLoadDataB2.setBackground(new java.awt.Color(235, 104, 156));
        MLoadDataB2.setForeground(new java.awt.Color(255, 255, 255));
        MLoadDataB2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/loaddata+.png"))); // NOI18N
        MLoadDataB2.setText("Actualizar");
        MLoadDataB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MLoadDataB2ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(MLoadDataB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 330, -1, -1));

        MLoadTypeDataCB2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Sabores", "Aderezos" }));
        ModificacionesPane1.add(MLoadTypeDataCB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 330, 110, 30));

        jLabel10.setText("Tipo de datos");
        ModificacionesPane1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 340, -1, -1));

        MInformationL2.setText("Hi");
        ModificacionesPane1.add(MInformationL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 340, -1, -1));

        SDeleteAllB3.setBackground(new java.awt.Color(235, 104, 156));
        SDeleteAllB3.setForeground(new java.awt.Color(255, 255, 255));
        SDeleteAllB3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete+.png"))); // NOI18N
        SDeleteAllB3.setText("Limpiar Todo");
        SDeleteAllB3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SDeleteAllB3ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(SDeleteAllB3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 60, 140, 30));

        updateProducts1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane9.setViewportView(updateProducts1);

        ModificacionesPane1.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 600, 50));

        MModifyL4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        MModifyL4.setText("Ingrese la nueva cantidad de porciones del producto");
        ModificacionesPane1.add(MModifyL4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, -1, 30));

        MSaveModifyB4.setBackground(new java.awt.Color(235, 104, 156));
        MSaveModifyB4.setForeground(new java.awt.Color(255, 255, 255));
        MSaveModifyB4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/guardardatos+.png"))); // NOI18N
        MSaveModifyB4.setText("Guardar");
        MSaveModifyB4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MSaveModifyB4ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(MSaveModifyB4, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 240, -1, -1));

        MModifyTF4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MModifyTF4ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(MModifyTF4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 240, 360, 30));

        MFindL3.setText("Ingrese el código del aderezo que desee modificar");
        ModificacionesPane1.add(MFindL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 30, -1, 20));

        SL6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        SL6.setText("Si desea eliminar el elemento buscado, seleccione el botón \"Eliminar\"");
        ModificacionesPane1.add(SL6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 290, 390, 20));

        WMDeleteWorkerB2.setBackground(new java.awt.Color(235, 104, 156));
        WMDeleteWorkerB2.setForeground(new java.awt.Color(255, 255, 255));
        WMDeleteWorkerB2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/remove+.png"))); // NOI18N
        WMDeleteWorkerB2.setText("Eliminar");
        WMDeleteWorkerB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WMDeleteWorkerB2ActionPerformed(evt);
            }
        });
        ModificacionesPane1.add(WMDeleteWorkerB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 290, 140, 30));

        InventoryTabbed.addTab("Modificar Aderezos", ModificacionesPane1);

        ModificacionesPane.setBackground(new java.awt.Color(253, 234, 166));
        ModificacionesPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound4.setBackground(new java.awt.Color(255, 255, 255));
        panelRound4.setRoundBottomLeft(100);
        panelRound4.setRoundBottomRight(100);
        panelRound4.setRoundTopLeft(100);
        panelRound4.setRoundTopRight(100);
        panelRound4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        MFindB.setBackground(new java.awt.Color(104, 192, 183));
        MFindB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Buscarpositivo.png"))); // NOI18N
        MFindB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MFindBActionPerformed(evt);
            }
        });
        panelRound4.add(MFindB, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 60, 50, 30));
        panelRound4.add(MFindTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 370, 30));

        MModifyL.setText("Ingrese el nuevo nombre del producto");
        panelRound4.add(MModifyL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, 20));

        MSaveModifyB.setBackground(new java.awt.Color(235, 104, 156));
        MSaveModifyB.setForeground(new java.awt.Color(255, 255, 255));
        MSaveModifyB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/guardardatos+.png"))); // NOI18N
        MSaveModifyB.setText("Guardar");
        MSaveModifyB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MSaveModifyBActionPerformed(evt);
            }
        });
        panelRound4.add(MSaveModifyB, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 180, -1, -1));
        panelRound4.add(MModifyTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 180, 360, 30));

        MLoadDataB.setBackground(new java.awt.Color(235, 104, 156));
        MLoadDataB.setForeground(new java.awt.Color(255, 255, 255));
        MLoadDataB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/loaddata+.png"))); // NOI18N
        MLoadDataB.setText("Actualizar");
        MLoadDataB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MLoadDataBActionPerformed(evt);
            }
        });
        panelRound4.add(MLoadDataB, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, -1, -1));

        panelRound6.setBackground(new java.awt.Color(255, 255, 255));
        panelRound6.setRoundBottomLeft(100);
        panelRound6.setRoundBottomRight(100);
        panelRound6.setRoundTopLeft(100);
        panelRound6.setRoundTopRight(100);

        MTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(MTable);

        javax.swing.GroupLayout panelRound6Layout = new javax.swing.GroupLayout(panelRound6);
        panelRound6.setLayout(panelRound6Layout);
        panelRound6Layout.setHorizontalGroup(
            panelRound6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound6Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 879, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        panelRound6Layout.setVerticalGroup(
            panelRound6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        panelRound4.add(panelRound6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 940, 250));

        MLoadTypeDataCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Sabores", "Aderezos" }));
        panelRound4.add(MLoadTypeDataCB, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 350, 110, 30));

        jLabel1.setText("Tipo de datos");
        panelRound4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 360, -1, -1));

        MInformationL.setText("Hi");
        panelRound4.add(MInformationL, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 360, -1, -1));

        SDeleteAllB1.setBackground(new java.awt.Color(235, 104, 156));
        SDeleteAllB1.setForeground(new java.awt.Color(255, 255, 255));
        SDeleteAllB1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete+.png"))); // NOI18N
        SDeleteAllB1.setText("Limpiar Todo");
        SDeleteAllB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SDeleteAllB1ActionPerformed(evt);
            }
        });
        panelRound4.add(SDeleteAllB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 60, 140, 30));

        updateProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane8.setViewportView(updateProducts);

        panelRound4.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 600, 50));

        MModifyL2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        MModifyL2.setText("Ingrese la nueva cantidad de porciones del producto");
        panelRound4.add(MModifyL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, 30));

        MSaveModifyB2.setBackground(new java.awt.Color(235, 104, 156));
        MSaveModifyB2.setForeground(new java.awt.Color(255, 255, 255));
        MSaveModifyB2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/guardardatos+.png"))); // NOI18N
        MSaveModifyB2.setText("Guardar");
        MSaveModifyB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MSaveModifyB2ActionPerformed(evt);
            }
        });
        panelRound4.add(MSaveModifyB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 240, -1, -1));
        panelRound4.add(MModifyTF2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 240, 360, 30));

        MFindL2.setText("Ingrese el código del sabor que desee modificar");
        panelRound4.add(MFindL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 30, -1, 20));

        SL5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        SL5.setText("Si desea eliminar el elemento buscado, seleccione el botón \"Eliminar\"");
        panelRound4.add(SL5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 290, 390, 20));

        WMDeleteWorkerB1.setBackground(new java.awt.Color(235, 104, 156));
        WMDeleteWorkerB1.setForeground(new java.awt.Color(255, 255, 255));
        WMDeleteWorkerB1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/remove+.png"))); // NOI18N
        WMDeleteWorkerB1.setText("Eliminar");
        WMDeleteWorkerB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WMDeleteWorkerB1ActionPerformed(evt);
            }
        });
        panelRound4.add(WMDeleteWorkerB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 290, 140, 30));

        ModificacionesPane.add(panelRound4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 940, 610));

        InventoryTabbed.addTab("Modificar Sabores", ModificacionesPane);

        HeladeriaInteractivePanel.add(InventoryTabbed, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 0, 978, 687));

        HSellsP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SProductsPane.setBackground(new java.awt.Color(253, 234, 166));
        SProductsPane.setRoundBottomLeft(100);
        SProductsPane.setRoundBottomRight(100);
        SProductsPane.setRoundTopRight(100);
        SProductsPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SProductsTabbed.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        PConeIceCreamP.setRoundBottomLeft(100);
        PConeIceCreamP.setRoundBottomRight(100);
        PConeIceCreamP.setRoundTopRight(100);
        PConeIceCreamP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AddOption.setBackground(new java.awt.Color(235, 104, 156));
        AddOption.setForeground(new java.awt.Color(255, 255, 255));
        AddOption.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add+.png"))); // NOI18N
        AddOption.setText("Añadir");
        AddOption.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddOptionActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(AddOption, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 150, 130, -1));

        SBOFindL1.setText("Ingrese la cantidad:");
        PConeIceCreamP.add(SBOFindL1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 210, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Producto", "Código", "Porciones", "Categoría"
            }
        ));
        jScrollPane11.setViewportView(jTable2);

        PConeIceCreamP.add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 230, 380, 200));

        PortionsSelected.setBackground(new java.awt.Color(253, 234, 166));
        PortionsSelected.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortionsSelectedActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(PortionsSelected, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 220, 30));

        SBOFindL2.setText("Elija el tipo de Helado que quiere:");
        PConeIceCreamP.add(SBOFindL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, -1, -1));

        AddOption1.setBackground(new java.awt.Color(235, 104, 156));
        AddOption1.setForeground(new java.awt.Color(255, 255, 255));
        AddOption1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add+.png"))); // NOI18N
        AddOption1.setText("Añadir");
        AddOption1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddOption1ActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(AddOption1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 150, 130, -1));

        SBOFindL3.setText("Ingrese la cantidad:");
        PConeIceCreamP.add(SBOFindL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 130, 210, -1));

        PortionsDelete.setBackground(new java.awt.Color(253, 234, 166));
        PortionsDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortionsDeleteActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(PortionsDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 490, 260, 30));

        SBOFindL4.setText("Ingrese del aderezo o sabor que desea eliminar del carrito:");
        PConeIceCreamP.add(SBOFindL4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 460, -1, -1));

        SBOFindL5.setText("Ingrese el aderezo que desea agregarle a su helado:");
        PConeIceCreamP.add(SBOFindL5, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, -1, -1));

        PortionsSelected2.setBackground(new java.awt.Color(253, 234, 166));
        PortionsSelected2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortionsSelected2ActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(PortionsSelected2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 150, 220, 30));

        SRDeleteOnecar.setBackground(new java.awt.Color(235, 104, 156));
        SRDeleteOnecar.setForeground(new java.awt.Color(255, 255, 255));
        SRDeleteOnecar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/remove+.png"))); // NOI18N
        SRDeleteOnecar.setText("Eliminar");
        SRDeleteOnecar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SRDeleteOnecarActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(SRDeleteOnecar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 540, 110, 30));

        SBOFindL6.setText("Ingrese el sabor que desea agregarle a su helado:");
        PConeIceCreamP.add(SBOFindL6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        iceCream.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Vasito", "Conito", "Paleta", "De Queso", " " }));
        iceCream.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iceCreamActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(iceCream, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 40, 120, -1));

        flavorShop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flavorShopActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(flavorShop, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 290, 30));

        ToppingShop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToppingShopActionPerformed(evt);
            }
        });
        PConeIceCreamP.add(ToppingShop, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 90, 290, 30));

        SProductsTabbed.addTab("", PConeIceCreamP);

        SProductsPane.add(SProductsTabbed, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 930, 600));

        jTabbedPane1.addTab("Productos", SProductsPane);

        SBillsPane.setBackground(new java.awt.Color(253, 234, 166));
        SBillsPane.setRoundBottomLeft(100);
        SBillsPane.setRoundBottomRight(100);
        SBillsPane.setRoundTopRight(100);
        SBillsPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SOrderPanel.setRoundBottomLeft(100);
        SOrderPanel.setRoundBottomRight(100);
        SOrderPanel.setRoundTopLeft(100);
        SOrderPanel.setRoundTopRight(100);
        SOrderPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        OrderTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(OrderTable);

        SOrderPanel.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 630, 250));

        SBOTitleL.setText("Datos del pedido");
        SOrderPanel.add(SBOTitleL, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, -1, -1));

        SBOCancelSellB.setBackground(new java.awt.Color(235, 104, 156));
        SBOCancelSellB.setForeground(new java.awt.Color(255, 255, 255));
        SBOCancelSellB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cancelarventa+.png"))); // NOI18N
        SBOCancelSellB.setText("Cancelar Compra");
        SBOCancelSellB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBOCancelSellBActionPerformed(evt);
            }
        });
        SOrderPanel.add(SBOCancelSellB, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 40, -1, -1));

        SBOSellB.setBackground(new java.awt.Color(235, 104, 156));
        SBOSellB.setForeground(new java.awt.Color(255, 255, 255));
        SBOSellB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/vender+.png"))); // NOI18N
        SBOSellB.setText("Vender");
        SBOSellB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBOSellBActionPerformed(evt);
            }
        });
        SOrderPanel.add(SBOSellB, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 390, -1, 30));

        SBORefreshB.setBackground(new java.awt.Color(235, 104, 156));
        SBORefreshB.setForeground(new java.awt.Color(255, 255, 255));
        SBORefreshB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/actualizar+.png"))); // NOI18N
        SBORefreshB.setText("Actualizar");
        SBORefreshB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBORefreshBActionPerformed(evt);
            }
        });
        SOrderPanel.add(SBORefreshB, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 40, -1, -1));

        SBOSubtotalL.setText("Subtotal");
        SOrderPanel.add(SBOSubtotalL, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 360, 50, 20));

        SBOIVAL.setText("IVA");
        SOrderPanel.add(SBOIVAL, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 400, 50, 20));

        SBOTotalL.setText("Total");
        SOrderPanel.add(SBOTotalL, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 360, 50, 20));

        SBOIVAP.setBackground(new java.awt.Color(253, 234, 166));
        SBOIVAP.setRoundBottomLeft(20);
        SBOIVAP.setRoundBottomRight(20);
        SBOIVAP.setRoundTopLeft(20);
        SBOIVAP.setRoundTopRight(20);

        SBOIVAResultP.setText("00.00");

        javax.swing.GroupLayout SBOIVAPLayout = new javax.swing.GroupLayout(SBOIVAP);
        SBOIVAP.setLayout(SBOIVAPLayout);
        SBOIVAPLayout.setHorizontalGroup(
            SBOIVAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SBOIVAPLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SBOIVAResultP, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                .addContainerGap())
        );
        SBOIVAPLayout.setVerticalGroup(
            SBOIVAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SBOIVAResultP, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
        );

        SOrderPanel.add(SBOIVAP, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 400, 60, 20));

        jTextPane1.setText("\t          OFERTA\nPor más de 5 dólares de compras para nuestros clientes registrados, ofrecemos el 10% de descuento en sus compras\n");
        jScrollPane12.setViewportView(jTextPane1);

        SOrderPanel.add(jScrollPane12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 240, 270));

        totalfinal.setText("00.00");
        SOrderPanel.add(totalfinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 360, 48, 20));

        SBOTotalP.setBackground(new java.awt.Color(253, 234, 166));
        SBOTotalP.setRoundBottomLeft(20);
        SBOTotalP.setRoundBottomRight(20);
        SBOTotalP.setRoundTopLeft(20);
        SBOTotalP.setRoundTopRight(20);

        javax.swing.GroupLayout SBOTotalPLayout = new javax.swing.GroupLayout(SBOTotalP);
        SBOTotalP.setLayout(SBOTotalPLayout);
        SBOTotalPLayout.setHorizontalGroup(
            SBOTotalPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SBOTotalPLayout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addComponent(finaaal, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        SBOTotalPLayout.setVerticalGroup(
            SBOTotalPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SBOTotalPLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(finaaal, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        SOrderPanel.add(SBOTotalP, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 360, 60, 20));

        SBOSubtotalP.setBackground(new java.awt.Color(253, 234, 166));
        SBOSubtotalP.setRoundBottomLeft(20);
        SBOSubtotalP.setRoundBottomRight(20);
        SBOSubtotalP.setRoundTopLeft(20);
        SBOSubtotalP.setRoundTopRight(20);

        javax.swing.GroupLayout SBOSubtotalPLayout = new javax.swing.GroupLayout(SBOSubtotalP);
        SBOSubtotalP.setLayout(SBOSubtotalPLayout);
        SBOSubtotalPLayout.setHorizontalGroup(
            SBOSubtotalPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        SBOSubtotalPLayout.setVerticalGroup(
            SBOSubtotalPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        SOrderPanel.add(SBOSubtotalP, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 360, 60, 20));
        SOrderPanel.add(iceCreamtype, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 60, 140, -1));

        jLabel2.setText("Tipo de Helado:");
        SOrderPanel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 40, -1, -1));

        SBillsPane.add(SOrderPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 950, 430));

        SClientP.setRoundBottomLeft(100);
        SClientP.setRoundBottomRight(100);
        SClientP.setRoundTopLeft(100);
        SClientP.setRoundTopRight(100);
        SClientP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SBCTitleL.setText("Datos del Usuario");
        SClientP.add(SBCTitleL, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 6, -1, -1));

        SBCBillL.setText("Factura");
        SClientP.add(SBCBillL, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, 20));

        SBillTypeCB.setBackground(new java.awt.Color(253, 234, 166));
        SBillTypeCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Datos", "Consumidor Final" }));
        SBillTypeCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBillTypeCBActionPerformed(evt);
            }
        });
        SClientP.add(SBillTypeCB, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, 280, -1));

        LockedPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SBCNameL.setText("Nombre");
        LockedPanel.add(SBCNameL, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        SBCPhoneL.setText("Telefono");
        LockedPanel.add(SBCPhoneL, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 20));

        SBCNameTF.setBackground(new java.awt.Color(253, 234, 166));
        SBCNameTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBCNameTFActionPerformed(evt);
            }
        });
        LockedPanel.add(SBCNameTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 280, -1));

        SBCPhoneTF.setBackground(new java.awt.Color(253, 234, 166));
        SBCPhoneTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBCPhoneTFActionPerformed(evt);
            }
        });
        LockedPanel.add(SBCPhoneTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 280, -1));

        SBCIdentificationL.setText("Cedula");
        LockedPanel.add(SBCIdentificationL, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 10, -1, 20));

        SBCPaymentL.setText("Pago");
        LockedPanel.add(SBCPaymentL, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 50, -1, 20));

        SBCidTF.setBackground(new java.awt.Color(253, 234, 166));
        SBCidTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBCidTFActionPerformed(evt);
            }
        });
        LockedPanel.add(SBCidTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 10, 310, -1));
        LockedPanel.add(SBCValidation4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 70, 310, 20));
        LockedPanel.add(SBCValidation1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 280, 20));
        LockedPanel.add(SBCValidation2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, 280, 20));
        LockedPanel.add(SBCValidation3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 30, 310, 20));

        SPaymentCB.setBackground(new java.awt.Color(253, 234, 166));
        SPaymentCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Efectivo", "Transferencia", "Tarjeta" }));
        SPaymentCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SPaymentCBActionPerformed(evt);
            }
        });
        LockedPanel.add(SPaymentCB, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, 310, -1));

        SBCRegisterL.setText("Registrar");
        LockedPanel.add(SBCRegisterL, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 90, -1, 20));

        RegisterBG.add(RegisterYes);
        RegisterYes.setText("Si");
        RegisterYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterYesActionPerformed(evt);
            }
        });
        LockedPanel.add(RegisterYes, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, -1, -1));

        RegisterBG.add(RegisterNo);
        RegisterNo.setSelected(true);
        RegisterNo.setText("No");
        LockedPanel.add(RegisterNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 90, -1, -1));

        SClientP.add(LockedPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 910, 110));

        SBOFindL.setText("Buscar");
        SClientP.add(SBOFindL, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 30, -1, 20));

        SBOFindB.setBackground(new java.awt.Color(104, 192, 183));
        SBOFindB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Buscarpositivo.png"))); // NOI18N
        SBOFindB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBOFindBActionPerformed(evt);
            }
        });
        SClientP.add(SBOFindB, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 30, 60, -1));

        SBOFindTF.setBackground(new java.awt.Color(253, 234, 166));
        SBOFindTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SBOFindTFActionPerformed(evt);
            }
        });
        SClientP.add(SBOFindTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 300, -1));
        SClientP.add(FindValidation, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 10, 160, 20));

        SBillsPane.add(SClientP, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 950, 180));

        jTabbedPane1.addTab("Facturacion", SBillsPane);

        SRegistersPane.setBackground(new java.awt.Color(253, 234, 166));
        SRegistersPane.setRoundBottomLeft(100);
        SRegistersPane.setRoundBottomRight(100);
        SRegistersPane.setRoundTopRight(100);
        SRegistersPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SRLoadDataRegisterB.setBackground(new java.awt.Color(235, 104, 156));
        SRLoadDataRegisterB.setForeground(new java.awt.Color(255, 255, 255));
        SRLoadDataRegisterB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/loaddata+.png"))); // NOI18N
        SRLoadDataRegisterB.setText("Cargar/Refrescar");
        SRLoadDataRegisterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SRLoadDataRegisterBActionPerformed(evt);
            }
        });
        SRegistersPane.add(SRLoadDataRegisterB, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 30, -1, -1));

        panelRound10.setBackground(new java.awt.Color(255, 255, 255));
        panelRound10.setRoundBottomLeft(100);
        panelRound10.setRoundBottomRight(100);
        panelRound10.setRoundTopLeft(100);
        panelRound10.setRoundTopRight(100);

        RegistersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(RegistersTable);

        javax.swing.GroupLayout panelRound10Layout = new javax.swing.GroupLayout(panelRound10);
        panelRound10.setLayout(panelRound10Layout);
        panelRound10Layout.setHorizontalGroup(
            panelRound10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound10Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 916, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        panelRound10Layout.setVerticalGroup(
            panelRound10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound10Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        SRegistersPane.add(panelRound10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 950, 540));

        jTabbedPane1.addTab("Registro de ventas", SRegistersPane);

        HSellsP.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 970, 680));

        HeladeriaInteractivePanel.add(HSellsP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 1010, 760));

        getContentPane().add(HeladeriaInteractivePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 0, 1010, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UserManualBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserManualBActionPerformed
        // TODO add your handling code here:
        UserManual UM = new UserManual();
        UM.setVisible(true);
        
    }//GEN-LAST:event_UserManualBActionPerformed

    private void ExitBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitBActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_ExitBActionPerformed

    private void SettingsBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SettingsBActionPerformed
        codeAdmin S = new codeAdmin();
        S.setLocationRelativeTo(null);
        S.setVisible(true);
    }//GEN-LAST:event_SettingsBActionPerformed

    private void TCuantityTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TCuantityTFActionPerformed

    }//GEN-LAST:event_TCuantityTFActionPerformed

    private void SQuantityTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SQuantityTFActionPerformed

    }//GEN-LAST:event_SQuantityTFActionPerformed
    
    private void TSaveAllBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TSaveAllBActionPerformed
        String Product = TNameTF.getText();
        String Code = TCodeTF.getText();
        String Quantity = TCuantityTF.getText();
        
        cF.validData(Product, Code, Quantity, TNameTF, TCuantityTF, TCodeTF);
        rF.LoadDataTaste(TTable);
    }//GEN-LAST:event_TSaveAllBActionPerformed

    private void SSaveAllBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SSaveAllBActionPerformed
        String Product = SNameTF.getText();
        String Code = SCodeTF.getText();
        String Quantity = SQuantityTF.getText();
        cT.validData(Product, Code, Quantity, SNameTF, SQuantityTF, SCodeTF);
        rT.LoadDataSuplies(STable);
        
    }//GEN-LAST:event_SSaveAllBActionPerformed

    private void ChangeUserBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangeUserBActionPerformed
    cU.changeUser(this);
    }//GEN-LAST:event_ChangeUserBActionPerformed

    private void InventoryBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InventoryBActionPerformed
     iF.seeInventary( InventoryTabbed, HSellsP);
    }//GEN-LAST:event_InventoryBActionPerformed

    private void SellsBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SellsBActionPerformed
        // TODO add your handling code here:
        HSellsP.setVisible(true);
        InventoryTabbed.setVisible(false);
    }//GEN-LAST:event_SellsBActionPerformed

    private void SBCPhoneTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBCPhoneTFActionPerformed
        // TODO add your handling code here:
        String PhoneClient = SBCPhoneTF.getText();
        String IDClient = SBCidTF.getText();
        vP.validData(PhoneClient, IDClient, SBCValidation2);
    }//GEN-LAST:event_SBCPhoneTFActionPerformed

    private void SNameTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SNameTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SNameTFActionPerformed

    private void SBillTypeCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBillTypeCBActionPerformed
        // TODO add your handling code here:
        eD.validDataComboBox(SBillTypeCB,LockedPanel,SBCNameTF,SBCPhoneTF,SBCidTF );
    }//GEN-LAST:event_SBillTypeCBActionPerformed

    private void SBOSellBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBOSellBActionPerformed
        String selectedBill = (String) SBillTypeCB.getSelectedItem();
        String nameClient = SBCNameTF.getText();
        String phoneClient = SBCPhoneTF.getText();
        String idClient = SBCidTF.getText();
        String paymentClient = (String) SPaymentCB.getSelectedItem();
        saveClient sC=new saveClient();
       sC.validData(selectedBill, nameClient, phoneClient, paymentClient, idClient, SBCValidation1, SBCValidation2, SBCValidation3, SBCValidation4, jTable2, OrderTable, iceCreamtype, PortionsDelete, iceCream, finaaal, totalfinal, SBOIVAResultP, RegisterYes, RegisterNo); 
    }//GEN-LAST:event_SBOSellBActionPerformed
    private void RegisterYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterYesActionPerformed
    }//GEN-LAST:event_RegisterYesActionPerformed

    private void SBCNameTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBCNameTFActionPerformed
                                     
        // TODO add your handling code here:
        String NameClient = SBCNameTF.getText();
        if(NameClient.isEmpty()){
            SBCValidation1.setText("¡Este campo es obligatorio!");
            SBCValidation1.setForeground(Color.RED);
        }else{
            try(MongoClient mongoClient = MongoClients.create(dir)){
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("RegistroClientes");
                
                Document query = new Document("Nombre",NameClient);
                
                FindIterable<Document> documents = collection.find(query);
                
                if(documents.iterator().hasNext()){
                    SBCValidation1.setText("Este nombre ya esta en uso, ingresa otro para registrar");
                    SBCValidation1.setForeground(Color.RED);
                }else{
                    SBCValidation1.setText("");
                }
            }catch(MongoException e){
                System.out.println("ERROR AL BUSCAR EL NOMBRE");
            }
        }
    }//GEN-LAST:event_SBCNameTFActionPerformed

    private void SBCidTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBCidTFActionPerformed
        // TODO add your handling code here:
        String IDClient = SBCidTF.getText();
        String PhoneClient = SBCPhoneTF.getText();
        if(IDClient.isEmpty()){
            SBCValidation3.setText("¡Este campo es obligatorio!");
            SBCValidation3.setForeground(Color.RED);
        }else{
            if(IDClient.length()!=10 || IDClient==PhoneClient){
                SBCValidation3.setText("La cedula debe tener 10 digitos numericos y ser diferente al telefono");
            }else{
                    try(MongoClient mongoClient = MongoClients.create(dir)){
                        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                        MongoCollection<Document> collection = database.getCollection("RegistroClientes");

                        Document query = new Document("Cedula",IDClient);

                        FindIterable<Document> documents = collection.find(query);

                        if(documents.iterator().hasNext()){
                            SBCValidation3.setText("Esta cedula ya esta en uso, ingresa otra para registrar");
                            SBCValidation3.setForeground(Color.RED);
                        }else{
                            SBCValidation3.setText("");
                        }
                    }catch(MongoException e){
                        System.out.println("ERROR AL BUSCAR LA CEDULA");
                    }
            }
        }      
    }//GEN-LAST:event_SBCidTFActionPerformed

    private void SPaymentCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SPaymentCBActionPerformed
        // TODO add your handling code here:
        String SelectedPaymethod = (String) SPaymentCB.getSelectedItem();
        if(SelectedPaymethod=="Seleccione"){
            SBCValidation4.setText("¡Selecciona un metodo de pago valido!");
            SBCValidation4.setForeground(Color.RED);
        }else if(SelectedPaymethod=="Efectivo"){
                    // Crear un JTextField para que el usuario ingrese la cantidad
            JTextField MontoRecibido = new JTextField();
            Object[] message = {
                "Monto recibido:", MontoRecibido
            };

            int option = JOptionPane.showConfirmDialog(this, message, "Ingresar Monto", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                // Obtener la cantidad ingresada
                String amountStr = MontoRecibido.getText();
            }
            SBCValidation4.setText("");
        }else if(SelectedPaymethod=="Transferencia"){
            JOptionPane.showConfirmDialog(this, "Banco: Pichincha\nTipo de cuenta: Ahorros\nCuenta: 2200337799\nRUC: 1723456890001\nEsperando transferencia...", "Datos de la cuenta", JOptionPane.OK_CANCEL_OPTION);
            SBCValidation4.setText("");
        }else if(SelectedPaymethod=="Tarjeta"){
            CardDialog.setVisible(true);
            SBCValidation4.setText("");
        }
    }//GEN-LAST:event_SPaymentCBActionPerformed

    private void CardNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CardNameActionPerformed
        // TODO add your handling code here:
        String CName = CardName.getText();
        
        String CSecurityC = CardSC.getText();
        if(CName.isEmpty()){
            ValidationCName.setText("¡Este campo es obligatorio!");
            ValidationCName.setForeground(Color.RED);
        }else{
            ValidationCName.setText("");
        }
    }//GEN-LAST:event_CardNameActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        CardDialog.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        CardDialog.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void CardNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CardNumberActionPerformed
        // TODO add your handling code here:
        String CNumber = CardNumber.getText();
        if(CNumber.isEmpty()){
            ValidationCNumber.setText("¡Este campo es obligatorio!");
            ValidationCNumber.setForeground(Color.RED);
        }else if(CNumber.length()!=13){
            ValidationCNumber.setText("La tarjeta ingresada no es valida, ingresa una de 13 caracteres numericos");
        }else{
            ValidationCNumber.setText("");
        }
    }//GEN-LAST:event_CardNumberActionPerformed

    private void CardExpirationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CardExpirationActionPerformed
        // TODO add your handling code here:
        String CExpiration = CardExpiration.getText();
        if (CExpiration.isEmpty()) {
            ValidationCEMM.setText("¡Este campo es obligatorio!");
            ValidationCEMM.setForeground(Color.RED);
        } else if (!CExpiration.matches("^(0[1-9]|1[0-2])$")) {
            ValidationCEMM.setText("El mes no es válido");
            ValidationCEMM.setForeground(Color.RED);
        } else {
            ValidationCEMM.setText("");
        }
    }//GEN-LAST:event_CardExpirationActionPerformed

    private void CardSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CardSCActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_CardSCActionPerformed

    private void YYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YYActionPerformed
        // TODO add your handling code here:

        String CExpiration = YY.getText();
        if (CExpiration.isEmpty()) {
            ValidationCEMM.setText("¡Este campo es obligatorio!");
            ValidationCEMM.setForeground(Color.RED);
        } else if (!CExpiration.matches("^(1[5-9]|2[0-8])$")) {
            ValidationCEMM.setText("El año no es válido");
            ValidationCEMM.setForeground(Color.RED);
        } else {
            ValidationCEMM.setText("");
        }
    }//GEN-LAST:event_YYActionPerformed
    private void SBOFindTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBOFindTFActionPerformed
        // TODO add your handling code here:
        String find = SBOFindTF.getText().trim();
        if (find.isEmpty()) {
            FindValidation.setText("¡Ingresa datos para buscar!");
        } else {
            // Verificar si el valor ingresado contiene solo dígitos (posiblemente una cédula)
            if (find.matches("\\d+")) {
                sF.buscarPorCedula(find, FindValidation, SBCNameTF, SBCPhoneTF, SBCidTF);
            } else {
                sF.buscarPorNombre(find, FindValidation, SBCNameTF, SBCPhoneTF, SBCidTF);
            }
        }    
    }//GEN-LAST:event_SBOFindTFActionPerformed

    private void SBOFindBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBOFindBActionPerformed
        // TODO add your handling code here:
                // TODO add your handling code here:
        String find = SBOFindTF.getText().trim();
        if (find.isEmpty()) {
            FindValidation.setText("¡Ingresa datos para buscar!");
        } else {
            // Verificar si el valor ingresado contiene solo dígitos (posiblemente una cédula)
            if (find.matches("\\d+")) {
                sF.buscarPorCedula(find, FindValidation, SBCNameTF, SBCPhoneTF, SBCidTF);
            } else {
                sF.buscarPorNombre(find, FindValidation, SBCNameTF, SBCPhoneTF, SBCidTF);
            }
        }
    }//GEN-LAST:event_SBOFindBActionPerformed

    private void SBORefreshBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBORefreshBActionPerformed
       rC.updateTable(jTable2,OrderTable,iceCreamtype ,PortionsDelete,iceCream);
    }//GEN-LAST:event_SBORefreshBActionPerformed

    private void SRLoadDataRegisterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SRLoadDataRegisterBActionPerformed
        rI.seeInvoices(RegistersTable);
    }//GEN-LAST:event_SRLoadDataRegisterBActionPerformed

    private void AddOptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddOptionActionPerformed
    String productSelected=flavorShop.getSelectedItem().toString();
        if(productSelected.isEmpty()||PortionsSelected.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Llene todos los compos", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }//controla que los campos estén llenos
        if (!PortionsSelected.getText().matches("([1-5])")) {
            JOptionPane.showMessageDialog(this, "Ingrese un valor numérico para la cantidad(Máximo 5)", "Error", JOptionPane.ERROR_MESSAGE);
            PortionsSelected.setText(null);
            return;
        }


//controla que solo se pueda elegir una catidad maxima de 7 (obiamente si se elige sabores que es de 5 ya se controla mas adelante)
        int portionsSelected=Integer.parseInt(PortionsSelected.getText());
        MongoClient mongoClient = (MongoClient) MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionFlavors = database.getCollection("Sabores");
        Document filter=new Document("Producto:",productSelected);
        Document flavors=collectionFlavors.find(filter).first();
        DefaultTableModel modelTable=new DefaultTableModel();
        modelTable.addColumn("Producto");
        modelTable.addColumn("Código");
        modelTable.addColumn("Porciones");
        modelTable.addColumn("Categoría");

        if(flavors==null){
            JOptionPane.showMessageDialog(this, "Sabor ingresado no encontrado","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(portionsSelected>5){
            JOptionPane.showMessageDialog(this, "No puede elegir más de 5 porciones de sabores", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int portions = Integer.parseInt(flavors.getString("Porciones:"));
        String code=flavors.getString("Código:");
        int totalPortionscat = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        System.out.print(totalPortionscat);
        if(portions==0){
            JOptionPane.showMessageDialog(this, "Producto agotado", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si el producto está en 0
        }
        if(portions<portionsSelected){
            JOptionPane.showMessageDialog(this, "La cantidad de porciones elegidas sobrepasa la existente", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si la cantidad seleccionada sobrepasa a la disponible
        }
        if(totalPortionscat+portionsSelected>5){
            JOptionPane.showMessageDialog(this, "Sobrepasa la cantidad de sabores a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(totalPortionscat>=5){
            JOptionPane.showMessageDialog(this, "Sobrepasa la cantidad de sabores a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control para que no pase de 5 sabores totales elegidos
        }
        int Portions=portions-portionsSelected;
        String newPortions=String.valueOf(Portions);
        Document update=new Document("$set",new Document("Porciones:",newPortions));
        collectionFlavors.updateOne(filter,update);//actualiza la base principal disminuyendo lo que pidio el cliente
        Document filter2=new Document("Código:",code);
        MongoCollection<Document>collection=database.getCollection("Carrito");
        Document carProducts=collection.find(filter2).first();
        System.out.print(carProducts);
        if(carProducts!=null){
            int newcarPortion =carProducts.getInteger("Porciones:") + portionsSelected;
            Document update2=new Document("$set",new Document("Porciones:",newcarPortion));
            collection.updateOne(filter2,update2);//actualiza solo la cantidad en el carrito si el cliente vuelve a elegir el mismo producto
        }else{
            Document documentCar=new Document()
            .append("Producto:",flavors.getString("Producto:"))
            .append("Código:", flavors.getString("Código:"))
            .append("Porciones:", portionsSelected)
            .append("Categoría:","Sabores");
            collection.insertOne(documentCar);//actualiza el carrito agregando el nuevo sabor/aderezo que eligió el cliente
        }
        FindIterable<Document> documents = collection.find();
        for (Document document : documents) {
            String[] dataProduct = {
                document.getString("Producto:"),
                document.getString("Código:"),
                String.valueOf(document.getInteger("Porciones:")),
                document.getString("Categoría:")
            };
            modelTable.addRow(dataProduct);
        }//muestra en la tabla lo que el cliente eligió
        jTable2.setModel(modelTable);
        OrderTable.setModel(modelTable);
        JOptionPane.showMessageDialog(this, "Sabor agregado");
        float value=(float) 1.0;
        int totalPortionscat2 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        int totalPortionscat3 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        float Prize=(totalPortionscat2+totalPortionscat3)*value;
        String cream=iceCream.getSelectedItem().toString();
        float PrizeIce=0;
        if(cream=="Vasito"){
            PrizeIce=1;
        }else{
            if(cream=="Conito"){
                PrizeIce=(float) 1.25;
            }else{
                if(cream=="Paleta"){
                    PrizeIce=(float) 0.50;
                }else{
                    PrizeIce=2;
                }
            }
        }
        float totalPrize=Prize+PrizeIce;
        String totalPrizes = String.valueOf(totalPrize);
        totalfinal.setText(totalPrizes);
                    double iva=totalPrize*0.12;
                    SBOIVAResultP.setText(String.valueOf(iva));
                    double finale=totalPrize+iva;
                    finaaal.setText(String.valueOf(finale));
        
    }//GEN-LAST:event_AddOptionActionPerformed
   
    private void PortionsSelectedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PortionsSelectedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PortionsSelectedActionPerformed

    private void AddOption1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddOption1ActionPerformed
    String ProductSelected1=ToppingShop.getSelectedItem().toString();
        if(ProductSelected1.isEmpty()||PortionsSelected2.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Llene todos los compos", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }//controla que los campos estén llenos
        if (!PortionsSelected2.getText().matches("([1-7])")) {
            JOptionPane.showMessageDialog(this, "Ingrese un valor numérico para la cantidad(Máximo 7)", "Error", JOptionPane.ERROR_MESSAGE);
            PortionsSelected2.setText(null);
            return;
        }//controla que solo se pueda elegir una catidad maxima de 7 (obiamente si se elige sabores que es de 5 ya se controla mas adelante)
        int portionsSelected=Integer.parseInt(PortionsSelected2.getText());
        MongoClient mongoClient = (MongoClient) MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionDressings = database.getCollection("Aderezos");
        Document filter=new Document("Producto:",ProductSelected1);
        Document dressings=collectionDressings.find(filter).first();
        DefaultTableModel modelTable=new DefaultTableModel();
        modelTable.addColumn("Producto");
        modelTable.addColumn("Código");
        modelTable.addColumn("Porciones");
        modelTable.addColumn("Categoría"); // TODO add your handling code here:
        if(dressings==null){
            JOptionPane.showMessageDialog(this, "Aderezo ingresado no encontrado","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(portionsSelected>7){
            JOptionPane.showMessageDialog(this, "No puede elegir más de 7 porciones de aderezo", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int portions = Integer.parseInt(dressings.getString("Porciones:"));
        String code=dressings.getString("Código:");
        int totalPortionscat = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        System.out.print(totalPortionscat);
        if(portions==0){
            JOptionPane.showMessageDialog(this, "Producto agotado", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si el producto está en 0
        }
        if(portions<portionsSelected){
            JOptionPane.showMessageDialog(this, "La cantidad de porciones elegidas sobrepasa la existente", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control si la cantidad seleccionada sobrepasa a la disponible
        }
        if(totalPortionscat+portionsSelected>7){
            JOptionPane.showMessageDialog(this, "Sobrepasa la cantidad de aderezos a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(totalPortionscat>=7){
            JOptionPane.showMessageDialog(this, "Sobrepasa la cantidad de aderezos a elegir", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;//control para que no pase de 5 sabores totales elegidos
        }
        int Portions=portions-portionsSelected;
        String newPortions=String.valueOf(Portions);
        Document update=new Document("$set",new Document("Porciones:",newPortions));
        collectionDressings.updateOne(filter,update);//actualiza la base principal disminuyendo lo que pidio el cliente
        Document filter2=new Document("Código:",code);
        MongoCollection<Document>collection=database.getCollection("Carrito");
        Document carProducts=collection.find(filter2).first();
        System.out.print(carProducts);
        if(carProducts!=null){
            int newcarPortion =carProducts.getInteger("Porciones:") + portionsSelected;
            Document update2=new Document("$set",new Document("Porciones:",newcarPortion));
            collection.updateOne(filter2,update2);//actualiza solo la cantidad en el carrito si el cliente vuelve a elegir el mismo producto
        }else{
            Document documentCar=new Document()
            .append("Producto:",dressings.getString("Producto:"))
            .append("Código:", dressings.getString("Código:"))
            .append("Porciones:", portionsSelected)
            .append("Categoría:","Aderezos");
            collection.insertOne(documentCar);//actualiza el carrito agregando el nuevo sabor/aderezo que eligió el cliente
        }
        FindIterable<Document> documents = collection.find();
        for (Document document : documents) {
            String[] dataProduct = {
                document.getString("Producto:"),
                document.getString("Código:"),
                String.valueOf(document.getInteger("Porciones:")),
                document.getString("Categoría:")
            };
            modelTable.addRow(dataProduct);
        }//muestra en la tabla lo que el cliente eligió
        jTable2.setModel(modelTable);
        OrderTable.setModel(modelTable);
        JOptionPane.showMessageDialog(this, "Aderezo agregado");
        float value=(float) 0.75;
        int totalPortionscat2 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Sabores");
        int totalPortionscat3 = tPC.totalPortionscategory(database.getCollection("Carrito"), "Aderezos");
        float Prize=(totalPortionscat2+totalPortionscat3)*value;
        String cream=iceCream.getSelectedItem().toString();
        float PrizeIce=0;
        if(cream=="Vasito"){
            PrizeIce=1;
        }else{
            if(cream=="Conito"){
                PrizeIce=(float) 1.25;
            }else{
                if(cream=="Paleta"){
                    PrizeIce=(float) 0.50;
                }else{
                    PrizeIce=2;
                }
            }
        }
        float totalPrize=Prize+PrizeIce;
        String totalPrizes = String.valueOf(totalPrize);
        totalfinal.setText(totalPrizes);
        double iva=totalPrize*0.12;
                    SBOIVAResultP.setText(String.valueOf(iva));
                    double finale=totalPrize+iva;
                    finaaal.setText(String.valueOf(finale));
    }//GEN-LAST:event_AddOption1ActionPerformed

    private void PortionsDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PortionsDeleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PortionsDeleteActionPerformed

    private void PortionsSelected2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PortionsSelected2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PortionsSelected2ActionPerformed

    private void SRDeleteOnecarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SRDeleteOnecarActionPerformed
        String delete= PortionsDelete.getText();
        deleteOneCar dOC=new deleteOneCar();
        dOC.deleteProductoCar( delete);
        dOC.addTable( jTable2,  PortionsDelete, iceCream, totalfinal,SBOIVAResultP,finaaal  );
    }//GEN-LAST:event_SRDeleteOnecarActionPerformed

    private void MFindBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MFindBActionPerformed
        String newCode= MFindTF.getText();
        if (!newCode.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Sabores");
        Document query = new Document("Código:", newCode);
        long count= collection.countDocuments(query);

        if(count<=0){
            JOptionPane.showMessageDialog(this, "La cedula ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            DefaultTableModel tableModel = (DefaultTableModel) updateProducts.getModel();
            tableModel.setRowCount(0);
            tableModel.setColumnIdentifiers(new String []{"Producto","Código","Cantidad"});
            FindIterable<Document> documents = collection.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Producto:"),
                    document.get("Código:"),
                    document.get("Porciones:")
                });  }
                updateProducts.setModel(tableModel);
                updateProducts.revalidate();
                updateProducts.repaint();
            }

            // TODO add your handling code here:
    }//GEN-LAST:event_MFindBActionPerformed

    private void MSaveModifyBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MSaveModifyBActionPerformed
        String idSearch= MFindTF.getText();
        String nameNew=MModifyTF.getText();
        if (nameNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}

        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Inventario");
        MongoCollection<Document> collectionn = database.getCollection("Sabores");
        Document query = new Document("Código:", idSearch);
        long count= collection.countDocuments(query);
        Document queryy = new Document("Producto:", nameNew);
        long countt= collection.countDocuments(queryy);

        if(count<=0){
            JOptionPane.showMessageDialog(this, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(countt<=0){
        }else{
            JOptionPane.showMessageDialog(this, "El nombre ingresado ya está siendo utilizado para otro sabor", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Document act= new Document("$set",new Document("Producto:", nameNew));
        collection.updateOne(query, act);
        collectionn.updateOne(query, act);
        JOptionPane.showMessageDialog(this, "Nombre del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
        pSB.añadirProdComboBox(flavorShop);
        MFindTF.setText("");
        MModifyTF.setText("");
        MModifyTF2.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_MSaveModifyBActionPerformed

    private void MLoadDataBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MLoadDataBActionPerformed
        // TODO add your handling code here:
        String Selected = (String) MLoadTypeDataCB.getSelectedItem();
        if(Selected=="Seleccione"){
            JOptionPane.showMessageDialog(this,"Selecciona el tipo de datos para cargar","Seleccion nula",JOptionPane.WARNING_MESSAGE);
        }else{
            if(Selected=="Sabores"){
                MInformationL.setText("Datos cargados de tipo: Sabores");
                MongoClient mongoClient = MongoClients.create(dir);
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("Sabores");

                FindIterable<Document> documents = collection.find();
                DefaultTableModel model;
                model = new DefaultTableModel();
                model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});

                for(Document document : documents){
                    Vector<Object> Row = new Vector<>();
                    Row.add(document.getString("Producto:"));
                    Row.add(document.getString("Código:"));
                    Row.add(document.getString("Porciones:"));

                    model.addRow(Row);

                }MTable.setModel(model);

            }else if(Selected =="Aderezos"){
                MongoClient mongoClient = MongoClients.create(dir);
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("Aderezos");

                FindIterable<Document> documents = collection.find();
                DefaultTableModel model;
                model = new DefaultTableModel();
                model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});

                for(Document document : documents){
                    Vector<Object> Row = new Vector<>();
                    Row.add(document.getString("Producto:"));
                    Row.add(document.getString("Código:"));
                    Row.add(document.getString("Porciones:"));

                    model.addRow(Row);

                }MTable.setModel(model);
                MInformationL.setText("Datos cargados de tipo: Aderezos");
            }
        }
    }//GEN-LAST:event_MLoadDataBActionPerformed

    private void SDeleteAllB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SDeleteAllB1ActionPerformed
        MFindTF.setText("");
        DefaultTableModel model = (DefaultTableModel) updateProducts.getModel();
        model.setRowCount(0);

    }//GEN-LAST:event_SDeleteAllB1ActionPerformed

    private void MSaveModifyB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MSaveModifyB2ActionPerformed
        String idSearch= MFindTF.getText();
        String quantiNew=MModifyTF2.getText();
        if (quantiNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        try {
            int stockr = Integer.parseInt(quantiNew);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Inventario");
        MongoCollection<Document> collectionn = database.getCollection("Sabores");

        Document query = new Document("Código:", idSearch);
        long count= collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(this, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            Document act= new Document("$set",new Document("Porciones:", quantiNew));
            collection.updateOne(query, act);
            collectionn.updateOne(query, act);
            JOptionPane.showMessageDialog(this, "Cantidad del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

        }
        MFindTF.setText("");
        MModifyTF.setText("");
        MModifyTF2.setText("");   // TODO add your handling code here:
    }//GEN-LAST:event_MSaveModifyB2ActionPerformed

    private void WMDeleteWorkerB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WMDeleteWorkerB1ActionPerformed
        String idSearch= MFindTF.getText();
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Sabores");
        Document query = new Document("Código:", idSearch);
        collection.deleteOne(query);
        JOptionPane.showMessageDialog(this, "Sabor eliminado exitosamente", "Error", JOptionPane.INFORMATION_MESSAGE);

        MFindTF.setText("");
        MModifyTF.setText("");
        MModifyTF2.setText("");
        DefaultTableModel model = (DefaultTableModel) updateProducts.getModel();
        model.setRowCount(0);
        pSB.añadirProdComboBox(flavorShop);
        // TODO add your handling code here:
    }//GEN-LAST:event_WMDeleteWorkerB1ActionPerformed

    private void MFindB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MFindB2ActionPerformed
        String newCode= MFindTF2.getText();
        if (!newCode.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        Document query = new Document("Código:", newCode);
        long count= collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(this, "El código ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            DefaultTableModel tableModel = (DefaultTableModel) updateProducts1.getModel();
            tableModel.setRowCount(0);
            tableModel.setColumnIdentifiers(new String []{"Producto","Código","Cantidad"});
            FindIterable<Document> documents = collection.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Producto:"),
                    document.get("Código:"),
                    document.get("Porciones:")
                });  }
                updateProducts1.setModel(tableModel);
                updateProducts1.revalidate();
                updateProducts1.repaint();
            }

            // TODO add your handling code here:
    }//GEN-LAST:event_MFindB2ActionPerformed

    private void MSaveModifyB3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MSaveModifyB3ActionPerformed
        String idSearch= MFindTF2.getText();
        String nameNew=MModifyTF3.getText();
        if (nameNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}

        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Aderezos");
        Document query = new Document("Código:", idSearch);
        long count= collectionn.countDocuments(query);
        Document queryy = new Document("Producto:", nameNew);
        long countt= collectionn.countDocuments(queryy);

        if(count<=0){
            JOptionPane.showMessageDialog(this, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if( countt <= 0){
        }else {
            JOptionPane.showMessageDialog(this, "El nombre del aderezo indicado ya existe dentro de los datos ingresados, por favor ingrese un aderezo distinto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Document act= new Document("$set",new Document("Producto:", nameNew));
        collectionn.updateOne(query, act);
        JOptionPane.showMessageDialog(this, "Nombre del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

        MFindTF2.setText("");
        MModifyTF3.setText("");
        MModifyTF4.setText("");
        pAB.añadirProdComboBox(ToppingShop);
        // TODO add your handling code here:
        // TODO add your handling code here:
    }//GEN-LAST:event_MSaveModifyB3ActionPerformed

    private void MLoadDataB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MLoadDataB2ActionPerformed
        String Selected = (String) MLoadTypeDataCB2.getSelectedItem();
        if(Selected=="Seleccione"){
            JOptionPane.showMessageDialog(this,"Selecciona el tipo de datos para cargar","Seleccion nula",JOptionPane.WARNING_MESSAGE);
        }else{
            if(Selected=="Sabores"){
                MInformationL2.setText("Datos cargados de tipo: Sabores");
                MongoClient mongoClient = MongoClients.create(dir);
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("Sabores");

                FindIterable<Document> documents = collection.find();
                DefaultTableModel model;
                model = new DefaultTableModel();
                model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});

                for(Document document : documents){
                    Vector<Object> Row = new Vector<>();
                    Row.add(document.getString("Producto:"));
                    Row.add(document.getString("Código:"));
                    Row.add(document.getString("Porciones:"));

                    model.addRow(Row);

                }MTable1.setModel(model);

            }else if(Selected =="Aderezos"){
                MongoClient mongoClient = MongoClients.create(dir);
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("Aderezos");

                FindIterable<Document> documents = collection.find();
                DefaultTableModel model;
                model = new DefaultTableModel();
                model.setColumnIdentifiers(new String []{"Producto", "Código", "Cantidad"});

                for(Document document : documents){
                    Vector<Object> Row = new Vector<>();
                    Row.add(document.getString("Producto:"));
                    Row.add(document.getString("Código:"));
                    Row.add(document.getString("Porciones:"));

                    model.addRow(Row);

                }MTable1.setModel(model);
                MInformationL2.setText("Datos cargados de tipo: Aderezos");
            }
        }        // TODO add your handling code here:
    }//GEN-LAST:event_MLoadDataB2ActionPerformed

    private void SDeleteAllB3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SDeleteAllB3ActionPerformed
        MFindTF2.setText("");
        DefaultTableModel model = (DefaultTableModel) updateProducts1.getModel();
        model.setRowCount(0);  // TODO add your handling code here:
    }//GEN-LAST:event_SDeleteAllB3ActionPerformed

    private void MSaveModifyB4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MSaveModifyB4ActionPerformed
        String idSearch= MFindTF2.getText();
        String quantiNew=MModifyTF4.getText();
        if (quantiNew.isEmpty() || idSearch.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Ingrese algun dato para actualizar", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        try {
            int stockr = Integer.parseInt(quantiNew);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!idSearch.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Inventario");
        MongoCollection<Document> collectionn = database.getCollection("Aderezos");

        Document query = new Document("Código:", idSearch);
        long count= collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(this, "El codigo ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            Document act= new Document("$set",new Document("Porciones:", quantiNew));
            collection.updateOne(query, act);
            collectionn.updateOne(query, act);
            JOptionPane.showMessageDialog(this, "Cantidad del Producto actualizado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

        }
        MFindTF2.setText("");
        MModifyTF2.setText("");
        MModifyTF4.setText("");   // TODO add your handling code here:
        // TODO add your handling code here:
    }//GEN-LAST:event_MSaveModifyB4ActionPerformed

    private void MModifyTF4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MModifyTF4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MModifyTF4ActionPerformed

    private void WMDeleteWorkerB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WMDeleteWorkerB2ActionPerformed
        String idSearch= MFindTF2.getText();
        String dir = "mongodb://localhost:27017";
        MongoClient mongoClient = (MongoClient) MongoClients.create(dir);
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        Document query = new Document("Código:", idSearch);
        collection.deleteOne(query);
        JOptionPane.showMessageDialog(this, "Aderezo eliminado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);

        MFindTF2.setText("");
        MModifyTF2.setText("");
        MModifyTF4.setText("");
        DefaultTableModel model = (DefaultTableModel) updateProducts1.getModel();
        model.setRowCount(0);  
        pAB.añadirProdComboBox(ToppingShop);// TODO add your handling code here:
    }//GEN-LAST:event_WMDeleteWorkerB2ActionPerformed

    private void SBOCancelSellBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SBOCancelSellBActionPerformed
        initializeMongo iM=new initializeMongo();
        iM.openMongo();
        iM.getDatabase();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> carritoCollection = database.getCollection("Carrito");
        moverAColecciones(database, carritoCollection);// TODO add your handling code here:
        JOptionPane.showMessageDialog(this, "Compra cancelada exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
        rC.updateTable(jTable2,OrderTable,iceCreamtype ,PortionsDelete,iceCream);
        PortionsSelected.setText("");
        PortionsSelected2.setText("");
    }//GEN-LAST:event_SBOCancelSellBActionPerformed
public void moverAColecciones(MongoDatabase database, MongoCollection<Document> carritoCollection) {
    MongoCollection<Document> saboresCollection = database.getCollection("Sabores");
    MongoCollection<Document> aderezosCollection = database.getCollection("Aderezos"); 
    FindIterable<Document> carritoDocuments = carritoCollection.find();
    for (Document carritoDocument : carritoDocuments) {
        String categoria = carritoDocument.getString("Categoría:");
        String producto = carritoDocument.getString("Producto:");
        int porciones = carritoDocument.getInteger("Porciones:", 0);
        // Actualizar la colección correspondiente (Sabores o Aderezos)
        if ("Sabores".equals(categoria)) {
            actualizarColeccion(saboresCollection, producto, porciones);
        } else if ("Aderezos".equals(categoria)) {
            actualizarColeccion(aderezosCollection, producto, porciones);
        }
        // Eliminar el documento de la colección "Carrito" si es necesario
        carritoCollection.deleteOne(carritoDocument);
    }
}

private void actualizarColeccion(MongoCollection<Document> collection, String producto, int porciones) {
    Document filter = new Document("Producto:", producto);
    Document existingDocument = collection.find(filter).first();

    if (existingDocument != null) {
        String porcionesString = existingDocument.getString("Porciones:");

// Convertir a int usando Integer.parseInt()
    int existingPorciones = 0;  // Valor predeterminado en caso de que la cadena no sea un número válido
    if (porcionesString != null) {
        existingPorciones = Integer.parseInt(porcionesString);
    }
        //int existingPorciones = existingDocument.getInteger("Porciones:", 0);
        // Sumar directamente a la variable de tipo int
        int newPorciones = existingPorciones + porciones;
        // Actualizar porciones en la colección correspondiente
        Document update = new Document("$set", new Document("Porciones:", Integer.toString(newPorciones)));
        collection.updateOne(filter, update);
    } else {
        // Insertar un nuevo documento si no existe en la colección
        Document newDocument = new Document()
                .append("Producto:", producto)
                .append("Porciones:", porciones);
        collection.insertOne(newDocument);
    }
}
    private void iceCreamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iceCreamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iceCreamActionPerformed

    private void BurgerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BurgerButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BurgerButtonActionPerformed

    private void flavorShopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flavorShopActionPerformed
            // TODO add your handling code here:
    }//GEN-LAST:event_flavorShopActionPerformed

    private void ToppingShopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToppingShopActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ToppingShopActionPerformed
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IceCreamShop().setVisible(true);
                
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddOption;
    private javax.swing.JButton AddOption1;
    private javax.swing.JLabel Addorn;
    private javax.swing.JLabel BackgroundLateralP;
    private javax.swing.JButton BurgerButton;
    private javax.swing.JPanel ButtonsPanel;
    private javax.swing.JDialog CardDialog;
    private javax.swing.JTextField CardExpiration;
    private javax.swing.JTextField CardName;
    private javax.swing.JTextField CardNumber;
    private javax.swing.JTextField CardSC;
    private javax.swing.JButton ChangeUserB;
    private javax.swing.JButton ExitB;
    private javax.swing.JLabel FindValidation;
    private javax.swing.JPanel HSellsP;
    private javax.swing.JPanel HeladeriaInteractivePanel;
    private javax.swing.JPanel HeladeriaLateralPanel;
    private javax.swing.JButton InventoryB;
    private javax.swing.JTabbedPane InventoryTabbed;
    private javax.swing.JPanel LockedPanel;
    private javax.swing.JLabel LogoL;
    private javax.swing.JButton MFindB;
    private javax.swing.JButton MFindB2;
    private javax.swing.JLabel MFindL2;
    private javax.swing.JLabel MFindL3;
    private javax.swing.JTextField MFindTF;
    private javax.swing.JTextField MFindTF2;
    private javax.swing.JLabel MInformationL;
    private javax.swing.JLabel MInformationL2;
    private javax.swing.JButton MLoadDataB;
    private javax.swing.JButton MLoadDataB2;
    private javax.swing.JComboBox<String> MLoadTypeDataCB;
    private javax.swing.JComboBox<String> MLoadTypeDataCB2;
    private javax.swing.JLabel MModifyL;
    private javax.swing.JLabel MModifyL2;
    private javax.swing.JLabel MModifyL3;
    private javax.swing.JLabel MModifyL4;
    private javax.swing.JTextField MModifyTF;
    private javax.swing.JTextField MModifyTF2;
    private javax.swing.JTextField MModifyTF3;
    private javax.swing.JTextField MModifyTF4;
    private javax.swing.JButton MSaveModifyB;
    private javax.swing.JButton MSaveModifyB2;
    private javax.swing.JButton MSaveModifyB3;
    private javax.swing.JButton MSaveModifyB4;
    private javax.swing.JTable MTable;
    private javax.swing.JTable MTable1;
    private generalFunctionalities.PanelRound ModificacionesPane;
    private generalFunctionalities.PanelRound ModificacionesPane1;
    private javax.swing.JTable OrderTable;
    private generalFunctionalities.PanelRound PConeIceCreamP;
    private javax.swing.JTextField PortionsDelete;
    private javax.swing.JTextField PortionsSelected;
    private javax.swing.JTextField PortionsSelected2;
    private javax.swing.ButtonGroup RegisterBG;
    private javax.swing.JRadioButton RegisterNo;
    private javax.swing.JRadioButton RegisterYes;
    private javax.swing.JTable RegistersTable;
    private javax.swing.JLabel SBCBillL;
    private javax.swing.JLabel SBCIdentificationL;
    private javax.swing.JLabel SBCNameL;
    private javax.swing.JTextField SBCNameTF;
    private javax.swing.JLabel SBCPaymentL;
    private javax.swing.JLabel SBCPhoneL;
    private javax.swing.JTextField SBCPhoneTF;
    private javax.swing.JLabel SBCRegisterL;
    private javax.swing.JLabel SBCTitleL;
    private javax.swing.JLabel SBCValidation1;
    private javax.swing.JLabel SBCValidation2;
    private javax.swing.JLabel SBCValidation3;
    private javax.swing.JLabel SBCValidation4;
    private javax.swing.JTextField SBCidTF;
    private javax.swing.JButton SBOCancelSellB;
    private javax.swing.JButton SBOFindB;
    private javax.swing.JLabel SBOFindL;
    private javax.swing.JLabel SBOFindL1;
    private javax.swing.JLabel SBOFindL2;
    private javax.swing.JLabel SBOFindL3;
    private javax.swing.JLabel SBOFindL4;
    private javax.swing.JLabel SBOFindL5;
    private javax.swing.JLabel SBOFindL6;
    private javax.swing.JTextField SBOFindTF;
    private javax.swing.JLabel SBOIVAL;
    private generalFunctionalities.PanelRound SBOIVAP;
    private javax.swing.JLabel SBOIVAResultP;
    private javax.swing.JButton SBORefreshB;
    private javax.swing.JButton SBOSellB;
    private javax.swing.JLabel SBOSubtotalL;
    private generalFunctionalities.PanelRound SBOSubtotalP;
    private javax.swing.JLabel SBOTitleL;
    private javax.swing.JLabel SBOTotalL;
    private generalFunctionalities.PanelRound SBOTotalP;
    private javax.swing.JComboBox<String> SBillTypeCB;
    private generalFunctionalities.PanelRound SBillsPane;
    private generalFunctionalities.PanelRound SClientP;
    private javax.swing.JLabel SCodeL;
    private javax.swing.JTextField SCodeTF;
    private javax.swing.JButton SDeleteAllB1;
    private javax.swing.JButton SDeleteAllB3;
    private javax.swing.JLabel SImageL;
    private javax.swing.JLabel SL5;
    private javax.swing.JLabel SL6;
    private javax.swing.JLabel SNameL;
    private javax.swing.JTextField SNameTF;
    private generalFunctionalities.PanelRound SOrderPanel;
    private javax.swing.JComboBox<String> SPaymentCB;
    private generalFunctionalities.PanelRound SProductsPane;
    private javax.swing.JTabbedPane SProductsTabbed;
    private javax.swing.JLabel SQuantityL;
    private javax.swing.JTextField SQuantityTF;
    private javax.swing.JButton SRDeleteOnecar;
    private javax.swing.JButton SRLoadDataRegisterB;
    private generalFunctionalities.PanelRound SRegistersPane;
    private javax.swing.JButton SSaveAllB;
    private javax.swing.JTable STable;
    private javax.swing.JButton SellsB;
    private javax.swing.JButton SettingsB;
    private generalFunctionalities.PanelRound SupliesPane;
    private generalFunctionalities.PanelRound SupliesTablePanel;
    private javax.swing.JLabel TCodeL;
    private javax.swing.JTextField TCodeTF;
    private javax.swing.JTextField TCuantityTF;
    private javax.swing.JLabel TImageL;
    private javax.swing.JLabel TNameL;
    private javax.swing.JTextField TNameTF;
    private javax.swing.JLabel TQuantityL;
    private javax.swing.JButton TSaveAllB;
    private javax.swing.JTable TTable;
    private generalFunctionalities.PanelRound TastePanel;
    private javax.swing.JComboBox<String> ToppingShop;
    private javax.swing.JButton UserManualB;
    private javax.swing.JLabel ValidationCEMM;
    private javax.swing.JLabel ValidationCName;
    private javax.swing.JLabel ValidationCNumber;
    private javax.swing.JLabel ValidationCSC;
    private javax.swing.JButton WMDeleteWorkerB1;
    private javax.swing.JButton WMDeleteWorkerB2;
    private javax.swing.JTextField YY;
    private javax.swing.JLabel finaaal;
    private javax.swing.JComboBox<String> flavorShop;
    private javax.swing.JComboBox<String> iceCream;
    private javax.swing.JTextField iceCreamtype;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextPane jTextPane1;
    private generalFunctionalities.PanelRound panelRound1;
    private generalFunctionalities.PanelRound panelRound10;
    private generalFunctionalities.PanelRound panelRound2;
    private generalFunctionalities.PanelRound panelRound4;
    private generalFunctionalities.PanelRound panelRound5;
    private generalFunctionalities.PanelRound panelRound6;
    private javax.swing.JLabel totalfinal;
    private javax.swing.JTable updateProducts;
    private javax.swing.JTable updateProducts1;
    // End of variables declaration//GEN-END:variables
}
