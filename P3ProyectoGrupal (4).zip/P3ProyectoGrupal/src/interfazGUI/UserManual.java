package interfazGUI;
import classUserManual.closeUserManual;
import tipografias.Fuentes;

public class UserManual extends javax.swing.JFrame {
    Fuentes tipoFuente;
    closeUserManual cUM=new closeUserManual();
    public UserManual() {
        initComponents();
        
        tipoFuente = new Fuentes();
        rsscalelabel.RSScaleLabel.setScaleLabel(UMBackgroundL, "src/imagenes/Background.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(Logo, "src/imagenes/LogoDeliFrostMini.png");
        this.setLocationRelativeTo(null);
        
        //Cambiar fuente
        UMTitleL.setFont(tipoFuente.fuente(tipoFuente.QS,1,22));
        UMInfoTabbed.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        UMSimbologyL.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        UMInterfacesL.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        UMDatabaseL.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        UMSimbologyInfoTP.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        UMInterfaceInfoTP.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        UMDatabaseInfoTP.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        Function.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        InterfaceTitle.setFont(tipoFuente.fuente(tipoFuente.QS,1,16));
        FunctionTitle.setFont(tipoFuente.fuente(tipoFuente.QS,1,16));
        Inventory.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        Sells.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        Settings.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        UM.setFont(tipoFuente.fuente(tipoFuente.QS,1,14));
        SL1.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL2.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL3.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL4.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL5.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL6.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL7.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL8.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL9.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL10.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL11.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
        SL12.setFont(tipoFuente.fuente(tipoFuente.QS,1,12));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LogoPanel = new generalFunctionalities.PanelRound();
        Logo = new javax.swing.JLabel();
        UMBackgroundP = new javax.swing.JPanel();
        UMTitleL = new javax.swing.JLabel();
        UMInfoTabbed = new javax.swing.JTabbedPane();
        UMSimbologyP = new generalFunctionalities.PanelRound();
        UMSimbologyL = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        UMSimbologyInfoTP = new javax.swing.JTextPane();
        SL5 = new javax.swing.JLabel();
        SL7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        SL8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        SL11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        SL4 = new javax.swing.JLabel();
        SL6 = new javax.swing.JLabel();
        SL1 = new javax.swing.JLabel();
        SL2 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        SL3 = new javax.swing.JLabel();
        SL9 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        SL10 = new javax.swing.JLabel();
        SL13 = new javax.swing.JLabel();
        SL12 = new javax.swing.JLabel();
        UMInterfaceP = new generalFunctionalities.PanelRound();
        UMInterfacesL = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        UMInterfaceInfoTP = new javax.swing.JTextPane();
        InterfaceTitle = new javax.swing.JLabel();
        FunctionTitle = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Function = new javax.swing.JTextPane();
        Inventory = new javax.swing.JLabel();
        Sells = new javax.swing.JLabel();
        Settings = new javax.swing.JLabel();
        UM = new javax.swing.JLabel();
        UMDatabaseP = new generalFunctionalities.PanelRound();
        UMDatabaseL = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        UMDatabaseInfoTP = new javax.swing.JTextPane();
        WMBackB = new javax.swing.JButton();
        UMBackgroundL = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 480));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LogoPanel.setBackground(new java.awt.Color(117, 117, 117));
        LogoPanel.setRoundBottomLeft(200);
        LogoPanel.setRoundBottomRight(200);
        LogoPanel.setRoundTopLeft(200);
        LogoPanel.setRoundTopRight(200);

        javax.swing.GroupLayout LogoPanelLayout = new javax.swing.GroupLayout(LogoPanel);
        LogoPanel.setLayout(LogoPanelLayout);
        LogoPanelLayout.setHorizontalGroup(
            LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 130, Short.MAX_VALUE)
            .addGroup(LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Logo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
        );
        LogoPanelLayout.setVerticalGroup(
            LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 130, Short.MAX_VALUE)
            .addGroup(LogoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Logo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
        );

        getContentPane().add(LogoPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, 130, 130));

        UMBackgroundP.setBackground(new java.awt.Color(117, 117, 117));
        UMBackgroundP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        UMTitleL.setForeground(new java.awt.Color(255, 255, 255));
        UMTitleL.setText("MANUAL DE USUARIO");
        UMBackgroundP.add(UMTitleL, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        UMInfoTabbed.setBackground(new java.awt.Color(255, 255, 255));
        UMInfoTabbed.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        UMInfoTabbed.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        UMSimbologyP.setBackground(new java.awt.Color(166, 166, 166));
        UMSimbologyP.setRoundBottomLeft(100);
        UMSimbologyP.setRoundBottomRight(100);
        UMSimbologyP.setRoundTopRight(100);
        UMSimbologyP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        UMSimbologyL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        UMSimbologyL.setForeground(new java.awt.Color(255, 255, 255));
        UMSimbologyL.setText("Simbologia");
        UMSimbologyP.add(UMSimbologyL, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        UMSimbologyInfoTP.setEditable(false);
        UMSimbologyInfoTP.setBackground(new java.awt.Color(166, 166, 166));
        UMSimbologyInfoTP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UMSimbologyInfoTP.setForeground(new java.awt.Color(255, 255, 255));
        UMSimbologyInfoTP.setText("Bienvenido a la guía de símbolos, a continuación te presentaremos la función de cada símbolo utilizado en el software desarrollado para la marca DeliFrost, esto te permitirá orientarte en el uso de esta herramienta.");
        jScrollPane3.setViewportView(UMSimbologyInfoTP);

        UMSimbologyP.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 630, 70));

        SL5.setForeground(new java.awt.Color(255, 255, 255));
        SL5.setText("Eliminar un solo elemento seleccionado ");
        UMSimbologyP.add(SL5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 220, 20));

        SL7.setForeground(new java.awt.Color(255, 255, 255));
        SL7.setText("Simbolos");
        UMSimbologyP.add(SL7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 120, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/remove+.png"))); // NOI18N
        UMSimbologyP.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        SL8.setForeground(new java.awt.Color(255, 255, 255));
        SL8.setText("Definicion");
        UMSimbologyP.add(SL8, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete+.png"))); // NOI18N
        UMSimbologyP.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        SL11.setForeground(new java.awt.Color(255, 255, 255));
        SL11.setText("Añadir un elemento a la tabla");
        UMSimbologyP.add(SL11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, 210, 30));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/vender+.png"))); // NOI18N
        UMSimbologyP.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        SL4.setForeground(new java.awt.Color(255, 255, 255));
        SL4.setText("Realizar la venta y registrarla en la base");
        UMSimbologyP.add(SL4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 220, 30));

        SL6.setForeground(new java.awt.Color(255, 255, 255));
        SL6.setText("de una tabla");
        UMSimbologyP.add(SL6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 210, -1));

        SL1.setForeground(new java.awt.Color(255, 255, 255));
        SL1.setText("Simbolos");
        UMSimbologyP.add(SL1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        SL2.setForeground(new java.awt.Color(255, 255, 255));
        SL2.setText("Definicion");
        UMSimbologyP.add(SL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        UMSimbologyP.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Modificarpositivo.png"))); // NOI18N
        UMSimbologyP.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/actualizar+.png"))); // NOI18N
        UMSimbologyP.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 160, 30, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add+.png"))); // NOI18N
        UMSimbologyP.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 190, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/loaddata+.png"))); // NOI18N
        UMSimbologyP.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 250, -1, -1));

        SL3.setForeground(new java.awt.Color(255, 255, 255));
        SL3.setText("Volver a la pestaña anterior");
        UMSimbologyP.add(SL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 150, 30));

        SL9.setForeground(new java.awt.Color(255, 255, 255));
        SL9.setText("Modificar un elemento");
        UMSimbologyP.add(SL9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, 150, 20));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cancelarventa+.png"))); // NOI18N
        UMSimbologyP.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, -1, -1));

        SL10.setForeground(new java.awt.Color(255, 255, 255));
        SL10.setText("Actualizar la tabla");
        UMSimbologyP.add(SL10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 150, 30));

        SL13.setForeground(new java.awt.Color(255, 255, 255));
        SL13.setText("Cargar datos y refrescar la tabla");
        UMSimbologyP.add(SL13, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 250, 210, 30));

        SL12.setForeground(new java.awt.Color(255, 255, 255));
        SL12.setText("Cancelar la venta");
        UMSimbologyP.add(SL12, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 220, 210, 30));

        UMInfoTabbed.addTab("Simbología", UMSimbologyP);

        UMInterfaceP.setBackground(new java.awt.Color(166, 166, 166));
        UMInterfaceP.setRoundBottomLeft(100);
        UMInterfaceP.setRoundBottomRight(100);
        UMInterfaceP.setRoundTopRight(100);
        UMInterfaceP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        UMInterfacesL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        UMInterfacesL.setForeground(new java.awt.Color(255, 255, 255));
        UMInterfacesL.setText("Interfaces");
        UMInterfaceP.add(UMInterfacesL, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        UMInterfaceInfoTP.setEditable(false);
        UMInterfaceInfoTP.setBackground(new java.awt.Color(166, 166, 166));
        UMInterfaceInfoTP.setBorder(null);
        UMInterfaceInfoTP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UMInterfaceInfoTP.setForeground(new java.awt.Color(255, 255, 255));
        UMInterfaceInfoTP.setText("Bienvenido a la guía de interfaces, en este apartado te describiremos la función de cada interfaz que se despliega con los botones, esto para que puedas moverte fluidamente entre las mismas");
        jScrollPane2.setViewportView(UMInterfaceInfoTP);

        UMInterfaceP.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 630, 50));

        InterfaceTitle.setForeground(new java.awt.Color(255, 255, 255));
        InterfaceTitle.setText("Interfaz");
        UMInterfaceP.add(InterfaceTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        FunctionTitle.setForeground(new java.awt.Color(255, 255, 255));
        FunctionTitle.setText("Funcion");
        UMInterfaceP.add(FunctionTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, -1, -1));

        Function.setEditable(false);
        Function.setBackground(new java.awt.Color(166, 166, 166));
        Function.setForeground(new java.awt.Color(255, 255, 255));
        Function.setText("En esta interfaz puedes acceder al los datos de los productos registrados en el sisttema para añadir mas o modificarlos.\n\nPermite gestionar una venta con datos del cliente y datos del pedido, modificarlo, venderlo o cancelarlo.\n\nAquí puedes cambiar ajustes del programa u otros aspectos del sistema.\n\nEs donde te encuentras y aqui hay informacion util sobre el programa.");
        jScrollPane1.setViewportView(Function);

        UMInterfaceP.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 470, 150));

        Inventory.setForeground(new java.awt.Color(255, 255, 255));
        Inventory.setText("Inventario");
        UMInterfaceP.add(Inventory, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        Sells.setForeground(new java.awt.Color(255, 255, 255));
        Sells.setText("Ventas");
        UMInterfaceP.add(Sells, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, 20));

        Settings.setForeground(new java.awt.Color(255, 255, 255));
        Settings.setText("Configuraciones");
        UMInterfaceP.add(Settings, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, -1));

        UM.setForeground(new java.awt.Color(255, 255, 255));
        UM.setText("Manual de usuario");
        UMInterfaceP.add(UM, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        UMInfoTabbed.addTab("Interfaces", UMInterfaceP);

        UMDatabaseP.setBackground(new java.awt.Color(166, 166, 166));
        UMDatabaseP.setRoundBottomLeft(100);
        UMDatabaseP.setRoundBottomRight(100);
        UMDatabaseP.setRoundTopRight(100);
        UMDatabaseP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        UMDatabaseL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        UMDatabaseL.setForeground(new java.awt.Color(255, 255, 255));
        UMDatabaseL.setText("Base de datos");
        UMDatabaseP.add(UMDatabaseL, new org.netbeans.lib.awtextra.AbsoluteConstraints(14, 6, -1, -1));

        UMDatabaseInfoTP.setEditable(false);
        UMDatabaseInfoTP.setBackground(new java.awt.Color(166, 166, 166));
        UMDatabaseInfoTP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UMDatabaseInfoTP.setForeground(new java.awt.Color(255, 255, 255));
        UMDatabaseInfoTP.setText("Bienvenido a la guía de base de datos, la base de datos es proporcionada y funciona gracias a MongoDB, esta base se ejecuta de manera local, es decir no necesitas de conexión a internet para acceder a ella, aunque algunos complementos de este sistema si requieren de una conexión a internet, por esto no te recomendamos que lo utilices fuera de la red, la base de datos consta de varias colecciones, que almacenan datos de los productos, los trabajadores y los registros, te sugerimos no modificar nada de esta, en caso de que el programa no funcione con normalidad arranca manualmente el servidor con un símbolo del sistema de Windows, ingresando el comando “mongod” para iniciar el servidor, después dirígete a “MongoDB Compass” e inicia la conexión, esto solucionara el problema, de otra forma contacta con los desarrolladores del sistema para obtener soporte, esperamos que este programa sea de utilidad para tu trabajo.");
        jScrollPane4.setViewportView(UMDatabaseInfoTP);

        UMDatabaseP.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 630, 210));

        UMInfoTabbed.addTab("Base de datos", UMDatabaseP);

        UMBackgroundP.add(UMInfoTabbed, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 760, 290));

        getContentPane().add(UMBackgroundP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 1280, 550));

        WMBackB.setBackground(new java.awt.Color(117, 117, 117));
        WMBackB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        WMBackB.setBorder(null);
        WMBackB.setContentAreaFilled(false);
        WMBackB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WMBackBActionPerformed(evt);
            }
        });
        getContentPane().add(WMBackB, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));
        getContentPane().add(UMBackgroundL, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void WMBackBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WMBackBActionPerformed
    cUM.ce(this);
    }//GEN-LAST:event_WMBackBActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserManual().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextPane Function;
    private javax.swing.JLabel FunctionTitle;
    private javax.swing.JLabel InterfaceTitle;
    private javax.swing.JLabel Inventory;
    private javax.swing.JLabel Logo;
    private generalFunctionalities.PanelRound LogoPanel;
    private javax.swing.JLabel SL1;
    private javax.swing.JLabel SL10;
    private javax.swing.JLabel SL11;
    private javax.swing.JLabel SL12;
    private javax.swing.JLabel SL13;
    private javax.swing.JLabel SL2;
    private javax.swing.JLabel SL3;
    private javax.swing.JLabel SL4;
    private javax.swing.JLabel SL5;
    private javax.swing.JLabel SL6;
    private javax.swing.JLabel SL7;
    private javax.swing.JLabel SL8;
    private javax.swing.JLabel SL9;
    private javax.swing.JLabel Sells;
    private javax.swing.JLabel Settings;
    private javax.swing.JLabel UM;
    private javax.swing.JLabel UMBackgroundL;
    private javax.swing.JPanel UMBackgroundP;
    private javax.swing.JTextPane UMDatabaseInfoTP;
    private javax.swing.JLabel UMDatabaseL;
    private generalFunctionalities.PanelRound UMDatabaseP;
    private javax.swing.JTabbedPane UMInfoTabbed;
    private javax.swing.JTextPane UMInterfaceInfoTP;
    private generalFunctionalities.PanelRound UMInterfaceP;
    private javax.swing.JLabel UMInterfacesL;
    private javax.swing.JTextPane UMSimbologyInfoTP;
    private javax.swing.JLabel UMSimbologyL;
    private generalFunctionalities.PanelRound UMSimbologyP;
    private javax.swing.JLabel UMTitleL;
    private javax.swing.JButton WMBackB;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}
