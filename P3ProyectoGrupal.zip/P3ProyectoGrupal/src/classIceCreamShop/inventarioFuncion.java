package classIceCreamShop;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class inventarioFuncion {
   public void seeInventary(JTabbedPane InventoryTabbed,JPanel HSellsP){
        InventoryTabbed.setVisible(true);
        HSellsP.setVisible(false);
   } 
}
