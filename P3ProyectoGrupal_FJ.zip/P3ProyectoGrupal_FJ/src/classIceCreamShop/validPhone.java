package classIceCreamShop;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import java.awt.Color;
import javax.swing.JLabel;
import org.bson.Document;
public class validPhone {
   public void validData(String PhoneClient,String  IDClient,JLabel SBCValidation2 ){
     if(PhoneClient.isEmpty()){
            SBCValidation2.setText("¡Este campo es obligatorio!");
            SBCValidation2.setForeground(Color.RED);
        }else{
            if(PhoneClient.length()!=10 && PhoneClient==IDClient){
                SBCValidation2.setText("El telefono debe tener 10 digitos numericos y ser diferente a la cedula");
            }else{
             searchPhone( PhoneClient,  IDClient, SBCValidation2) ;  
                    
            }
        }   
   }
   public void searchPhone(String PhoneClient,String  IDClient,JLabel SBCValidation2){
    initializeMongo iM=new initializeMongo();
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();   
    MongoCollection<Document> collection = database.getCollection("RegistroClientes");
    Document query = new Document("Teléfono",PhoneClient);
    FindIterable<Document> documents = collection.find(query);
    if(documents.iterator().hasNext()){
       SBCValidation2.setText("Este telefono ya esta en uso, ingresa otro para registrar");
       SBCValidation2.setForeground(Color.RED);
    }else{
        SBCValidation2.setText("");
    }  
   }
}
