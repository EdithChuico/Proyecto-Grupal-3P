/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classIceCreamShop;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import generalFunctionalities.initializeMongo;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class readInvoices {
    public void seeInvoices(JTable RegistersTable){
    initializeMongo iM=new initializeMongo();
    iM.openMongo();
    iM.getDatabase();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("Facturas");
    DefaultTableModel modelRegisters = new DefaultTableModel();
    FindIterable<Document> documents = collection.find();
    modelRegisters.setRowCount(0);
    for(Document document : documents){
        String[] row={
            document.getString("Cliente"),
            document.getString("Cedula"),
            document.getString("Telefono"),
            document.getString("Pago"),
            document.getString("Pedido"),
            document.getString("Cantidad"),
            document.getString("Total")
        };
        modelRegisters.addRow(row);
        }
            
        RegistersTable.setModel(modelRegisters);
}
}

